#include<bits/stdc++.h>
using namespace std;
int a,b,n;
int main(){
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	cin >> a >> b;
	n=b-a-1;
	cout << (1+n)*n/2-a << endl;
	return 0;
}
