#include<bits/stdc++.h>
using namespace std;
long long a,b,cha; 
int main(){
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	long long t[1001];
	t[1]=1;
	for(int i=2;i<1000;i++){
		t[i]=t[i-1]+i;
	}
	cin>>a>>b;
	cha=b-a;
	cout<<t[cha]-b<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
