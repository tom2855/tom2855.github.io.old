#include<bits/stdc++.h>
using namespace std;
int a,cx[10005],ans;
int main(){
	freopen("carry.in","r",stdin);
	freopen("carry.out","w",stdout);
	cin>>a;
	for(int i=1;i<=a;i++){
		cin>>cx[i];
	}
	for(int i=1;i<a;i++){
		bool f=1;
		for(int j=1;j<=a-i;j++){
			if(cx[j+1]<cx[j]){
				swap(cx[j+1],cx[j]);
				f=0;
				ans++;
			}
		}
		if(f) break;
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
