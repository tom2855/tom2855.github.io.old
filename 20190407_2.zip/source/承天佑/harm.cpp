#include<bits/stdc++.h>
using namespace std;
int n,a[1005][1005]={0},ans;
int dx[2]={0,1};
int dy[2]={1,0};
bool check(int x,int y){
	if(x<0||x>n) return 0;
	if(y>n||y<0) return 0;
	if(a[x][y]) return 0;
	return 1;
}
void dfs(int x,int y){
	ans=ans+a[x][y];
	if(check(x+1,y))
		if(check(x,y+1))
			if(a[x+1][y]>a[x][y+1])
			dfs(x,y+1);
			else
			dfs(x+1,y);
	
}
int main(){
	freopen("harm.in","r",stdin);
	freopen("harm.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
	cin>>a[i][j];
	dfs(1,1);
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
