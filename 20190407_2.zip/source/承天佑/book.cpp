#include<bits/stdc++.h>
using namespace std;
int a,c[55],y[55];
int main(){
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	cin>>a;
	int m=30;
	for(int i=0;i<a;i++)
		for(int j=0;j<a;j++){
			char h;
			cin>>h;
			c[i]+=(h-'0');
			y[i]+=(h-'0');
		}
	for(int i=1;i<a;i++)
		m=min(m,min(c[i],y[i]));
	cout<<m<<endl;
	fclose(stdin);
	fclose(stdout);
		return 0;
}
