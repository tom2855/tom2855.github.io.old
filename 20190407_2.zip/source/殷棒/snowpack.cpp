#include<bits/stdc++.h>
using namespace std;
int a,b,ans;
int main(){
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
    cin >> a >> b;
    ans = ((b - a) * (b - a + 1)) / 2 - b;
    cout << ans << endl;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
