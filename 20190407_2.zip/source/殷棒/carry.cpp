#include<bits/stdc++.h>
using namespace std;
int n,c[10005],ans = 20000000,s;
int main() {
	freopen("carry.in","r",stdin);
	freopen("carry.out","w",stdout);
	cin >> n;
	for(int i = 1; i <= n; i++) {
		cin >> c[i];
	}
	for(int i = 1; i < n; i++) {
		if(c[i] > c[i + 1] && i + 1 <= n) {
			swap(c[i],c[i + 1]);
			s++;
		}
	}
	ans = min(ans,s);
	cout << ans * 2 << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
