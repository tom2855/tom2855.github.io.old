#include<bits/stdc++.h>
using namespace std;
int n,c,ans;
char ch[25][25];
bool b[25];
void dfs(int y) {
	if(y == n+1) {
		ans++;
		return;
	}
	for(int i=1; i<=n; i++) {
		if(ch[i][y] == '1' && !b[i]) {
			b[i] = 1;
			dfs(y+1);
			b[i] = 0;
		}
	}
}
int main() {
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	cin >> n;
	for(int i=1; i<=n; i++)
		for(int j=1; j<=n; j++)
			cin >> ch[i][j];
	dfs(1);
	cout << ans << endl;
	return 0;
}
