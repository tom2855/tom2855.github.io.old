#include<bits/stdc++.h>
using namespace std;
int a,b;
int y[1001],c = 1;
int main() {
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	cin >> a >> b;
	y[1] = 1;
	for(int i=2; i<=999; i++) {
		y[i] = y[i-1] + i;
	}
	for(int i=1; ; i++) {
		for(int j=1; j<a; j++) {
			if(a+j == y[i] && b+j == y[i+1]) {
				cout << j << endl;
				return 0;
			}
		}
	}
}
