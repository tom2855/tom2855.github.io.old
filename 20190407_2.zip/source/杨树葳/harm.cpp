#include<bits/stdc++.h>
using namespace std;
int n;
int opt[1005][1005],s;
int ni,nj;
int main() {
	freopen("harm.in","r",stdin);
	freopen("harm.out","w",stdout);
	cin >> n;
	for(int i=1; i<=n; i++)
		for(int j=1; j<=n; j++) {
			cin >> opt[i][j];
		}
	s = opt[1][1];
	for(int i=1; i<=n; i++)
		for(int j=1; j<=n; j++) {
			s += min(opt[i+1][j],opt[i][j+1]);
		}
	cout << s << endl;
	return 0;
}
