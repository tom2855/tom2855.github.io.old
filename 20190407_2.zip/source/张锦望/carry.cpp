#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("carry.in","r",stdin);
	freopre("carry.out","w",stdout);
	int n,a[10000],ans=0;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	for(int i=0;i<n-1;i++){
		bool f=1;
		for(int j=0;j<n-1;j++){
			if(a[j]>a[j+1]){
				swap(a[j],a[j+1]);
				ans++;
				f=0;
			}
		}
		if(f)break;
	}
	cout<<ans;
}
