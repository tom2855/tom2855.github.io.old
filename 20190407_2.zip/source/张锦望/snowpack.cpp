#include<bits/stdc++.h>
using namespace std;
int a,b,c,ans;
int main(){
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	cin>>a>>b;
	c=b-a;
	for(int i=1;i<=c;i++){
		ans+=i;
	}
	cout<<ans-b;
}
