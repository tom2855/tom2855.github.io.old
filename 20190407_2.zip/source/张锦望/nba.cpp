#include<bits/stdc++.h>
using namespace std;
struct nba{
	int year;
	string city;
};
bool p(nba a,nba b){
	return a.year<b.year;
}
int main(){
	freopen("nba.in","r",stdin);
	freopen("nba.out","w",stdout);
	int n;
	nba a[50];
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i].city>>a[i].year;
	}
	sort(a,a+n,p);
	cout<<a[0].year<<' '<<a[0].city<<'\n';
	for(int i=1;i<n;i++){
		if(a[i].year!=a[i-1].year){
			cout<<a[i].year<<' '<<a[i].city<<'\n';
		}
	}
}
