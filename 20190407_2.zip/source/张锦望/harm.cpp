#include<bits/stdc++.h>
using namespace std;
int n,mp[1000][1000];
int d[4][2]={
-1,0,
0,1,
1,0,
0,-1};
long long mi=LLONG_MAX;
struct point{
	int x;
	int y;
};
queue<point> a;
void bfs(int x,int y,long long s){
	if(x==n&&y==n){
		mi=min(mi,s+mp[x][y]);
		return;
	}
	a.pop();
	for(int i=0;i<4;i++){
		point t;
		t.x=x+d[i][0];
		t.y=y+d[i][1];
		if(t.x>=0&&t.x<n&&t.y>=0&&t.y<n){
			a.push(t);
		}
	}
	bfs(a.front().x,a.front().y,s+mp[a.front().x][a.front().y]);
} 
int main(){
	cin>>n;
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			cin>>mp[i][j];
		}
	}
	point t;
	t.x=0;
	t.y=0;
	a.push(t);
	bfs(t.x,t.y,0);
	cout<<mi;
} 
