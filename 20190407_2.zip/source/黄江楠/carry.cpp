#include<bits/stdc++.h>
using namespace std;
int n,i,j,t,s,a[10010];
int main() {
	freopen("carry.in","r",stdin);
	freopen("carry.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++){
		cin>>a[i];
	}
	for(i=1;i<=n-1;i++){
		for(j=1;j<=n-i;j++){
			if(a[j]>a[j+1]){
				swap(a[j],a[j+1]);
				s++;
			}
		}
	}
	cout<<s<<endl;
	return 0;
}
