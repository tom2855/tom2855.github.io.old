#include<bits/stdc++.h>
using namespace std;
int n,a[1001][1001],i,j,k,ans,t,jj,jjj;
int main() {
	freopen("harm.in","r",stdin);
	freopen("harm.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++){
		for(j=1;j<=n;j++){
			cin>>a[i][j];
			if(i==1 and j==1) jj=a[i][j];
			if(a[i][j]!=jj) jjj=1; 
		}
	}
	if(jjj==0) {
		cout<<jj*n+jj*(n-1)<<endl;
		return 0;
	}
	for(i=1;i<=n;i++){
		for(j=1;j<=n;j++){
			ans=ans+a[i][j];
			if(i==n and j==n) break;
			if(i==n) {
				for(k=j+1;k<=n;k++){
					ans=ans+a[n][k];
				}
				break;
			}
			if(j==n) {
				for(k=n+1;k<=j;k++){
					ans=ans+a[k][n];
				}
				break;
			}
			if(a[i+1][j]>=a[i][j+1]) {
				continue;
			}
			if(a[i+1][j]<a[i][j+1]) {
				i++;
				j--;
				continue;
			}
		}
	}
	cout<<ans<<endl;
	return 0;	
}
