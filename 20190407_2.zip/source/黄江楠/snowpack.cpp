#include<bits/stdc++.h>
using namespace std;
int a,b,c,h1,h2,sum,i,j,ans;
int main() {
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	cin>>a>>b;
	c=b-a;
	for(i=1;i<=c;i++){
		sum=sum+i;
	}
	cout<<sum-b<<endl;
	return 0;
}
