#include <cstdio>
using namespace std;

int map[1002][1002], n;
long long opt[1002][1002];

int min(int x1, int x2) {
	return x1 < x2? x1 : x2;
}

int main() {
	freopen("harm.in", "r", stdin);
	freopen("harm.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 0; i <= n + 1; ++i) {
		for(int j = 0; j <= n + 1; ++j) {
			map[i][j] = 0x7fffffff;
		}
	}
	for(int i = 1; i <= n; ++i) {
		for(int j = 1; j <= n; ++j) {
			scanf("%d", &map[i][j]);
		}
	}
	opt[1][1] = map[1][1];
	for(int i = 2; i <= n; ++i) {
		opt[i][1] = opt[i - 1][1] + map[i][1];
		opt[1][i] = opt[1][i - 1] + map[1][i];
	}
	for(int i = 2; i <= n; ++i) {
		for(int j = 2; j <= n; ++j) {
			opt[i][j] = min(opt[i - 1][j] + map[i][j], opt[i][j - 1] + map[i][j]);
		}
	}
/*	for(int i = 1; i <= n; ++i) {
		for(int j = 1; j <= n; ++j) {
			printf("%d ", opt[i][j]);
		}
		putchar('\n');
	}*/
	printf("%d\n", opt[n][n]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
