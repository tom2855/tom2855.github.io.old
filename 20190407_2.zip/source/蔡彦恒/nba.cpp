#include <iostream>
#include <cstdio>
#include <string>
#include <algorithm>
#include <set>
using namespace std;

struct node {
	string team;
	int year;
	bool operator < (node cmp) const {
		return year < cmp.year;
	}
}s[51];
int n;
set<node> se;

int calc(string &str) {
	int nn = 0, len = str.size();
	for(int i = len - 4; i < len; ++i) {
		nn = nn * 10 + str[i] - '0';
	}
	str.erase(len - 5, len - 1);
	return nn;
}

int main() {
	freopen("nba.in", "r", stdin);
	freopen("nba.out", "w", stdout);
	cin >> n;
	getchar();
	for(int i = 1; i <= n; ++i) {
		getline(cin, s[i].team);
		s[i].year = calc(s[i].team);
		se.insert(s[i]);
	}
	sort(s + 1, s + 1 + n);
	for(set<node> :: iterator it = se.begin(); it != se.end(); it++) {
		cout << (*it).year << " " << (*it).team << endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
