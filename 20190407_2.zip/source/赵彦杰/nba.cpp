#include<bits/stdc++.h>
using namespace std;
int n,t,num,i,j,year[50];
string c,city[50];
int main() {
	freopen("nba.in","r",stdin);
	freopen("nba.out","w",stdout);
	scanf("%d",&n);
	for(i = 0; i < n; i++) {
		cin >> c >> t;
		for(j = 0; j < num ; j++)
			if(year[j] == t && city[j] == c)
				break;
		if(j == num) {
			city[num] = c;
			year[num++] = t;
		}
	}
	for(i = 0; i < num; i++)
		for(j = i + 1 ; j < num; j++)
			if(year[i] > year[j]) {
				swap(year[i],year[j]);
				swap(city[i],city[j]);
			}
	for(i = 0 ; i < num; i++)
		cout << year[i] << " " << city[i] << endl;
	return 0;
}
