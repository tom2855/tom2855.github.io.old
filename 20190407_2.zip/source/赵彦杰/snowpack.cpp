#include<bits/stdc++.h>
using namespace std;
int a,b,i,h[1000] = {0,1};
int main() {
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	scanf("%d%d",&a,&b);
	for(i = 2; i <= 999; i++) {
		h[i] = h[i - 1] + i;
		if(h[i - 1] - a == h[i] - b) {
			printf("%d\n",h[i] - b);
			return 0;
		}
	}
}
