#include<bits/stdc++.h>
using namespace std;
int n,ans,i,j;
bool a[21][21],book[21];
char c;
void dfs(int num) {
	if(num > n)
		ans++;
	else
		for(int i = 1; i <= n; i++)
			if(a[num][i] && !book[i]) {
				book[i] = 1;
				dfs(num + 1);
				book[i] = 0;
			}
}
int main() {
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	scanf("%d",&n);
	for(i = 1; i <= n; i++)
		for(j = 1; j <= n; j++) {
			cin >> c;
			a[i][j] = c - '0';
		}
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
