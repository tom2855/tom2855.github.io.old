#include<bits/stdc++.h>
using namespace std;
int n,ans,i,x = 1,a[10000];
int main() {
	freopen("carry.in","r",stdin);
	freopen("carry.out","w",stdout);
	scanf("%d",&n);
	for(i = 0; i < n; i++)
		scanf("%d",&a[i]);
	while(x) {
		x = 0;
		for(i = 0; i < n - 1; i++)
			if(a[i] > a[i + 1]) {
				ans++;
				swap(a[i],a[i + 1]);
				x = 1;
			}
	}
	printf("%d\n",ans);
	return 0;
}
