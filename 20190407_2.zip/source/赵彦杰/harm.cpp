#include<bits/stdc++.h>
using namespace std;
int n,i,j,a[1001][1001];
int main() {
	freopen("harm.in","r",stdin);
	freopen("harm.out","w",stdout);
	scanf("%d",&n);
	for(i = 0; i <= n; i++)
		for(j = 0; j <= n; j++)
			a[i][j] = 2000;
	for(i = 1; i <= n; i++)
		for(j = 1; j <= n; j++)
			scanf("%d",&a[i][j]);
	a[1][0] = a[0][1] = 0;
	for(i = 1; i <= n; i++)
		for(j = 1 ; j <= n; j++)
			a[i][j] += min(a[i - 1][j],a[i][j - 1]);
	printf("%d\n",a[n][n]);
	return 0;
}
