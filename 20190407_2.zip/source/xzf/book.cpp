#include<bits/stdc++.h>
using namespace std;
#define Maxn 20 + 5
int n,like[Maxn][Maxn],used[Maxn],ans;
char ch;
void dfs(int i){
	for(int j = 1;j <= n;j++)
		if (like[i][j] && !used[j]){
			used[j] = 1;
			if (i == n) 
				ans++;
			else 
				dfs(i + 1);
			used[j] = 0;
		}
}
int main(){
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	cin >> n;
	for(int i = 1;i <= n;i++)
		for(int j = 1;j <= n;j++){
			cin >> ch;
			like[i][j] = ch - '0';
		}
	dfs(1);
	cout << ans << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;	
}
