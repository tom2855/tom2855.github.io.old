#include<bits/stdc++.h>
using namespace std;
#define Maxn 10000
int n,carry[Maxn + 5],opt[Maxn + 5],ans;
int main() {
	freopen("carry.in","r",stdin);
	freopen("carry.out","w",stdout);
	cin >> n;
	for(int i = 1; i <= n; i++)
		cin >> carry[i];
	ans = opt[n] = 1;
	for(int i = n; i >= 1; i--) {
		int tmp = 0;
		for(int j = i + 1; j <= n; j++)
			if(carry[j] > carry[i] && opt[j] > tmp)
				tmp = opt[i];
		opt[i] = tmp + 1;
		ans = max(ans,opt[i]);
	}
	printf("%d\n",(n - ans) * 2);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

