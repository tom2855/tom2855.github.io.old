#include <bits/stdc++.h>
using namespace std;
int a,b,h;
int main(){
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	cin >> a >> b;
	h = b - a - 1;
	cout << (h/2+h*h/2)-a << endl;
	return 0;
}
