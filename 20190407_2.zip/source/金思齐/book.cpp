#include <bits/stdc++.h>
using namespace std;
char c[22][22];
bool _used[22];
int n,suc;
int dfs(int i,int j) {
	if (i == n) {
		suc++;
		return 0;
	}
	for (int a = 1; a<=n; a++) {
		if (c[i+1][a] == '1'&&_used[a] == false) {
			_used[a] = true;
			dfs(i+1,a);
			_used[a] = false;
		}
	}
}
int main() {
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	cin >> n;
	for (int i = 1; i<=n; i++)
		for (int j = 1; j<=n; j++)
			cin >> c[i][j];
	for (int j = 1; j<=n; j++)
		if (c[1][j] == '1') {
			_used[j] = true;
			dfs(1,j);
			_used[j] = false;
		}
	cout << suc << endl;
	return 0;
}
