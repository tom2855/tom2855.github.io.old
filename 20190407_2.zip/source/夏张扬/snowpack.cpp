#include<bits/stdc++.h>
using namespace std;
int a,b,c,ans;
int main() {
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	cin>>a>>b;
	c=b-a;
	for(int i=0; i<=c; i++) {
		ans+=i;
	}
	ans-=b;
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
