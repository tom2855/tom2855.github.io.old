#include<bits/stdc++.h>
using namespace std;
int n,a[20],num;
bool flag;
int main(){
	freopen("carry.in","r",stdin);
	freopen("carry.out","w",stdout);
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	for(int i=0;i<n;i++){
		flag=true;
		for(int j=0;j<n-1;j++){
			if(a[j]>a[j+1]){
				swap(a[j],a[j+1]);
				flag=false;
				num++;
			}
			if(flag) break;
		}
	}
	cout<<num;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
