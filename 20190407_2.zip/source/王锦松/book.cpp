#include<bits/stdc++.h>
using namespace std;
int n,a[20],b[20],ans=1;
int main(){
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	cin>>n;
	for(int j=1;j<=n;j++){
		cin>>a[j];
		if(a[j]==1)
			b[j]++;
	}
	for(int i=1;i<=n;i++)
		if(b[i]==1){
			cout<<1<<endl;
			return 0;
		}
	for(int i=1;i<=n;i++)
		ans=ans*b[i];
	cout<<1<<endl;
	return 0;
}
