#include<bits/stdc++.h>
using namespace std;
long long n,a[1000000],ans;
int main(){
	freopen("harm.in","r",stdin);
	freopen("harm.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n*n;i++)
		cin>>a[i];
	sort(a,a+n*n+1);
	for(int i=1;i<=n+n-1;i++)
		ans+=a[i];
	cout<<ans<<endl;
	return 0;
}
