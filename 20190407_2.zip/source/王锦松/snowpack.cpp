#include<bits/stdc++.h>
using namespace std;
int a,b;
int main(){
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	cin >> a >> b;
	for(int i = 1;i <= a;i++)
		for(int j=1;j<=a;j++)
		if(a+i == (1+j)*j/2 && b+i == (2+j)*(j+1)/2){
			cout << i << endl;
			return 0; 
		}
}
