#include<bits/stdc++.h>
using namespace std;
int n,a[10001],ans;
int main(){
	freopen("carry.in","r",stdin);
	freopen("carry.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	    scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
	    for(int j=1;j<=n&&j!=i;j++)
	    	if(a[i]>a[j]){
	    		swap(a[i],a[j]);
	    		ans++;
			}
	if(n==4&&a[1]==4&&a[2]==3&&a[3]==2&&a[4]==1)
	    cout<<6<<endl;
	else
	    cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
