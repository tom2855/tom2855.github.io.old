#include<bits/stdc++.h>
using namespace std;
int a,b,h[1000];
int main(){
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	cin>>a>>b;
	for(int i=1;i<=999;i++)
	    h[i]=h[i-1]+i;
	for(int i=1;i<999;i++)
	    if(h[i]-a==h[i+1]-b){
	    	cout<<h[i]-a<<endl;
	    	break;
		}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
