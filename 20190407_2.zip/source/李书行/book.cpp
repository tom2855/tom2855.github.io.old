#include<bits/stdc++.h>
using namespace std;
int n,ans;
char a[21][21];
bool b[21];
void dfs(int y){
	if(y==n+1){
		ans++;
		return;
	}
	for(int i=1;i<=n;i++)
		if(a[i][y]=='1'&&!b[i]){
			b[i]=true;
			dfs(y+1);
			b[i]=false;
		}
}
int main(){
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	    for(int j=1;j<=n;j++)
	        cin>>a[i][j];
	dfs(1);
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
