#include<bits/stdc++.h>
using namespace std;
int a[10005],ans;
int main(){
	freopen("carry.in","r",stdin);
	freopen("carry.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<n;i++){
		for(int j=1;j<=n-i;j++){
			if(a[j]>a[j+1]){
				swap(a[j],a[j+1]);
				ans++;
			}
		}

	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
