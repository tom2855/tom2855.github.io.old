#include<bits/stdc++.h>
using namespace std;
int a[25],b[25];
int main(){
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	int n;
	cin>>n;
	int m=30;
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++){
			char c;
			cin>>c;
			a[i]+=(c-'0');
			b[j]+=(c-'0');
		}
	for(int i=0;i<n;i++) m=min(m,min(a[i],b[i]));
	cout<<m;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
