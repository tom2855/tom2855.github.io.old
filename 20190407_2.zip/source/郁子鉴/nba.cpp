#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("nba.in","r",stdin);
	freopen("nba.out","w",stdout);
	int n;
	cin>>n;
	set<string> y;
	string s[55][2]; 
	for(int i=0;i<n;i++){
		cin>>s[i][0]>>s[i][1];
		y.insert(s[i][1]);
	}
	set<string>::iterator it;
	for(it=y.begin();it!=y.end();it++){
		bool f=1;
		for(int i=0;i<n;i++){
			if(s[i][1]==*it){
				cout<<*it<<' '<<s[i][0]<<endl;
				f=0;
			}
			if(!f) break;
		}
	}
	return 0;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
