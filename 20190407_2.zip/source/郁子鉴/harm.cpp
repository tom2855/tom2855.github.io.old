#include<bits/stdc++.h>
using namespace std;
int a[1005][1005];
int n;
long long mans=1000^3+5;
int dx[2]={1,0},dy[2]={0,1};
bool check(int i,int j){
	if(i<0||i>=n) return 0;
	if(j<0||j>=n) return 0;
	if(a[i][j]==-1) return 0;
	return 1;
}
void dfs(int x,int y,long long ans){
	if(ans>=mans) return;
	if(x==n-1&&y==n-1) mans=min(mans,ans);
	else{
		for(int i=0;i<2;i++){
			int nx=x+dx[i];
			int ny=y+dy[i];
			if(check(nx,ny)){
				int t=a[x][y];
				a[x][y]=-1;
				dfs(nx,ny,ans+a[nx][ny]);
				a[x][y]=t;
			}
		}
	}
	return;
}
int main(){
	freopen("harm.in","r",stdin);
	freopen("harm.out","w",stdout);
	cin>>n;
	for(int i=0;i<n;i++) for(int j=0;j<n;j++) cin>>a[i][j];
	dfs(0,0,a[0][0]);
	cout<<mans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
