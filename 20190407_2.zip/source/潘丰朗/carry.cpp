#include<bits/stdc++.h>
using namespace std;
int n,m[10005],s[10005];
int main(){
	freopen("carry.in","r",stdin);
	freopen("carry.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>m[i];
	}
	for(int i=1;i<=n;i++){
		s[i]=s[i-1]+i;
	}
	cout<<s[n-1];
	return 0;
}
