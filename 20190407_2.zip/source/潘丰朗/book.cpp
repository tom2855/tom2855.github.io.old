#include<bits/stdc++.h>
using namespace std;
int n,s;
char a[21][21];
bool b[21];
void dfs(int x){
	if(x==n+1){
		s++;
		return;
	}
	for(int i=1;i<=n;i++)
		if(a[i][x]=='1'&&!b[i]){
			b[i]=true;
			dfs(x+1);
			b[i]=false;
		}
}
int main(){
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	    for(int j=1;j<=n;j++)
	        cin>>a[i][j];
	dfs(1);
	cout<<s<<endl;
	return 0;
}
