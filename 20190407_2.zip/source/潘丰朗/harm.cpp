#include<bits/stdc++.h>
using namespace std;
int n,m[1001][1001],opt[1001][1001];
int main(){
	freopen("harm.in","r",stdin);
	freopen("harm.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	    for(int j=1;j<=n;j++)
	        cin>>m[i][j];
	for(int i=1;i<=n;i++)
	    for(int j=1;j<=n;j++)
	        if(opt[i][j-1]&&opt[i-1][j])
	            opt[i][j]=min(opt[i][j-1],opt[i-1][j])+m[i][j];
	        else
	            opt[i][j]=max(opt[i][j-1],opt[i-1][j])+m[i][j];
	cout<<opt[n][n]<<endl;
	return 0;
}
