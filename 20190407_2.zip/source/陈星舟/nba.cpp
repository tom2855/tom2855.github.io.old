#include<bits/stdc++.h>
using namespace std;
int n;
char ch;
struct node{
	int time;
	string name;
	bool operator <(const node x) const{
		return time<x.time;
	}
}a[55];
int main(){
    freopen("nba.in","r",stdin);
    freopen("nba.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i].name;
		ch=getchar();
		cin>>a[i].time;
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=n;i++)
	    cout<<a[i].time<<' '<<a[i].name<<endl;
}
