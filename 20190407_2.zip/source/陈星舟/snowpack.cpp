#include<bits/stdc++.h>
using namespace std;
int a,b,h[500000];
int main(){
    freopen("snowpack.in","r",stdin);
    freopen("snowpack.out","w",stdout);
	cin>>a>>b;
	int step=0;
	for(int i=1;i<=999;i++)
	{
		h[i+step]=1;
		step=i+step;
	}
	int i;
	for(i=1;i<=999;i++){
		if(h[a+i]&&h[b+i]) break;
	}
	cout<<i<<endl;
	return 0;
}
