#include<bits/stdc++.h>
using namespace std;
int n,_map[1005][1005],opt[1005][1005];
int main() {
	freopen("harm.in","r",stdin);
	freopen("harm.out","w",stdout);
	cin>>n;
	for(int i=0; i<=n+1; i++)
		for(int j=0; j<=n+1; j++)
			opt[i][j]=1005;

	for(int i=1; i<=n; i++)
		for(int j=1; j<=n; j++)
			cin>>_map[i][j];
	for(int i=1; i<=n; i++)
		for(int j=1; j<=n; j++) {
			opt[i][j]=min(opt[i-1][j],opt[i][j-1])+_map[i][j];
			opt[1][1]=_map[1][1];
		}
	cout<<opt[n][n]<<endl;
}
