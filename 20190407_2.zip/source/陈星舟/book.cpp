#include<bits/stdc++.h>
using namespace std;
int n,ans;
bool like[25][25];
bool had[25];
char ch;
void dfs(int book) {
	for(int i=1; i<=n; i++) {
		if(like[i][book]&&!had[i]) {
			if(book==n) ans++;
			else {
				had[i]=true;
				dfs(book+1);
				had[i]=false;
			}
		}
	}
}
int main() {
    freopen("book.in","r",stdin);
    freopen("book.out","w",stdout);
	string s;
	cin>>n;
	for(int i=1; i<=n; i++) {
		cin>>s;
		for(int j=0; j<s.size(); j++)
			like[i][j+1]=s[j]-'0';
	}
	dfs(1);
	cout<<ans<<endl;
	return 0;
}
