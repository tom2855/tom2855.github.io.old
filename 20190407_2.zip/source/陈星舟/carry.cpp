#include<bits/stdc++.h>
using namespace std;
int n,a[10005],b[10005],c[10005],ans;
int main(){
    freopen("carry.in","r",stdin);
    freopen("carry.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		int x;
		cin>>x;
		a[x]=i;
		b[i]=x;
		c[i]=b[i];
	}
	sort(b+1,b+n+1);
	int tmp=n;
	while(tmp>1){
		ans+=b[tmp]-a[tmp];
		for(int i=a[tmp]+1;i<=b[tmp];i++)
		{
			a[c[i]]--;
		}
		tmp--;
	}
	cout<<ans<<endl;
}
