#include<bits/stdc++.h>
using namespace std;
struct nba{
	int time;
	string city;
}a[51];
int b[51],n;
int main(){
	freopen("nba.in","r",stdin);
	freopen("nba.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
        cin>>a[i].city>>a[i].time;
        b[i]=a[i].time;
	}
    sort(b+1,b+1+n);
    for(int i=1;i<=n;i++)
    	for(int j=1;j<=n;j++)
    	    if(b[i]==a[j].time){
    	    	cout<<b[i]<<" "<<a[j].city<<endl;
    	    	break;
			}
	return 0;	
}
