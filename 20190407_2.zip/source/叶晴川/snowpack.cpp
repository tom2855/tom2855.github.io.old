#include<bits/stdc++.h>
using namespace std;
int a,b,ans;
int main(){
     freopen("snowpack.in","r",stdin);
	 freopen("snowpack.out","w",stdout);  
	 cin>>a>>b;
	 for(int i=1;i<=b-a-1;i++){
	 	ans+=i;
	 }
	 cout<<ans-a<<endl;
	 return 0;
}
