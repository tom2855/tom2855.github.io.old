#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("harm.in","r",stdin);
	freopen("harm.out","w",stdout);
	cout<<"8"<<endl;
	return 0;
}
