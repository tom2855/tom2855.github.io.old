#include <bits/stdc++.h>
using namespace std;

bool want[25][25],vis[25];
int n,ans;

void dfs(int m,int b) {
	if(!want[m][b] || vis[b]) return ;
	if(m = 5) ans ++;
	else {
		vis[b] = true;
		for(int i = 1; i <= n; i ++) {
			dfs(m + 1,i);
		}
		vis[b] = false;		
	}
}

int main() {
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	cin >> n;
	for(int i = 1; i <= n; i ++)
		for(int j = 1; j <= n; j ++) {
			register char c;
			cin >> c;
			want[i][j] = c - '0';
		}
	want[0][0] = true;
	dfs(0,0);
	cout << ans << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
