#include <bits/stdc++.h>
using namespace std;

int n,_map[1005][1005],opt[1005][1005];

int main() {
	freopen("harm.in","r",stdin);
	freopen("harm.out","w",stdout);
	scanf("%d",&n);
	for(int i = 1; i <= n; i ++)
		for(int j = 1; j <= n; j ++) {
			scanf("%d",&_map[i][j]);
		}
	opt[1][1] = _map[1][1];
	for(int i = 1; i <= n; i ++)
		for(int j = 1; j <= n; j ++) {
			if(i == 1 && j == 1) continue;
			if(i == 1) {
				opt[i][j] = opt[i][j - 1] + _map[i][j];
				continue;
			}
			if(j == 1) {
				opt[i][j] = opt[i - 1][j] + _map[i][j];
				continue;
			} else opt[i][j] = min(opt[i - 1][j] + _map[i][j],opt[i][j - 1] + _map[i][j]);
		}
/*
	for(int i = 1; i <= n; i ++) {
		for(int j = 1; j <= n; j ++)
			cout << setw(5) << opt[i][j];
		cout << endl;
	}
*/
	cout << opt[n][n] << endl;
	return 0;
}
