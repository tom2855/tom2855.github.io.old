#include <bits/stdc++.h>
using namespace std;

struct _nba {
	string team;
	string year;
} nba[55];
int n;
stringstream stio;

bool cmp(_nba a,_nba b) {
	return a.year < b.year;
}

int main() {
	freopen("nba.in","r",stdin);
	freopen("nba.out","w",stdout);
	cin >> n;
	for(int i = 1;i <= n;i ++) {
		string tmp;
		while(cin >> tmp,isalpha(tmp[0])) {
			if(nba[i].team != "") nba[i].team += " ";
			nba[i].team += tmp;
		}
		nba[i].year = tmp;
	}
	sort(nba + 1,nba + n + 1,cmp);
	for(int i = 1;i <= n;i ++) printf("%s %s\n",nba[i].year.c_str(),nba[i].team.c_str());
	return 0;
}
