#include <bits/stdc++.h>
using namespace std;

int a,b,opt;

int main() {
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	cin >> a >> b;
	for(int i = 1;i <= b - a;i ++) opt += i;
	cout << opt - b << endl;
	fclose(stdin);
	fclose(stdout);
	return 0; 
}
