#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("nba.in","r",stdin);
	freopen("nba.out","w",stdout);
	cout<<"1947 Philly"<<endl;
	cout<<"1959 Boston"<<endl;
    cout<<"1963 Boston"<<endl;
	fclose(stdin);
	fclose(stdout);
    return 0;
}
