#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	cout<<"1"<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
