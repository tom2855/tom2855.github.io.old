#include<bits/stdc++.h>
using namespace std;
int a,b,c,d;
int main(){
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	cin>>a>>b;
	c=b-a;
	for(int i=1;i<=c;i++){
		d+=i;
	}
	cout<<d-b<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
