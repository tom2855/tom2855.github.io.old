#include<bits/stdc++.h>
using namespace std;
int n,grass[1010][1010],ans[1010][1010];
int main(){
	freopen("harm.in","r",stdin);
	freopen("harm.out","w",stdout);
	cin>>n;
	for(int i=2;i<=n;i++){
		ans[0][i]=ans[i][0]=INT_MAX;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			cin>>grass[i][j];
			ans[i][j]=min(ans[i-1][j],ans[i][j-1])+grass[i][j];
		}
	}
	cout<<ans[n][n]<<endl;
	return 0;
}
