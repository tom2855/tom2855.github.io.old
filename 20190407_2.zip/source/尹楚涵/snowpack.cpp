#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	int a,b,ans,c;
	cin>>a>>b;
	c=b-a;
	ans=(c*(c+1)/2)-b;
	cout<<ans<<endl;
	return 0;
}
