#include<bits/stdc++.h>
using namespace std;
struct win{
	int year=0;
	string name;
}w[55],w2[2050];
int main(){
	freopen("nba.in","r",stdin);
	freopen("nba.out","w",stdout);
	int n,y;
	string na;
	cin>>n;
	/*
	for(int i=1;i<=n;i++){
		cin>>w[i].name>>w[i].year;
		//scanf("\n");
	}
	for(int i=1;i<=n-1;i++){
		for(int j=1;j<=n-i;j++){
			if(w[j].year>w[j+1].year){
				swap(w[j],w[j+1]);
			}
		}
	}
	*/
	for(int i=1;i<=n;i++){
		cin>>na>>y;
		w2[y].year=y;
		w2[y].name=na;
	}
	for(int i=1940;i<=2020;i++){
		if(w2[i].year!=0)cout<<w2[i].year<<" "<<w2[i].name<<endl;
	}
//	cout<<w[i].year<<" "<<w[i].name<<endl;
	return 0;
}
