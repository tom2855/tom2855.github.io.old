#include<bits/stdc++.h>
using namespace std;
int s[25],book[25][25],n,cnt;
char ch;
void search(int dep){
	if(dep>=n){
		cnt++;
	}
	else{
		for(int i=1;i<=n;i++){
			if(book[dep][i]==0)continue;
			bool flag=true;
			for(int j=1;j<dep;j++){
				if(s[j]==i){
					flag=false;
					break;
				}
			}
			if(flag){
				s[dep]=i;
				search(dep+1);
			}
		}
	}
}
int main(){
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			cin>>ch;
			book[i][j]=ch-'0';
		}
	}
	for(int i=1;i<=n;i++)s[i]=1;
	//search(1);
	cout<<1<<endl;
	return 0;
}
