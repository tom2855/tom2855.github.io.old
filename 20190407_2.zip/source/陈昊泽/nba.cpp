#include<bits/stdc++.h>
using namespace std;
int N;
struct node{
	string c;
	int y;
}nba[51];
bool mycmp(node a,node b){
	return a.y<b.y;
}
int main(){
	freopen("nba.in","r",stdin);
	freopen("nba.out","w",stdout);
	cin>>N;
	for(int i=1;i<=N;i++)
		cin>>nba[i].c>>nba[i].y;
	sort(nba+1,nba+N+1,mycmp);
	for(int i=1;i<=N;i++)
		cout<<nba[i].y<<' '<<nba[i].c<<endl;
	
	return 0;
}
