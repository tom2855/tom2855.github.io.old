#include<bits/stdc++.h>
using namespace std;
int N,tmp,ans;
bool Map[21][21],book[21];
void go(int p){
	if(p==N+1){
		++ans;
		return;
	}
	for(int i=1;i<=N;++i)
		if(!book[i]&&Map[p][i]){
			book[i]=true;
			go(p+1);
			book[i]=false;
		}
}
int main(){
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	scanf("%d",&N);
	for(int i=1;i<=N;++i)
		for(int j=1;j<=N;++j){
			scanf("%1d",&tmp);
			Map[i][j]=tmp;
		}
	
	go(1);
	
	printf("%d\n",ans);
	return 0;
}
