#include<bits/stdc++.h>
using namespace std;
long long a,b;
int main(){
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	scanf("%lld%lld",&a,&b);
	printf("%lld\n",(b-a)*(b-a+1)/2-b);
	return 0;
}
