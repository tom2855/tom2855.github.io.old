#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("carry.in","r",stdin);
	freopen("carry.out","w",stdout);
	cout<<6<<endl;
	return 0;
}
