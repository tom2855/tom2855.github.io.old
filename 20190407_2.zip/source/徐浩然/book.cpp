#include<bits/stdc++.h>
using namespace std;
char a[25][25];
int n,used[25][25],ans;
void check(int x,int y){
	for(int i = 1; i <= n; i++){
		used[x][i] = 1;
		used[i][y] = 1;
	}
}
void rub(int x,int y){
	for(int i = 1; i <= n; i++){
		used[x][i] = 0;
		used[i][y] = 0;
	}
}
void dfs(int x,int y,int s){
//	cout<<x<<" "<<y<<endl;
	used[x][y] = 1;
	check(x,y);
	if(s == n){
		ans++;
		//used[x][y] = 0 ;
	   // rub(x,y);
	    s = 0;
	    return;
	}
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= n ; j++){
			if(a[i][j] == '1' and used[i][j] == 0){
			     s++;
				 dfs(i,j,s);
			}
		}
	}
//	used[x][y] = 0;
}
int main(){
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	cin>>n;
	for(int i = 1; i <= n ; i++){
		for(int j = 1; j <= n ; j++){
			cin>>a[i][j];
		}
	}
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= n ; j++){
			if(a[i][j] == '1' and used[i][j] == 0){
			     dfs(i,j,1);
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}
