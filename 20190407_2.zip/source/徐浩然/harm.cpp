#include<bits/stdc++.h>
using namespace std;
int n,used[1005][1005],a[1005][1005];
int dx[2] = {0,1};
int dy[2] = {1,0};
long long ans = 1000000005;
void dfs(int x,int y,long long s){
	used[x][y] = 1;
	if(x == n and y == n){
		ans = min(ans,s);
		used[x][y] = 0;
		return; 
	}
	for(int i = 0; i < 2; i++){
		int nx = x + dx[i];
		int ny = y + dy[i];
		if(nx >= 1 and nx <= n and ny >= 1 and ny <= n and used[nx][ny] == 0){
			
			dfs(nx,ny,s + a[nx][ny]);
		}
	}
	used[x][y] = 0;
}
int main(){
	freopen("harm.in","r",stdin);
	freopen("harm.out","w",stdout);
	cin>>n;
	for(int i = 1; i <= n ; i++){
		for(int j = 1; j <= n ; j++){
			cin>>a[i][j];
		}
	}
	dfs(1,1,a[1][1]);
	cout<<ans<<endl;
	return 0;
	
	
}
