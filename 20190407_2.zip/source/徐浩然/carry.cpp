#include<bits/stdc++.h>
using namespace std;
int n,a[10005],ans;
int main() {
	freopen("carry.in","r",stdin);
	freopen("carry.out","w",stdout);
	cin>>n;
	for(int i = 1 ; i <= n; i++) {
		cin>>a[i];
	}
	for(int i = 1; i <= n - 1; i++) {
		for(int j = 1; j <= n - 1; j++) {
			if(a[j] > a[j + 1]) {
				swap(a[j],a[j+1]);
				ans++;
			}
		}
	}
	cout<<ans<<endl;
	return 0;

}
