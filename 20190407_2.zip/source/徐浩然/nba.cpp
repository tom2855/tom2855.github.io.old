#include<bits/stdc++.h>
using namespace std;
struct node{
	int num;
	string s;
}a[55];
int n;
bool cmp(node x,node y){
	 return x.num < y.num;
}
int main(){
	freopen("nba.in","r",stdin);
	freopen("nba.out","w",stdout);
	cin>>n;
	for(int i = 1; i <= n ; i++){
	    cin>>a[i].s>>a[i].num;
	}
	sort(a + 1 , a + n + 1, cmp);
	for(int i = 1; i <= n ; i++){
		for(int j = i + 1; j <= n ; j++){
			if(a[i].num == a[j].num){
				a[i].num = 0;
			}
		}
	}
	for(int i = 1; i <= n ; i++){
		if(a[i].num != 0 ) cout<<a[i].num<<" "<<a[i].s<<endl;
	}
    return 0;
}
