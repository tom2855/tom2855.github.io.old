#include<bits/stdc++.h>
using namespace std;

int a,b;
int c[1005],ans;
int main(){
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	cin>>a>>b;
	c[1] = 1;
	for(int i = 1; i <= 999; i++){
		 for(int j = 1; j <= i; j++){
		 	c[i] = c[j] + i;
		 }
	}
	for(int i = 1; i <= 999 ; i++){
		 c[i] = c[i] / 2;
		// cout<<c[i] <<endl;
	}
	for(int i = 1; i <= 999 ; i++){
	     for(int j = i + 1; j <= 999;j++){
	     	if(c[i] - a == c[j] - b) ans = c[i] - a;
		 }
	}
	cout<<ans<<endl;
	   
	return 0;
	
}
