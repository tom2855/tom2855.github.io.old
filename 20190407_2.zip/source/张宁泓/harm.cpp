#include<bits/stdc++.h>
#define Maxn 100000000
using namespace std;
int s=1,s1,_map[1005][1005],n,grass,ans=Maxn,grass1[100000001],wnzj[100000001];
int dx[2]= {0,1};
int dy[2]= {1,0};
int dfs(int x,int y) {
	grass+=_map[x][y];
	if(x==n&&y==n) {
		ans=min(ans,grass);
		grass1[s++]=grass;
		grass=0;
	}
	for(int k=0; k<2; k++) {
		int nx=x+dx[k];
		int ny=y+dy[k];
		if(nx<=n&&ny<=n) dfs(nx,ny);
	}
}


int main() {
	freopen("harm.in","r",stdin);
	freopen("harm.out","w",stdout);
	cin>>n;
	for(int i=1; i<=n; i++) {
		for(int j=1; j<=n; j++) {
			cin>>_map[i][j];
			wnzj[++s1]=_map[i][j];
		}
	}
	dfs(1,1);
	  cout<<grass1[n+1]<<endl;
}
