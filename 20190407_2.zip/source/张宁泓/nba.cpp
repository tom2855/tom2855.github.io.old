#include<bits/stdc++.h>
using namespace std;
int n,year[55],tmp;
string name[55],stmp;
int main(){
	freopen("nba.in","r",stdin);
	freopen("nba.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>name[i]>>year[i];
	}
	for(int i=1;i<=n;i++){
		if(year[i]<year[i+1]&&i+1<=n){
			tmp=year[i];
			year[i]=year[i+1];
			year[i+1]=tmp;
			
			stmp=name[i];
			name[i]=name[i+1];
			name[i+1]=stmp;
		}
	}
	for(int i=n;i>0;i--){
		cout<<year[i]<<" "<<name[i]<<endl;
	}
	return 0;
	fclose(stdin);
	fclose(stdout);
}
