#include<bits/stdc++.h>
using namespace std;
int n,i,a[10005],ans,b=1,c;
bool x=true;
int main() {
	freopen("carry.in","r",stdin);
	freopen("carry.out","w",stdout);
	cin>>n;
	for(i=1; i<=n; i++)
		cin>>a[i];
	while(b=1) {
		i=1;
		x=true;
		for(i=1; i<n; i++) {
			if(a[i]>a[i+1]) {
				swap(a[i],a[i+1]);
				ans++;
			}
		}
		for(int j=1; j<n; j++)
			if(a[j]+1!=a[j+1])x=false;
		if(x=true)break;
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
