#include<bits/stdc++.h>
using namespace std;
int n,a[25][25],s[25],ans=1,b[25];
bool x=true;
int main(){
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>b[i];
		for(int j=1;j<=n;j++)
		a[i][j]=b[i]/((n-j+1)*10);
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(i!=1)
				for(int k=i;k>=1;k--)
					if(a[k][j]==1)x=false;
			if(x)s[i]=s[i]+a[i][j];
		}
		ans=s[i]*ans;
		x=true;
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
