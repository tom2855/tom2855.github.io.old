#include<bits/stdc++.h>
using namespace std;
int a,b,s;
int main(){
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	cin>>a>>b;
	for(int i=1;i<=b-a;i++)
		s=s+i;
	cout<<s-b<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
