#include<bits/stdc++.h>
using namespace std;
int a,b,t,r,i=1;
int main() {
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	cin>>a>>b;
	while(r<a) {
		r+=i;
		i++;
	}
	cout<<r-a<<endl;
	return 0;
}
