#include<bits/stdc++.h>
using namespace std;
struct q {
	string name;
	int time;
} que[60];
int n;
int main() {
	freopen("nba.in","r",stdin);
	freopen("nba.out","w",stdout);
	cin>>n;
	for(int i=1; i<=n; i++) {
		cin>>que[i].name ;
		cin>>que[i].time ;
	}
	for(int i=1; i<=n; i++) {
		for(int j=1; j<i; j++) {
			if(que[i].time<que[j].time) swap(que[i],que[j]);
		}
	}
	for(int i=1; i<=n; i++) {
		cout<<que[i].time<<" "<<que[i].name<<endl;
	}
	return 0;
}
