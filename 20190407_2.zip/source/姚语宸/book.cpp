#include<bits/stdc++.h>
using namespace std;
int n,ans;
char num[50][50];
bool book[25];
void dfs(int p,int bn) {
	if(bn==n) {
		ans++;
		return ;
	} else {
		for(int i=1; i<=n; i++) {
			if(num[p][i]=='1'&&book[i]==false) {
				book[i]=true;
				dfs(p+1,bn+1);
				book[i]=false;
			}
		}
		return ;
	}
}
int main() {
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	cin>>n;
	for(int i=1; i<=n; i++)
		book[i]=false;
	for(int i=1; i<=n; i++) {
		for(int j=1; j<=n; j++) {
			cin>>num[i][j];
		}
	}
	dfs(1,0);
	cout<<ans<<endl;
	return 0;
}
