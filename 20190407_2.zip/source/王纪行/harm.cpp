#include<bits/stdc++.h>
using namespace std;
int n,a[1009][1009],opt[1009][1009];
int main() {
	freopen("harm.in","r",stdin);
	freopen("harm.out","w",stdout);
	cin >> n;
	for(int i = 1;i <= n;i++){
		for(int j = 1;j <= n;j++){
			cin >> a[i][j];
		}
	}
	for(int i = 1;i <= n;i++){
		opt[i][0] = INT_MAX / 2;
		opt[0][i] = opt[i][0];
	}
	opt[1][1] = a[1][1];
	for(int i = 1;i <= n;i++){
		for(int j = 1;j <= n;j++){
			if(i == 1 && j == 1)continue;
			opt[i][j] = min(opt[i][j - 1],opt[i - 1][j]) + a[i][j];
		}
	}
	cout << opt[n][n] << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
