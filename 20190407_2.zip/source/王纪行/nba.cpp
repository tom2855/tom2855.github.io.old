#include<bits/stdc++.h>
using namespace std;
int n;
string x;
struct win{
	string city;
	int t;
}a[100];
bool cmp(win p,win q){
	return p.t < q.t;
}
int main() {
	freopen("nba.in","r",stdin);
	freopen("nba.out","w",stdout);
	cin >> n;
	for(int i = 1;i <= n;i++){
		while(cin >> x){
			if(x[0] >= '0' && x[0] <= '9')break;
			a[i].city += ' ';
			a[i].city += x;
		}
		for(int j = 0;j < 4;j++){
			a[i].t *= 10;
			a[i].t += x[j] - '0';
		}
	}
	sort(a + 1,a + 1 + n,cmp);
	for(int i = 1;i <= n;i++){
		cout << a[i].t << a[i].city << endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
