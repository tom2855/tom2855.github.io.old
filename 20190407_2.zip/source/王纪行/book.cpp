#include<bits/stdc++.h>
using namespace std;
int n,ans;
char a[40][40];
bool vis[30];
void dfs(int step){
	if(step > n){
		ans++;
		return ;
	}
	for(int i = 1;i <= n;i++){
		if(a[step][i] == '1' && !vis[i]){
			vis[i] = true;
			dfs(step + 1);
			vis[i] = false;
		}
	}
}
int main() {
	freopen("book.in","r",stdin);
	freopen("book.out","w",stdout);
	cin >> n;
	for(int i = 1;i <= n;i++){
		for(int j = 1;j <= n;j++){
			cin >> a[i][j];
		}
	}
	dfs(1);
	cout << ans << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
