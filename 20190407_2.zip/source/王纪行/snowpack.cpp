#include<bits/stdc++.h>
using namespace std;
int a,b,cnt;
bool t[500500];
int main() {
	freopen("snowpack.in","r",stdin);
	freopen("snowpack.out","w",stdout);
	cin >> a >> b;
	for(int i = 1;i <= 999;i++){
		cnt += i;
		t[cnt] = true;
	}
	for(int i = 1;i <= 999;i++){
		if(a + i > 499500 || b + i > 499500)break;
		if(t[a + i] && t[b + i]){
			cout << i << endl;
			break;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
