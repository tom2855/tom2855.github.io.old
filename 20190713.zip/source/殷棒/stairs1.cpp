#include<bits/stdc++.h>
using namespace std;
int n,opt[35];
int main(){
	freopen("stairs1.in","r",stdin);
	freopen("stairs1.out","w",stdout);
	cin >> n;
	opt[1] = 1;
	opt[2] = 2;
	for(int i = 3;i <= n;i++){
		opt[i] = opt[i - 1] + opt[i - 2];
	}
	cout << opt[n] << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
