#include<bits/stdc++.h>
using namespace std;
int n,m,x,y,ans[25][25];
int dx[9] = {0,-1, 1,-2, 2,-2,2,-1,1};
int dy[9] = {0,-2,-2,-1,-1, 1,1, 2,2};
bool vis[25][25];
int main(){
	freopen("solider.in","r",stdin);
	freopen("solider.out","w",stdout);
	cin >> n >> m >> x >> y;
	memset(vis,true,sizeof(vis));
	for(int k = 0;k < 9;k++){
		int nx = x + dx[k];
		int ny = y + dy[k];
		if(nx >= 0 && nx <= n && ny >= 0 && ny <= m){
			vis[nx][ny] = false;
		}
	}
	ans[0][0] = 1;
	for(int j = 1;j <= m;j++){
		if(vis[0][j]){
			ans[0][j] = ans[0][j - 1];
		}
	}
	for(int i = 1;i <= n;i++){
		if(vis[i][0]){
			ans[i][0] = ans[i - 1][0];
		}
	}
	for(int i = 1;i <= n;i++){
		for(int j = 1;j <= m;j++){
			if(vis[i][j]){
				ans[i][j] = ans[i - 1][j] + ans[i][j - 1];
			}
		
		}
	}
	cout << ans[n][m] << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
