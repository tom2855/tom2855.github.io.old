#include<bits/stdc++.h>
using namespace std;
int n,ans;
int opt[100005];
void dfs(int x){
	if(opt[x]) ans+=opt[x];
	else{
		ans++;
		int c=x/2;
		int anss=ans;
		for(register int i=1;i<=c;i++){
			dfs(i);
			opt[x]=ans-anss+1;
		}
	}
	return;
}
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	dfs(n);
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
