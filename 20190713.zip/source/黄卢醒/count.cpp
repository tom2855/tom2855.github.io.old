#include<bits/stdc++.h>
using namespace std;
int n,num[1005];
int main() {
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	num[0]=1;
	num[1]=1;
	for(int i=2; i<=n; i++) {
		for(int j=0; j<=i/2; j++) {
			num[i]+=num[j];
		}
	}
	cout<<num[n];
	return 0;
}
