#include<bits/stdc++.h>
using namespace std;
int n,m,num[25][25],x,y,vis[25][25],nx,ny;
int dx[9]= {0,1,2,-1,-2, 1, 2,-1,-2};
int dy[9]= {0,2,1,-2,-1,-2,-1, 2, 1};
int main() {
	freopen("solider.in","r",stdin);
	freopen("solider.out","w",stdout);
	cin>>n>>m>>x>>y;
	for(int i=0; i<=8; i++) {
		nx=x+dx[i];
		ny=y+dy[i];
		if(nx>=0&&ny>=0&&nx<=n&&ny<=m) {
			vis[nx][ny]=-1;
		}
	}
	for(int i=0; i<=n; i++) {
		num[i][0]=1;
		if(vis[i][0]==-1) {
			num[i][0]=0;
			break;
		}
	}
	for(int j=0; j<=n; j++) {
		num[0][j]=1;
		if(vis[0][j]==-1) {
			num[0][j]=0;
			break;
		}
	}
	for(int i=1; i<=n; i++) {
		for(int j=1; j<=m; j++) {
			num[i][j]=num[i-1][j]+num[i][j-1];
			if(vis[i][j]==-1) num[i][j]=0;
		}
	}
	cout<<num[n][m];
	return 0;
}
