#include<bits/stdc++.h>
using namespace std;
int n,num[10001],jw=0,k;
int main() {
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	cin>>n;
	num[1000]=2;
	for(int i=2; i<=n; i++) {
		for(int j=1000; j>=1; j--) {
			num[j]=num[j]*2+jw;
			jw=num[j];
			num[j]=jw%10;
			jw=jw/10;
		}
		num[1000]=num[1000]+2;
		if(num[1000]==10) {
			num[1000]=0;
			num[999]++;
		}
	}
	for(k=1; k<=1000; k++) {
		if(num[k]>0){
			break;
		}
	}
	for(int i=k;i<=1000;i++)
		cout<<num[i];
	return 0;
}
