#include<bits/stdc++.h>
using namespace std;
int n,num[35];
int main(){
	freopen("stairs1.in","r",stdin);
	freopen("stairs1.out","w",stdout);
	cin>>n;
	num[1]=1;
	num[2]=2;
	for(int i=3;i<=n;i++)
		num[i]=num[i-1]+num[i-2];
	cout<<num[n];
	return 0;
}
