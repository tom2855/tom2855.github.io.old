#include<bits/stdc++.h>
using namespace std;
int n,m,num[35][35];
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m;
	num[0][1]=1;
	for(int i=1;i<=m;i++){
		for(int j=2;j<n;j++){
			num[i][j]=num[i-1][j-1]+num[i-1][j+1];
		}
		num[i][n]=num[i-1][1]+num[i-1][n-1];
		num[i][1]=num[i-1][n]+num[i-1][2];
	}
		
	cout<<num[m][1];
	return 0;
}
