#include<bits/stdc++.h>
using namespace std;
int n,ans,data[31];
int main(){
	freopen("stairs1.in","r",stdin);
	freopen("stairs1.out","w",stdout);
	cin>>n;
	data[1]=1;
	data[2]=2;
	for(int i=3;i<=n;i++)
	  data[i]=data[i-1]+data[i-2];
	cout<<data[n]<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
