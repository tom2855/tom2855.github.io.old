#include<bits/stdc++.h>
using namespace std;
int n,data[205];
int main(){
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		data[i]=i*(i+1);
	}
	cout<<data[n]<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
