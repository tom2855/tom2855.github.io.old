#include<bits/stdc++.h>
using namespace std;
int m,n,ball[35],ans;
int give(int t,int x) {
	if(t==m) {
		if(x==1) ans++;
	} else {
			if(x==1) {
				give(t+1,x+1);
				give(t+1,n);
			}
			if(x==n) {
				give(t+1,x-1);
				give(t+1,1);
			}
			if(x!=1&&x!=n) {
				give(t+1,x-1);
				give(t+1,x+1);
		   }

	}
}
int main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m;
	ball[1]=1;
	if(n==m) ans=2;
    else give(0,1);
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
