#include<bits/stdc++.h>
using namespace std;
int n,opt[1005];
int main() {
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	
	scanf("%d",&n);
	opt[0] = opt[1] = 1;
	for(int i = 2;i <= n;++i)
	for(int j = 0;j <= i >> 1;++j)
	opt[i] += opt[j];
	cout << opt[n] << endl;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
