#include<bits/stdc++.h>
using namespace std;
int dx[8] = { 1, 2, 2, 1,-1,-2,-2,-1};
int dy[8] = {-2,-1, 1, 2, 2, 1,-1,-2};
int n,m,x,y;
long long opt[30][30];
bool hor[30][30];
int main() {
	freopen("solider.in","r",stdin);
	freopen("solider.out","w",stdout);
	
	scanf("%d%d%d%d",&n,&m,&x,&y);
	hor[x][y] = true;
	for(int i = 0;i < 8;++i) {
		int nx = x + dx[i];
		int ny = y + dy[i];
		if(nx > n || nx < 0 || ny > m || ny < 0) continue;
		hor[nx][ny] = true;
	}
	if(hor[0][0]) {
		cout << 0 << endl;
		return 0;
	}
	opt[0][0] = 1;
	for(int i = 1;i <= n;++i){
		if(hor[i][0]) continue;
		opt[i][0] = opt[i - 1][0];
	}
	for(int i = 1;i <= n;++i){ 
		if(hor[0][i]) continue;
		opt[0][i] = opt[0][i - 1];
	}
	for(int i = 1;i <= n;++i){
		for(int j = 1;j <= m;++j) {
			if(hor[i][j]) opt[i][j] = 0;
			else opt[i][j] = opt[i - 1][j] + opt[i][j - 1];
		}
	}
	cout << opt[n][m] << endl;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
