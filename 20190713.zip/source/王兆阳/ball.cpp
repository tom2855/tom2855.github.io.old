#include<bits/stdc++.h>
using namespace std;
int n,m,opt[50][50];
int main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	opt[0][1] = 1;
	for(int i = 1;i <= m;++i)
	for(int j = 1;j <= n;++j) {
		if(j == 1)
		opt[i][j] = opt[i - 1][j + 1] + opt[i - 1][n];
		else if(j == n)
		opt[i][j] = opt[i - 1][1] + opt[i - 1][j - 1];
		else
		opt[i][j] = opt[i - 1][j + 1] + opt[i - 1][j - 1];
	}
	cout << opt[m][1] << endl;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
