#include<bits/stdc++.h>
using namespace std;
int n,ans,opt[1000000],tot;
void work() {
	bool add = 0;
	int i = -1;
	while(opt[++i] == 9) {
		opt[i] = 1;
	}
	++opt[i];
	if(i > tot) tot = i;
	for(i = 0;i <= tot || add;++i) {
		int tmp = opt[i];
		opt[i] = ((opt[i] << 1) + add) % 10;
		if((tmp << 1) > 9) add = 1;
		else add = 0;
	}
	if(i - 1 > tot) tot = i - 1;
}
int main() {
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	
	scanf("%d",&n);
	opt[0] = 2;
	for(int i = 2;i <= n;++i)
	work();
	for(int i = tot;i >= 0;--i)
	cout << opt[i];
	cout << endl;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
