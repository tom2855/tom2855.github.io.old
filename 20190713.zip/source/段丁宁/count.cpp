#include<bits/stdc++.h>
using namespace std;
int n,sum=0;
void fj(int n) {
	sum++;
	for(int i=1; i<=n/2; i++) {
		fj(i);
	}
}
int main() {
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	fj(n);
	cout<<sum<<endl;
}
