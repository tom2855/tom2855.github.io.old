#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	unsigned long long n,s=1;
	cin>>n;
	for(int i=1; i<=n; i++) {
		s=s*2;
	}
	s--;
	s=s*2;
	cout<<s<<endl;
	return 0;
}
