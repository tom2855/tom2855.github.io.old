#include<bits/stdc++.h>
using namespace std;
int n,m,opt[35][35];
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m;
    opt[1][0]=1;
	for(int i=1;i<=m;i++){
		opt[1][i]=opt[n][i-1]+opt[2][i-1];
		for(int j=2;j<n;j++){
            opt[j][i]=opt[j-1][i-1]+opt[j+1][i-1];
		}
		opt[n][i]=opt[n-1][i-1]+opt[1][i-1];
	}
	cout<<opt[1][m];
}
