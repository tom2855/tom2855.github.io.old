#include<bits/stdc++.h>
using namespace std;
int n,m,x,y,opt[25][25];
bool _map[25][25];
int dx[8]={1,1,2,2,-1,-1,-2,-2};
int dy[8]={2,-2,1,-1,2,-2,1,-1};
int main(){
	freopen("solider.in","r",stdin);
	freopen("solider.out","w",stdout);
	cin>>n>>m>>x>>y;
	_map[x][y]=1;
	for(int i=0;i<8;i++){
		_map[x+dx[i]][y+dy[i]]=1;
	}
	opt[0][0]=1;
	for(int i=1;i<=n;i++)
	{
		if(_map[i][0]) break;
		else opt[i][0]=opt[i-1][0];
	}
	for(int i=1;i<=m;i++)
	{
		if(_map[0][i]) break;
		else opt[0][i]=opt[0][i-1];
	}
	for(int i=1;i<=n;i++)
	    for(int j=1;j<=m;j++){
	    	if(_map[i][j]) opt[i][j]=0;
	    	else opt[i][j]=opt[i-1][j]+opt[i][j-1];
		}
	cout<<opt[n][m]<<endl;
	return 0;
}
