#include<bits/stdc++.h>
using namespace std;
int n,ans[305],jw;
int main(){
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	cin>>n;
	n++;
	ans[1]=1;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=300;j++){
			int tmp=0;
			tmp=jw+ans[j]*2;
			ans[j]=tmp%10;
			jw=tmp/10;
		}
	}
	ans[1]-=2;
	int i;
	for(i=300;i>=1;i--){
		if(ans[i]) break;
	}
	for(int j=i;j>=1;j--){
		cout<<ans[j];
	}
	cout<<endl;
	return 0;
}
