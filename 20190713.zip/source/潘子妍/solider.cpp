#include<bits/stdc++.h>
using namespace std;
int Map[21][21],n,m,f[21][21],x,y;
int dx[8]={1,1,2,2,-1,-1,-2,-2};
int dy[8]={2,-2,1,-1,2,-2,1,-1};
int main()
{
 freopen("solider.in","r",stdin);
 freopen("solider.out","w",stdout);
 cin>>n>>m>>x>>y;
 Map[x][y]=1;
 for (int i=0;i<8;i++)
   Map[x+dx[i]][y+dy[i]]=1;
 f[0][0]=1;
 for (int i=1;i<=n;i++)
   {
   	if (Map[i][0]) break;
   	else f[i][0]=f[i-1][0];
   }
 for (int i=1;i<=m;i++)
   {
   	if (Map[0][i]) break;
   	else f[0][i]=f[0][i-1];
   }  
 for (int i=1;i<=n;i++)
   for (int j=1;j<=m;j++)
     {
      if (Map[i][j]) f[i][j]=0;
	  else f[i][j]=f[i-1][j]+f[i][j-1];	
	 }  
 cout<<f[n][m]<<endl;
 fclose(stdin);
 fclose(stdout);
 return 0;	 
}
