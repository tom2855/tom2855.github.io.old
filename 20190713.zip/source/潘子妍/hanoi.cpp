#include<bits/stdc++.h>
using namespace std;
int ans[301],n,i,j,jw;
int main()
{
 freopen("hanoi.in","r",stdin);
 freopen("hanoi.out","w",stdout);
 cin>>n;
 n++;
 ans[1]=1;
 for (i=1;i<=n;i++)
   {
   	for (j=1;j<=300;j++)
   	  {
   	   int tmp;
   	   tmp=jw+ans[j]*2;
   	   ans[j]=tmp%10;
   	   jw=tmp/10;
	  }
   }
 ans[1]-=2;
 for (j=300;j>=1;j--)
   if (ans[j]) break;
 for (i=j;i>=1;i--)
   cout<<ans[i];
 cout<<endl;
 fclose(stdin);
 fclose(stdout);
 return 0;      
}
