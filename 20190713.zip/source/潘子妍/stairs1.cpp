#include<bits/stdc++.h>
using namespace std;
int f[31],n;
int main()
{
 freopen("stairs1.in","r",stdin);
 freopen("stairs1.out","w",stdout);
 cin>>n;
 f[1]=1;
 f[2]=2;
 for (int i=3;i<=n;i++)
   f[i]=f[i-1]+f[i-2];
 cout<<f[n]<<endl;
 fclose(stdin);
 fclose(stdout);
 return 0;  
}
