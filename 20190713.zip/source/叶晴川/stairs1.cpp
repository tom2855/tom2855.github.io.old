#include<bits/stdc++.h>
using namespace std;
int dfs(int n){
	if(n<=2) return n;
	else return dfs(n-1)+dfs(n-2);
}
int main(){
	int x;
	freopen("stairs1.in","r",stdin);
	freopen("stairs1.out","w",stdout);
	cin>>x;
	cout<<dfs(x)<<endl;
	return 0;
}
