#include<bits/stdc++.h>
using namespace std;
int n,m,opt[31][31];
int main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m;
	opt[1][0]=1;
	for(int j=1; j<=m; j++) {
		opt[1][j]=opt[2][j-1]+opt[n][j-1];
		for(int i=2; i<=n-1; i++)opt[i][j]=opt[i-1][j-1]+opt[i+1][j-1];
		opt[n][j]=opt[n-1][j-1]+opt[1][j-1];
	}
	cout<<opt[1][m]<<endl;
	return 0;
}
