#include<bits/stdc++.h>
using namespace std;
int n,m,x,y,f[25][25];
int dx[] = {0,-2,-1,1,2,2,1,-1,-2};
int dy[] = {0,1,2,2,1,-1,-2,-2,-1};
int main() {
//	freopen("solider.in","r",stdin);
//	freopen("solider.out","w",stdout);
	scanf("%d%d%d%d",&n,&m,&x,&y);
	for(int i = 0; i < 9; i++) {
		int nx = x + dx[i],ny = y + dy[i];
		if(nx >= 0 && ny >= 0 && nx <= n && ny <= m)
			f[nx][ny] = -1;
	}
	for(int i = 0 ; i <= n; i++) {
		if(f[i][0] == -1)
			break;
		f[i][0] = 1;
	}
	for(int i = 1 ; i <= m; i++) {
		if(f[0][i] == -1)
			break;
		f[0][i] = 1;
	}
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= m; j++) {
			if(f[i][j])
				continue;
			if(f[i - 1][j] != -1)
				f[i][j] += f[i - 1][j];
			if(f[i][j - 1] != -1)
				f[i][j] += f[i][j - 1];
		}
	printf("%d",f[n][m]);
	return 0;
}
