#include<bits/stdc++.h>
using namespace std;
int n,ds,jw,i,a[100] = {0,1};
int main() {
//	freopen("hanoi.in","r",stdin);
//	freopen("hanoi.out","w",stdout);
	scanf("%d",&n);
	for(i = 0; i <= n; i++)
		for(int j = 1 ; j <= 100; j++) {
			ds = a[j] * 2 + jw;
			jw = ds / 10;
			a[j] = ds % 10;
		}
	a[1] -= 2;
	for(i = 99; i > 1; i--)
		if(a[i])
			break;
	for(; i > 0; i--)
		printf("%d",a[i]);
	return 0;
}
