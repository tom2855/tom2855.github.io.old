#include<bits/stdc++.h>
using namespace std;
int n,a,b = 1,c;
int main() {
//	freopen("stairs1.in","r",stdin);
//	freopen("stairs1.out","w",stdout);
	scanf("%d",&n);
	for(int i = 1; i <= n; i++) {
		c = a + b;
		a = b;
		b = c;
	}
	printf("%d",c);
	return 0;
}
