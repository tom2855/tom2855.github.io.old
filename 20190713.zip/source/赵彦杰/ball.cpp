#include<bits/stdc++.h>
using namespace std;
int n,m,ans,i,j;
void dfs(int x,int step) {
	if(step == m) {
		if(x == 1)
			ans++;
		return;
	}
	if(min(n - x,x) > m - step)
		return;
	if(x == 1)
		dfs(n,step + 1);
	else
		dfs(x - 1,step + 1);
	if(x == n)
		dfs(1,step + 1);
	else
		dfs(x + 1,step + 1);
}
int main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin >> n >> m;
	dfs(1,0);
	cout << ans;
	return 0;
}
