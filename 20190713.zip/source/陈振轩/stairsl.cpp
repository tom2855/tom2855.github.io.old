#include<bits/stdc++.h>
using namespace std;
int n,f[35];
int main() {
	f[1]=1;
	f[2]=2;
	for(int i=3; i<=30; i++)
		f[i]=f[i-1]+f[i-2];
	cin>>n;
	cout<<f[n]<<endl;
	return 0;
}
