#include<bits/stdc++.h>
using namespace std;
int n,h[1000005];
int main(){
	h[1]=1;
	for(int i=2;i<=1000000;i++)
	h[i]=2*(h[i-1])+1;
	cin>>n;
	cout<<h[n]<<endl;
	return 0;
}
