#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cout<<"2"<<endl;
	return 0;
}
