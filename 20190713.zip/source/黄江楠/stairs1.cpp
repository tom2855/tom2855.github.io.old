#include<bits/stdc++.h>
using namespace std;
int n,i,j,k,sum,ans,a[105];
int main() {
	freopen("stairs1.in","r",stdin);
	freopen("stairs1.out","w",stdout);
	cin>>n;
	a[1]=1;
	a[2]=2;
	for(i=3;i<=n;i++){
		a[i]=a[i-1]+a[i-2];
	}
	cout<<a[n]<<endl;
	return 0;
}

