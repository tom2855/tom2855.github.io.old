#include<bits/stdc++.h>
using namespace std;
int n;
int main() {
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	cout<<n<<endl;
}
