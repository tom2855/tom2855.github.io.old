#include<bits/stdc++.h>
using namespace std;
int n,i,j,k,sum,num,a[205];
int main() {
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	cin>>n;
	a[1]=1;
	for(i=2;i<=n;i++){
		a[i]=2*a[i-1]+1;
	}
	cout<<a[n]*2<<endl;
	return 0;
}
