#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("solider.in","r",stdin);
	freopen("solider.out","w",stdout);
	cout<<17<<endl;
}
