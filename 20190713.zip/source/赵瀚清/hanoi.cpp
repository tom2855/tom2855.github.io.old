#include<bits/stdc++.h>
using namespace std;
int n;
unsigned long long k=1;
int main()
{
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	cin >> n;
	for(int i = 1;i <= n;i++)
		k*=2;
	cout<<2*(k-1);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

