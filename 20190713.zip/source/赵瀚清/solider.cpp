#include<bits/stdc++.h>
using namespace std;
int m,n,x,y;
int b[110][110];
long long a[110][110];
int main()
{
	freopen("solider.in","r",stdin);
	freopen("solider.out","w",stdout);
	memset(b,0,sizeof(b));
	int p[8]={2,1,-1,-2,-2,-1,1,2};
	int z[8]={1,2,-2,-1,1,2,2,1};
	cin >> n >> m >> x >> y;
	b[x][y]=1;
	for(int i = 0;i <= 7;i++)
		if(x+p[i]>=0&&x+p[i]<=n&&y+z[i]>=0&&y+z[i]<=m)
			b[x+p[i]][y+z[i]]=1;
	int k = 0;
	while(b[k][0]==0&&k<=n)
		a[k++][0]=1;
	int l=0;
	while(b[0][1]==0&&l<=m)
		a[0][l++]=1;
	for(int i = 1;i <= n;i++)
	{
		for(int j = 1;j <= m;j++)
		{
			if(b[i][j]==1) a[i][j]=0;
			if(b[i][j]!=1)a[i][j] = a[i-1][j]+a[i][j-1];
		}
	}
	cout<<a[n][m];
	fclose(stdin);
	fclose(stdout);
	return 0;
}

