#include<bits/stdc++.h>
using namespace std;
int n,ans;
void f(int n)
{
	ans++;
	
	for(int i = 1;i <= n / 2;i++)
		f(i);
}
int main()
{
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin >> n;
	dfs(n);
	cout << ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

