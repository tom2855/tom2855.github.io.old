#include<bits/stdc++.h>
using namespace std;
int n,m,f[35][35];
int main()
{
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin >> n >> m;
	f[0][1]=1;
	for(int i = 1;i <= m;i++)
	{	
		f[i][1]=f[i-1][n]+f[i-1][2];
		for(int j = 2;j < m;j++)
			f[i][j]=f[i-1][j-1]+f[i-1][j+1];
		f[i][n]=f[i-1][n-1]+f[i-1][1];
	}
	cout<<f[m][1];
	fclose(stdin);
	fclose(stdout);
	return 0;
}

