#include<bits/stdc++.h>
using namespace std;
int N;
long long han[2];
int main(){
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	scanf("%d",&N);
	han[1]=1;
	for(int i=2;i<=N;++i)
		han[i%2]=han[(i-1)%2]*2+1;
	printf("%d\n",han[N%2]*2);
	return 0;
}
