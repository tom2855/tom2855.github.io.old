#include<bits/stdc++.h>
using namespace std;
int N,feb[3];
int main(){
	freopen("stairs1.in","r",stdin);
	freopen("stairs1.out","w",stdout);
	scanf("%d",&N);
	feb[1]=1;
	feb[2]=2;
	for(int i=3;i<=N;++i)
		feb[i%3]=feb[(i-1)%3]+feb[(i-2)%3];
	printf("%d\n",feb[N%3]);
	return 0;
}
