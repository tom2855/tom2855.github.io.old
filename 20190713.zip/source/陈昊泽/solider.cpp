#include<bits/stdc++.h>
using namespace std;
int N,M,X,Y,dp[21][21];
int dx[9]={0,-2,-2,-1,-1,1,1,2,2};
int dy[9]={0,-1,1,-2,2,-2,2,-1,1};
bool check(int x,int y){
	for(int i=0;i<9;++i)
		if(X+dx[i]==x&&Y+dy[i]==y)return false;
	return true;
}
int main(){
	freopen("solider.in","r",stdin);
	freopen("solider.out","w",stdout);
	scanf("%d%d%d%d",&N,&M,&X,&Y);
	N+=1;
	M+=1;
	X+=1;
	Y+=1;
	dp[1][0]=1;
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
			if(check(i,j))dp[i][j]=dp[i-1][j]+dp[i][j-1];
		
	printf("%d",dp[N][M]);
	return 0;
}
