#include<bits/stdc++.h>
using namespace std;
int n;
long long f[205];
int main(){
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	cin>>n;
	f[1]=1;
	for(int i=2;i<=n;i++)
		f[i]=f[i-1]+1+f[i-1];
	cout<<f[n]*2<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
