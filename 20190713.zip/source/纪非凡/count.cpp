#include<bits/stdc++.h>
using namespace std;
int n,f[1005];
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	f[1]=1;
	for(int i=2;i<=n;i++){
		if(i%2==1)f[i]=f[i-1];
		else {
			for(int j=1;j<=i/2;j++)
				f[i]=f[i]+f[j];
			f[i]++;
		}
	}
	cout<<f[n]<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
