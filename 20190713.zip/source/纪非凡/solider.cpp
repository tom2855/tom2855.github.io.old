#include<bits/stdc++.h>
using namespace std;
int n,m,x,y;
long long f[25][25];
int main(){
	freopen("solider.in","r",stdin);
	freopen("solider.out","w",stdout);
	cin>>n>>m>>x>>y;
	f[x][y]=f[x-2][y-1]=f[x-1][y-2]=-1;
	f[x+1][y-2]=f[x+2][y-1]=f[x+2][y+1]=-1;
	f[x+1][y+2]=f[x-1][y+2]=f[x-2][y+1]=-1;
	for(int i=0;i<=n;i++){
		for(int j=0;j<=m;j++){
			if(f[i][j]==-1)f[i][j]=0;
			else if(i==0&&j!=0){
				if(x-2!=0)f[i][j]=1;
				else if(j<y-1)f[i][j]=1;
				else f[i][j]=0;
			}
			else if(i!=0&&j==0){
				if(y-2!=0)f[i][j]=1;
				else if(i<x-1)f[i][j]=1;
				else f[i][j]=0;
			}
			else f[i][j]=f[i-1][j]+f[i][j-1];
		}
	}
	cout<<f[n][m]<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
