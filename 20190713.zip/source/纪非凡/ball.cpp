#include<bits/stdc++.h>
using namespace std;
int n,m,i=1;
long long f[35][35];
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m;
	f[1][0]=1;
	while(i<=m){
		for(int j=2;j<=n;j++){
			if(j==n)f[j][i]=f[j-1][i-1]+f[1][i-1];
			else f[j][i]=f[j-1][i-1]+f[j+1][i-1];
		}
		i++;
		f[1][i]=f[2][i-1]+f[n][i-1];
	}
	cout<<f[1][m]<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
