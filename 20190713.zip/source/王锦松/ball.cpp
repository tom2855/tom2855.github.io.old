#include<bits/stdc++.h>
using namespace std;
int n,m,a[35][35],i,j;
int main(){
	freopen("stairs1.in","r",stdin);
	freopen("stairs1.out","w",stdout);
	cin>>n>>m;
	a[1][1]=2;
	for(i=1;i<=n;i++){
		a[i][1]=a[i-1][2]+a[i-1][n];
		for(j=1;j<=m;j++)
			a[i][j]=a[i-1][j-1]+a[i-1][j+1];
		a[i][n]=a[i-1][1]+a[i-1][n-1];		
	}
	cout<<a[1][m]<<endl;
	return 0;
}
