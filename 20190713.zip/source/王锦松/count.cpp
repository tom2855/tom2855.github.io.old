#include<bits/stdc++.h>
using namespace std;
int n,a[1005];
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	a[1]=1;
	a[2]=2;
	for(int i=3;i<=n;i++)
		a[i]=a[i/2]+a[i/2-1];
	cout<<a[n]*2<<endl;
	return 0;
}
