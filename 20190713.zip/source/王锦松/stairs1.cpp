#include<bits/stdc++.h>
using namespace std;
int n,a[35];
int main(){
	freopen("stairs1.in","r",stdin);
	freopen("stairs1.out","w",stdout);
	cin>>n;
	a[0]=0;
	a[1]=1;
	a[2]=2;
	for(int i=3;i<=n;i++)
		a[i]=a[i-1]+a[i-2];
	cout<<a[n]<<endl;
	return 0;
}
