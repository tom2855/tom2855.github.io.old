#include<bits/stdc++.h>
using namespace std;
int n,m,x,y,ans;
bool vis[20][20],_map[20][20],a[20][20];
int dx[2]={0,1};
int dy[2]={1,0};
bool check(int x,int y){
	if(x<1 || x>n)
		return false;
	if(y<1 || y>m)
		return false;
	if(_map[x][y]==false)
		return false;
	if(vis[x][y]==true)
		return false;
	return true;
}
void dfs(int x,int y){
	if(x==n && y==m)
		ans++;
	for(int k=0;k<=2;k++){
		int nx,ny;
		nx=x+dx[k];
		ny=y+dy[k];
		if(check(nx,ny)==true){
			vis[nx][ny]=true;
			dfs(nx,ny);
			vis[nx][ny]=false;
		}
	}
}
int main(){
	freopen("soilder.in","r",stdin);
	freopen("soilder.out","w",stdout);
	cin>>n>>m>>x>>y;
	memset(_map,true,sizeof(_map));
	memset(vis,false,sizeof(vis));
	_map[x][y]=false;
	_map[x-2][y-1]=false;
	_map[x-2][y+1]=false;
	_map[x-1][y+2]=false;
	_map[x+1][y+2]=false;
	_map[x+2][y+1]=false;
	_map[x+2][y-1]=false;
	_map[x+1][y-2]=false;
	_map[x-1][y-2]=false;
	vis[1][1]=true;
	dfs(1,1);
	cout<<ans<<endl;
	return 0;
}
