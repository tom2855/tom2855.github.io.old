#include<bits/stdc++.h>
using namespace std;
int n,ans=1;
int main(){
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n+1;i++)
		ans*=2;
	cout<<ans-2<<endl;
	return 0;
}
