#include<bits/stdc++.h>
using namespace std;
int num[35],n;
int main() {
	freopen("stairs1.in","r",stdin);
	freopen("stairs1.out","w",stdout);
	cin>>n;
	num[1]=1;
	num[2]=1;
	for(int i=1; i<=n;i++)
		num[i]+=num[i-1]+num[i-2];
	cout<<num[n]<<endl;
	return 0;
}
