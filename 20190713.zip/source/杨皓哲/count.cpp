#include<bits/stdc++.h>
using namespace std;
int n,ans=1;
int opt[100005];
void c(int x) {
	if(opt[x]) ans+=opt[x];
	else {
		ans++;
		int a=x/2;
		int ass=ans;
		for(register int i=1; i<=a; ++i) {
			c(i);
			opt[x]=ans-ass+1;
		}
	}
	return;
}
int main() {
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	c(n);
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
