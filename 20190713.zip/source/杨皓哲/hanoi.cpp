#include<bits/stdc++.h>
using namespace std;
int n,ans;
void mov(int x) {
	if(x==0) return;
	mov(x-1);
	ans++;
	mov(x-1);
}
int main() {
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	cin>>n;
	mov(n);
	cout<<ans*2<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
