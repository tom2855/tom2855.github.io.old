#include<bits/stdc++.h>
using namespace std;
int n;
int f(int x){
	if(x==1){
		return 1;
	}
	if(x==2){
		return 2;
	}
	return f(x-1)+f(x-2);	
}
int main(){
	freopen("stairs1.in","r",stdin);
	freopen("stairs1.out","w",stdout);
	cin>>n;
	cout<<f(n)<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
