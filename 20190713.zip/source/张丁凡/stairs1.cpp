#include<bits/stdc++.h>
using namespace std;
int n;
int f0 = 1 , f1 = 1 , f2 = 2;
int main() {
	freopen("stairs1.in","r",stdin);
	freopen("stairs1.out","w",stdout);
	cin >> n;
	if(n == 1) {
		cout << "1" << endl;
		return 0;
	}
	if(n != 2){
		
		for(int i = 2; i <= n; i++) {
			f2 = f0 + f1;
			f0 = f1;
			f1 = f2;
			
		}
	}
	printf("%d\n" , f2);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
