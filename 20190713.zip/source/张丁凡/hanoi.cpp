#include<bits/stdc++.h>
using namespace std;
int n , an;
int main() {
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	cin >> n;
	an = n * 2;
	cout << an * 2 - 2 << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
