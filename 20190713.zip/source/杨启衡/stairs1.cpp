#include<bits/stdc++.h>
using namespace std;
int n,ans;
int main(){
	freopen("stairs1.in","r",stdin);
	freopen("stairs1.out","w",stdout);
	cin >> n;
	ans = n / 2 + 1;
	for(int i=1;i<=n;i++)
	    if(n/(2*i) != 0)
	       ans+=n/2+n%2-1;
	cout << ans << endl;
	return 0;
}
