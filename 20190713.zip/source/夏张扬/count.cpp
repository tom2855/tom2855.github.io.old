#include<bits/stdc++.h>
using namespace std;
int n,opt[1005];
int main() {
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	opt[0]=1;
	for(int i=1;i<=n;i++)
		for(int j=0;j<=i/2;j++)
			opt[i]+=opt[j];	
	cout<<opt[n];
	fclose(stdin);
	fclose(stdout);
	return 0;
}
