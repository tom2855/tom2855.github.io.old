#include<bits/stdc++.h>
using namespace std;
int n,m,opt[35][35];
int main() {
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m;
	opt[0][1]=1;
	for(int i=1; i<=m; i++) {
		opt[i][1]=opt[i-1][n]+opt[i-1][2];
		for(int j=2; j<n; j++)
			opt[i][j]=opt[i-1][j-1]+opt[i-1][j+1];
		opt[i][n]=opt[i-1][n-1]+opt[i-1][1];
	}
	cout<<opt[m][1];
	fclose(stdin);
	fclose(stdout);
	return 0;
}
