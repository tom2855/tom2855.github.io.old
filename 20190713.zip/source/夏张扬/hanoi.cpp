#include<bits/stdc++.h>
using namespace std;
unsigned long long n,opt[205],jw;
int main(){
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	cin>>n;
	opt[1]=1;
	for(int i=1;i<=n+1;i++)
		for(int j=1;j<=200;j++){
			jw+=opt[j]*2;
			opt[j]=jw%10;
			jw/=10;
		} 
	int j;
	for(j=200;j>=1;j--){
		if(opt[j]) break;
	}
	opt[1]-=2;
	for(int i=j;i>=1;i--) cout<<opt[i];
	fclose(stdin);
	fclose(stdout);
	return 0; 
}
