#include<bits/stdc++.h>
using namespace std;
int n,m,x,y;
long long vis[25][25],opt[25][25];
int dx[] = {0,-2,-1,1,2,2,1,-1,-2};
int dy[] = {0,1,2,2,1,-1,-2,-2,-1};
int main() {
	freopen("solider.in","r",stdin);
	freopen("solider.out","w",stdout);
	cin >> n >> m >> x >> y;
	for(int i = 0;i <= n;i++)
		for(int j = 0;j <= m;j++)
			vis[i][j] = 1;
	for(int i = 0; i < 9; i++) {
		int nx = x + dx[i],ny = y + dy[i];
		if(nx >= 0 && ny >= 0 && nx <= n && ny <= m)
			vis[nx][ny] = 0;
	}
	opt[0][0] = 1;
	for(int i = 1;i <= n;i++)
		opt[i][0] = opt[i - 1][0] * vis[i][0];
		
	for(int j = 1;j <= m;j++)
		opt[0][j] = opt[0][j - 1] * vis[0][j];
		
	for(int i = 1;i <= n;i++)
		for(int j = 1;j <= m;j++)
			opt[i][j] = (opt[i - 1][j] + opt[i][j - 1]) * vis[i][j];
	cout << opt[n][m] << endl;
	return 0;
}
