#include <cstdio>
#include <algorithm>
using namespace std;

int n, w, diff = 0x7fffffff, pos;
int a[1001];

inline int abs(int x) {
	return x < 0? -x : x;
}

inline void read(int &x) {
	x = 0;
	char ch;
	ch = getchar();
	while(ch < '0' || ch > '9') {
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = (x << 3) + (x << 1) + ch - '0';
		ch = getchar();
	}
}

int main() {
	freopen("apple.in", "r", stdin);
	freopen("apple.out", "w", stdout);
	read(n);
	read(w);
	for(int i = 1; i <= n; ++i) {
		read(a[i]);
	}
	sort(a + 1, a + 1 + n);
	for(int i = 1; i <= n; ++i) {
		if(abs(a[i] - w) <= diff) {
			diff = abs(a[i] - w);
			pos = i;
		}
	}
	printf("%d\n", a[pos]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
