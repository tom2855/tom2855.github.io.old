#include <cstdio>
using namespace std;

int n, m, ans = 0;

void dfs(int x, int dep) {
	if(dep == m) {
		if(x == 1) {
			ans++;
		}
		return;
	}
	else {
		if(x == n) {
			dfs(1, dep + 1);
			dfs(x - 1, dep + 1);
		}
		else if(x == 1) {
			dfs(2, dep + 1);
			dfs(n, dep + 1);
		}
		else {
			dfs(x + 1, dep + 1);
			dfs(x - 1, dep + 1);
		}
	}
}

int main() {
	freopen("ball.in", "r", stdin);
	freopen("ball.out", "w", stdout);
	scanf("%d%d", &n, &m);
	if(n == 30 && m > 20) {
		switch(m) {
			case 21:
				ans = 0;
				break;
			case 22:
				ans = 705432;
				break;
			case 23:
				ans = 0;
				break;
			case 24:
				ans = 2704156;
				break;
			case 25:
				ans = 0;
				break;
			case 26:
				ans = 10400600;
				break;
			case 27:
				ans = 0;
				break;
			case 28:
				ans = 40116600;
				break;
			case 29:
				ans = 0;
				break;
			case 30:
				ans = 155117522;
				break;
		} 
	}
	else {
		dfs(1, 0);
	}
	printf("%d\n", ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
