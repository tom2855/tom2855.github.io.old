#include <cstdio>
#include <algorithm>
#include <vector>
using namespace std;

vector<int> v, tmp;
int minn[1001], maxn[1001];

inline void read(int &x) {
	x = 0;
	char ch;
	ch = getchar();
	bool flag = false;
	while(ch < '0' || ch > '9') {
		if(ch == '-') {
			flag = true;
		}
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = (x << 3) + (x << 1) + ch - '0';
		ch = getchar();
	}
	if(flag) {
		x = -x;
	}
}

int main() {
	freopen("window.in", "r", stdin);
	freopen("window.out", "w", stdout);
	
	register int t, rep, n, k;
	read(n);
	read(k);
	for(register int i = 0; i < n; ++i) {
		read(t);
		v.push_back(t);
	}
	rep = n - k + 1;
	for(register int i = 0; i < rep; ++i) {
		tmp = v;
		sort(tmp.begin() + i, tmp.begin() + i + k);
		minn[i] = tmp[i],
		maxn[i] = tmp[i + k - 1];
//		printf("%d\n", tmp[i+k]);
	}
	for(register int i = 0; i < rep; ++i) {
		printf("%d ", minn[i]);
	}
	putchar('\n');
	for(register int i = 0; i < rep; ++i) {
		printf("%d ", maxn[i]);
	}
	putchar('\n');
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
