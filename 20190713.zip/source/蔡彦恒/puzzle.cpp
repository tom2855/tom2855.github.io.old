#include <cstdio>
#include <algorithm>
using namespace std;

int n;
long long maxt = 1;
int a[100001];

inline void read(int &x) {
	x = 0;
	char ch;
	ch = getchar();
	while(ch < '0' || ch > '9') {
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = (x << 3) + (x << 1) + ch - '0';
		ch = getchar();
	}
}

int main() {
	freopen("puzzle.in", "r", stdin);
	freopen("puzzle.out", "w", stdout);
	
	read(n);
	for(register int i = 1; i <= n; ++i) {
		read(a[i]);
	}
	sort(a + 1, a + 1 + n);
	a[1]++;
	for(register int i = 1; i <= n; ++i) {
		maxt = (maxt % 999983) * a[i] % 999983;
	}
	printf("%d\n", maxt % 999983);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
