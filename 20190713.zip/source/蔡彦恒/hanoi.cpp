#include <cstdio>
using namespace std;

int n, h[201];

int main() {
	freopen("hanoi.in", "r", stdin);
	freopen("hanoi.out", "w", stdout);
	scanf("%d", &n);
	h[1] = 1;
	for(register int i = 2; i <= n; ++i) {
		h[i] = h[i - 1] * 2 + 1;
	}
	printf("%d\n", h[n] * 2);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
