#include <cstdio>
#include <algorithm>
using namespace std;

int n, c, a[100001];

inline void read(int &x) {
	x = 0;
	char ch;
	ch = getchar();
	while(ch < '0' || ch > '9') {
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = (x << 3) + (x << 1) + ch - '0';
		ch = getchar();
	}
}

bool check(int x) {
	register int cnt = 0, lst = 1;
	for(register int i = 2; i <= n; ++i) {
		if(x > a[i] - a[lst]) {
			cnt++;
		}
		else {
			lst = i;
		}
	}
	if(c >= cnt) {
		return true;
	}
	return false;
}

int main() {
	freopen("angry.in", "r", stdin);
	freopen("angry.out", "w", stdout);
	
	read(n);
	read(c);
	for(register int i = 1; i <= n; ++i) {
		read(a[i]);
	}
	sort(a + 1, a + 1 + n);
	c = n - c;
	register int lft = 0, rgt = a[n], mid;
	while(lft + 1 < rgt) {
		bool flag = true;
		mid = (lft + rgt) >> 1;
		if(check(mid)) {
			lft = mid;
		}
		else {
			rgt = mid;
		}
	}
	printf("%d\n", lft);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
