#include <cstdio>
using namespace std;

char c[100005], ch;
int win, lose, cnt;
int main() {
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	
	scanf("%c", &ch);
	while(ch != 'E') {
		c[++cnt] = ch;
		scanf("%c", &ch);
	}
	for(int i = 1; i <= cnt; i++) {
		if (c[i] == 'W')
			win++;
		if (c[i] == 'L')
			lose++;
		if (win >= 11 && win - lose > 1 || lose >= 11 && lose - win > 1) {
			printf("%d:%d\n", win, lose);
			lose = win = 0;
		}
	}
	printf("%d:%d\n", win, lose);
	putchar('\n');
	
	lose = win = 0;
	for(int i = 1; i <= cnt; i++) {
		if (c[i] == 'W')
			win++;
		if (c[i] == 'L')
			lose++;
		if (win >= 21 && win - lose > 1 || lose >= 21 && lose - win > 1) {
			printf("%d:%d\n", win, lose);
			lose = win = 0;
		}
	}	
	printf("%d:%d\n", win, lose);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
