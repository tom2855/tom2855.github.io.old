#include <cstdio>
using namespace std;

int n, m, x, y, ans = 0;
const int dx1[] = { 1, 2, 2, 1, -1, -2, -2, -1 },
		  dy1[] = { -2, -1, 1, 2, 2, 1, -1, -2 },
		  dx[] = { 1, 0 },
		  dy[] = { 0, 1 };
bool able[21][21];

void dfs(int xx, int yy) {
//	able[xx][yy] = true;
	if(xx == n && yy == m) {
		ans++;
		return;
	}
	for(int k = 0; k < 2; ++k) {
		int nx = xx + dx[k],
			ny = yy + dy[k];
		if(nx >= 0 && nx <= n && ny >= 0 && ny <= m && !able[nx][ny]) {
			dfs(nx, ny);
		}
	}
//	able[xx][yy] = false;
}

int main() {
	freopen("solider.in", "r", stdin);
	freopen("solider.out", "w", stdout);
	scanf("%d%d%d%d", &n, &m, &x, &y);
	able[x][y] = true;
	for(int k = 0; k < 8; ++k) {
		int nx = x + dx1[k],
			ny = y + dy1[k];
		if(nx >= 0 && nx <= n && ny >= 0 && ny <= m) {
			able[nx][ny] = true;
		}
	}
	dfs(0, 0);
	printf("%d\n", ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
