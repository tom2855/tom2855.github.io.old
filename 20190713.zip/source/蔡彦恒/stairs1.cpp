#include <cstdio>
using namespace std;

int fib[31], n;

//inline void read(int &x);

int main() {
	freopen("stairs1.in", "r", stdin);
	freopen("stairs1.out", "w", stdout);
	scanf("%d", &n);
	fib[1] = 1,
	fib[2] = 2;
	for(int i = 3; i <= n; ++i) {
		fib[i] = fib[i - 1] + fib[i - 2];
	}
	printf("%d\n", fib[n]);
	return 0;
}
