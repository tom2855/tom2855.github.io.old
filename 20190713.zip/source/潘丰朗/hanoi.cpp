#include<bits/stdc++.h>
using namespace std;
int n;
int main(){
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	cin>>n;
	if(n==1) cout<<2;
	if(n==2) cout<<6;
	return 0;
}
