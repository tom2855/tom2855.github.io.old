#include<bits/stdc++.h>
using namespace std;
int f[25][25];
bool pd[25][25];
int n,m,x,y;
int main(){
	freopen("solider.in","r",stdin);
	freopen("solider.out","w",stdout);
	memset(pd,true,sizeof(pd));
	cin>>n>>m>>x>>y;
	f[0][0]=1;
	pd[x][y]=false;
	pd[x-2][y-1]=false;
	pd[x-2][y+1]=false;
	pd[x-1][y+2]=false;
	pd[x+1][y+2]=false;
	pd[x+2][y-1]=false;
	pd[x+2][y+1]=false;
	pd[x-1][y-2]=false;
	pd[x+1][y-2]=false;
	for(int i=0;i<=n;i++){
		for(int j=0;j<=m;j++){
			if(!pd[i][j]) continue;
			if(pd[i-1][j]) f[i][j]+=f[i-1][j];
			if(pd[i][j-1]) f[i][j]+=f[i][j-1];
		}
	}
	cout<<f[n][n];
	return 0;
}
