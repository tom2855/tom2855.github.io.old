#include<bits/stdc++.h>
using namespace std;
int a,b=1,c,n;
int main(){
	freopen("stair1.in","r",stdin);
	freopen("stair1.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		c=a+b;
		a=b;
		b=c;
	}
	cout<<c;
	return 0;
}
