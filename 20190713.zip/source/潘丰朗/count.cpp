#include<bits/stdc++.h>
using namespace std;
int ans;
void count(int x){
	ans++;
	for(int i=1;i<=x/2;i++){
		count(i);
	}
}
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	int n;
	cin>>n;
	count(n);
	cout<<ans;
	return 0;
}
