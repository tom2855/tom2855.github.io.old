#include<bits/stdc++.h>
using namespace std;
int a[10];
int n,size,cnt;
void dfs(){
	for(int i=1;i<=a[size]/2;i++){
		cnt++;
		size++;
		a[size]=i;
		dfs();
		a[size]=0;
		size--;
	}
}
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	a[1]=n;
	size=1;
	cnt=1;
	dfs();
	cout<<cnt<<endl;
	return 0;
}

