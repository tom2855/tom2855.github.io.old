#include<bits/stdc++.h>
using namespace std;
int n,m,cnt;
int main(){
	freopen("ball.in","r",stdin);
	freopen("ball.out","w",stdout);
	cin>>n>>m;
	if(m==n)cnt+=2;
	while(!m%2)cnt+=2,m/=2;
	cout<<cnt<<endl;
	return 0;
}

