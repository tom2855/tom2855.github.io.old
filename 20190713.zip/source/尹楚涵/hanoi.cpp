#include<bits/stdc++.h>
using namespace std;
int n;
struct node{
	int num[100],size;
	node operator=(node a){
		size=a.size;
		for(int i=1;i<=size;i++)
			num[i]=a.num[i];
		return *this;
	}
	node(int n=0){
		memset(num,0,sizeof(num));
		num[1]=n;
		size=1;
	}
	inline node operator*(int n){
		node a;
		a.size=size;
		for(int i=1;i<size;i++){
			a.num[i]+=num[i]*n;
			while(a.num[i]>=10){
				a.num[i]-=10;
				a.num[i+1]++;
			}
		}
		a.num[a.size]+=num[size]*n;
		while(a.num[a.size]>=10){
			a.num[a.size]-=10;
			a.num[a.size+1]++;
			a.size++;
		}
		return a;
	}
	node operator-(int n){
		node a=*this;
		a.num[1]-=n;
		return a;
	}
};
int main(){
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	cin>>n;
	node sum(1);
	for(int i=1;i<=n;i++)sum=sum*2;
	node ans=(sum-1)*2;
	for(int i=ans.size;i>=1;i--)cout<<ans.num[i];
	cout<<endl;
	return 0;
}

