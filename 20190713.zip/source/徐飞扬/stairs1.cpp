#include<bits/stdc++.h>
using namespace std;
int n,step[35];
int main() {
	freopen("stairs1.in","r",stdin);
	freopen("stairs1.out","w",stdout);
	cin >> n;
	step[1] = 1;
	step[2] = 2;
	for(int i = 3; i <= n; i++)
		step[i] = step[i - 1] + step[i - 2];
	cout << step[n] << endl;
	return 0;
}
