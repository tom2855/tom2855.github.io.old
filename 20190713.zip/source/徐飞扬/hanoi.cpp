#include<bits/stdc++.h>
using namespace std;
int n;
long long ans;
int main(){
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	cin >> n;
	ans = 1;
    for(int i = 1; i <= n; i++)
		ans = ans * 2;
	ans = (ans - 1) * 2;
	cout << ans << endl;
	return 0;
}
