#include<bits/stdc++.h>
using namespace std;
int n,ans;
void sum(int n){
	ans;
	ans++;
	for(int i = 1; i <= n / 2; i++)
	    sum(i);
}
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin >> n;
	sum(n);
    cout << ans << endl;
    return 0;
}
