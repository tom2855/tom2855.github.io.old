#include<bits/stdc++.h>
using namespace std;
int n,ans=1;
void mov(int n,char a,char b,char c) {

	if(n==0) return;

	mov(n-1,a,b,c);
	ans++;
	mov(n-1,b,c,a);

}
int main() {
	freopen("hanoi.in","r",stdin);
	freopen("hanoi.out","w",stdout);
	cin>>n;
	mov(n,'a','c','b');
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
