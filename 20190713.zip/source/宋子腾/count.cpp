#include<bits/stdc++.h>
using namespace std;
int n,ans;
int main() {
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	for(int i=0; i<=n/2; i++) {
		ans++;
		if(i>1) for(int j=1; j<=i/2; j++)
				ans++;
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
