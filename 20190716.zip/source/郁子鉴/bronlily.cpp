#include"bits/stdc++.h"
using namespace std;
char _map[35][35];
bool vis[35][35];
int m,n,m1,m2,ans=1<<16-1;
int bx,by,ex,ey;
bool check(int x,int y){
	if(x<0||y<0) return 0;
	if(x>=m||y>=n) return 0;
	if(vis[x][y]) return 0;
	if(_map[x][y]=='0'||_map[x][y]=='2') return 0;
	return 1;
}
void dfs(int x,int y,int s){
	if(x==ex&&y==ey) ans=min(ans,s);
	else{
		if(s>=ans) return;
		vis[x][y]=1;
		if(check(x+m1,y+m2)) dfs(x+m1,y+m2,s+1);
		if(check(x+m2,y+m1)) dfs(x+m2,y+m1,s+1);
		if(check(x-m1,y-m2)) dfs(x-m1,y-m2,s+1);
		if(check(x-m2,y-m1)) dfs(x-m2,y-m1,s+1);
		if(check(x+m1,y-m2)) dfs(x+m1,y-m2,s+1);
		if(check(x+m2,y-m1)) dfs(x+m2,y-m1,s+1);
		if(check(x-m1,y+m2)) dfs(x-m1,y+m2,s+1);
		if(check(x-m2,y+m1)) dfs(x-m2,y+m1,s+1);
		vis[x][y]=0;
	}
	return;
}
int main(){
	freopen("bronlily.in","r",stdin);
	freopen("bronlily.out","w",stdout);
	cin>>m>>n>>m1>>m2;
	for(int i=0;i<m;i++)
		for(int j=0;j<n;j++){
			cin>>_map[i][j];
			if(_map[i][j]=='3'){bx=i,by=j;}
			if(_map[i][j]=='4'){ex=i,ey=j;}
		}
	dfs(bx,by,0);
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
