#include"bits/stdc++.h"
using namespace std;
int n,k,m;
struct Node{
	long long a;
	long long b;
	int c;
}x[50005];
bool tmp(Node x,Node y){
	return x.a>y.a;
}
int main(){
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	cin>>n>>k;
	for(int i=0;i<n;i++){scanf("%lld%lld",&x[i].a,&x[i].b);x[i].c=i+1;}
	sort(x,x+n,tmp);
	for(int i=0;i<k;i++) m=x[m].b>x[i].b?m:i;
	cout<<x[m].c<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
