#include"bits/stdc++.h"
using namespace std;
int l,m,ans;
bool f[30005];
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>l>>m;
	memset(f,1,sizeof(f));
	for(register int i=0;i<m;i++){
		int x,y;
		cin>>x>>y;
		for(register int j=x;j<=y;j++) f[j]=0;
	}
	for(register int i=0;i<=l;i++) ans+=f[i];
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
