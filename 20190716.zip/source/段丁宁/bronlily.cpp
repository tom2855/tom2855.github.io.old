#include<bits/stdc++.h>
using namespace std;
int m,n,m1,m2,start[1][1],end[1][1],step;
int a[35][35];
int main() {
	freopen("bronlily.in","r",stdin);
	freopen("bronlily.out","w",stdout);
	cin>>m>>n;
	cin>>m1>>m2;
	for(int i=1; i<=m; i++)
		for(int j=1; j<=n; j++) {
			cin>>a[i][j];
			if(a[i][j]==3) {
				start[0][0]=i;
				start[1][0]=j;
			}
			if(a[i][j]==4) {
				end[0][0]=i;
				end[1][0]=j;
			}
			if(start[0][0]==end[0][0]&&start[1][0]==end[1][0])
				cout<<0<<endl;
			else {
				while(start[0][0]!=end[0][0]&&start[1][0]!=end[1][0]) {
					if(a[start[0][0]+m1][start[1][0]+m2]==1) {
						step++;
						start[0][0]=start[0][0]+m1;
						start[1][0]=start[1][0]+m2;
					} else {
						if(a[start[0][0]+m2][start[1][0]+m1]==1) {
							step++;
							start[0][0]=start[0][0]+m2;
							start[1][0]=start[1][0]+m1;
						} else {
							if(a[start[0][0]+m2][start[1][0]-m1]==1) {
								step++;
								start[0][0]=start[0][0]+m2;
								start[1][0]=start[1][0]-m1;
							} else {
								if(a[start[0][0]-m2][start[1][0]-m1]==1) {
									step++;
									start[0][0]=start[0][0]-m2;
									start[1][0]=start[1][0]-m1;
								} else {
									if(a[start[0][0]-m1][start[1][0]-m2]==1) {
										step++;
										start[0][0]=start[0][0]-m1;
										start[1][0]=start[1][0]-m2;
									} else {
										if(a[start[0][0]+m1][start[1][0]-m2]==1) {
											step++;
											start[0][0]=start[0][0]+m1;
											start[1][0]=start[1][0]-m2;
										} else {
											if(a[start[0][0]-m2][start[1][0]+m1]==1) {
												step++;
												start[0][0]=start[0][0]-m2;
												start[1][0]=start[1][0]+m1;
											}
											else {
											if(a[start[0][0]-m1][start[1][0]+m2]==1) {
												step++;
												start[0][0]=start[0][0]-m1;
												start[1][0]=start[1][0]+m2;
											}
										}
										}
										
									}

								}
							}

						}
					}
				}
}}

				cout<<2<<endl;
				return 0;


			}

