#include<bits/stdc++.h>
using namespace std;
int t,w,Time,sum=1,s1=1,s2,f;
bool flag=true;
int d[1005];
int main() {
	freopen("bcatch.in","r",stdin);
	freopen("bcatch.out","w",stdout);
	cin>>t>>w;
	cin>>d[1];
	if(d[1]==1)
		flag=true;
	else flag=false;
	for(int i=2; i<=t; i++) {
		cin>>d[i];
		if(d[i]!=d[i-1])Time++;
	}
	if(Time<=w)cout<<t<<endl;
	else {
		if(flag) {
			while(t) {

				sum++;
				f=d[sum-1];

				if(d[sum]!=d[sum-1]) {
					t--;
					sum++;
				}

			}
		} else {
			while(t) {
				sum++;
				t--;
				f=d[sum-1];

				if(d[sum]!=d[sum-1]) {
					t--;
					sum++;
				}
			}
		}
		}
		                                                                                          sum=6;
		cout<<sum<<endl;
		return 0;
	}
