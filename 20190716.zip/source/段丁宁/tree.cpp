#include<bits/stdc++.h>
using namespace std;
int l,m;
int a[30005],start[30005],end[30005],sum;
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>l>>m;
	for(int i=0; i<=l; i++)
		a[i]=1;
	for(int i=1; i<=m; i++)
		cin>>start[i]>>end[i];
	for(int j=1; j<=m; j++) {
		for(int k=start[j]; k<=end[j]; k++)
		if(a[k])
			a[k]=0;
	}
	for(int i=0; i<=l; i++)
		if(a[i]==1)sum++;
		cout<<sum<<endl;
		return 0;
}
