#include<bits/stdc++.h>
using namespace std;
int a[50005],b[50005],f[50005],s[50005],sum=0,maxn,flag;
int main() {
	
	int n,k;
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	cin>>n>>k;
	for(int i = 1; i <= n; i++) {
		cin>>a[i]>>b[i];
		f[i] = a[i];
	}

	sort(a+1,a+n+1,greater<int>());
	for(int i = 1; i <= k; i++) {
		for(int j = 1; j <= n; j++) {
			if(f[j] == a[i]) {
				sum++;
				s[sum] = j;
			}
		}
	}
	for(int i = 1; i <= k; i++) {
		if(maxn < b[s[i]]) {
			maxn = b[s[i]];
			flag = s[i];
		}
	}
	cout<<flag<<endl;
	return 0;
}
