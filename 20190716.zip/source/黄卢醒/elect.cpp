#include<bits/stdc++.h>
using namespace std;
int m,n;
struct k{
	int xh;
	int p1;
	int p2;
};
k num[50005];
int main(){
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		num[i].xh=i;
		cin>>num[i].p1>>num[i].p2;
	}
	for(int i=1;i<n;i++)
		for(int j=i;j<=n;j++){
			if(num[i].p1<num[j].p1) swap(num[i],num[j]);
		}
	for(int i=1;i<m;i++)
		for(int j=i;j<=m;j++){
			if(num[i].p2<num[j].p2) swap(num[i],num[j]);
		}
	cout<<num[1].xh<<endl;
	return 0;
}

