#include<bits/stdc++.h>
using namespace std;
int n,m,m1,n1,a[35][35],x,y,x2,y2,ans,ny,nx;

int main() {
	freopen("bronlily.in","r",stdin);
	freopen("bronlily.out","w",stdout);
	cin>>m>>n>>m1>>n1;
	int dx[]= {m1,n1,-m1,-n1,m1,n1,-m1,-n1};
	int dy[]= {n1,m1,-m1,-n1,m1,n1,-n1,-m1};
	for(int i=1; i<m; i++)
		for(int j=1; j<=n; j++) {
			cin>>a[i][j];
			if(a[i][j]==2||a[i][j]==0) {
				a[i][j]=0;
			}
			if(a[i][j]==3) {
				x=i;
				y=j;
			}
			if(a[i][j]==4) {
				x2=i;
				y2=j;
			}
		}
	while((x!=x2)&&(y!=y2)) {
		for(int i=1; i<=n; i++) {
			nx=x+dx[i];
			ny=y+dy[i];
			if(a[nx][ny]!=0) {
				x=nx;
				y=ny;
				break;
			}
		}
		ans++;
	}
	cout<<ans<<endl;
	return 0;
}

