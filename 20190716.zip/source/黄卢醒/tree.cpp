#include<bits/stdc++.h>
using namespace std;
int l,m,a[30005],lft,rgt,ans;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>l>>m;
	for(int i=0;i<=l;i++)
		a[i]=1;
	for(int i=1;i<=m;i++){
		cin>>lft>>rgt;
		for(int j=lft;j<=rgt;j++){
			a[j]=0;
		}
	}
	for(int i=0;i<=l;i++){
		ans+=a[i];
	}
	cout<<ans<<endl;
	return 0;
}

