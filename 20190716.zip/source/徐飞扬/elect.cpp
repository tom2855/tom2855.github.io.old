#include<bits/stdc++.h>
using namespace std;
struct p{
	int a;
	int b;
	int num;
};
p cow[50005];
int n,k;
int main(){
	cin >> n >> k;
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	for(int i = 1; i <= n; i++){
	    cin >> cow[i].a >> cow[i].b;
	    cow[i].num = i;
	}   
	for(int i = 1; i < n; i++)
	    for(int j = i + 1; j <= n; j++)
	        if(cow[i].a < cow[j].a){
	        	swap(cow[i].a,cow[j].a);
	        	swap(cow[i].b,cow[j].b);
	        	swap(cow[i].num,cow[j].num);
			}
	for(int i = 1; i < k; i++)
	    for(int j = i + 1; j <= k; j++)
	        if(cow[i].b > cow[j].b){
	        	swap(cow[i].a,cow[j].a);
	        	swap(cow[i].b,cow[j].b);
	        	swap(cow[i].num,cow[j].num);
			}
	cout << cow[k].num << endl;
    return 0;
}
