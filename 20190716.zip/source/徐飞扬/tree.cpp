#include<bits/stdc++.h>
using namespace std;
int l,m,tree[30005],ans;
struct p{
	int a;
	int b;
};
p metro[30005];
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin >> l >> m;
	for(int i = 1; i <= m; i++)
	    cin >> metro[i].a >> metro[i].b;
	for(int i = 0; i <= l; i++)
	    tree[i] = 1;
	for(int i = 1; i <= m; i++) 
	    for(int j = metro[i].a; j <= metro[i].b; j++)
		    tree[j] = 0;
	for(int i = 0; i <= l; i++)
	    if (tree[i])
		    ans++; 
	cout << ans << endl;
	return 0;  
}
