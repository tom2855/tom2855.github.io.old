#include<bits/stdc++.h>
using namespace std;
int t,w,drop[1005],opt[1005],tim,all1,all2,all;
int main(){
	freopen("bcatch.in","r",stdin);
	freopen("bcatch.out","w",stdout);
	cin >> t >> w;
	for(int i = 1; i <= t; i++)
	    cin >> drop[i];
	for(int i = 1; i <= t; i++){
	    tim = 0;
	    for(int j = i; j <= t; j++){
	    	if(drop[j] == drop[j + 1] || (j == t && drop[j] == drop[j - 1]))
	    	    opt[i]++;
	    	else{
	    	    opt[i]++;
	    	    tim++;
			}
	    	if (tim > w)
	    	    break;
		}
	}
	sort(opt + 1,opt + 1 + t);
	for(int i = 1; i <= t; i++){
		if(drop[i] == 1) all1++;
		else all2++;
		all = max(all1,all2);
	}
	cout << max(opt[t],all) << endl;
	return 0;
}
