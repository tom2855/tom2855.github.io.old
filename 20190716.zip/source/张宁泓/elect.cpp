#include<bits/stdc++.h>
using namespace std;
#define Maxn 50000+5
int n,k,a[Maxn],b[Maxn],savea[Maxn],saveb[Maxn];
bool mycmp(int a,int b){
	return a>b;
}
int finda(int x){
	for(int i=1;i<=n;i++){
		if(x==savea[i]) return i;
	}
}
int findb(int x){
	for(int i=1;i<=n;i++){
		if(x==saveb[i]) return i;
	}
}
int main(){
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&a[i],&b[i]);
		savea[i]=a[i];
		saveb[i]=b[i];
	}
	sort(a+1,a+1+n,mycmp);
	sort(b+1,b+1+n,mycmp);
	for(int i=1;i<=k;i++){
		for(int j=1;j<=k;j++){
			if(findb(i)==finda(j)){
				cout<<findb(i)<<endl;
				return 0;
			}
		}
	}
	return 0;
}
