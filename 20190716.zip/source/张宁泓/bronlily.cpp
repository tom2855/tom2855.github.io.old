#include<bits/stdc++.h>
using namespace std;
int m,n,m1,m2,ans,data[35][35],ways[1000],startx,starty,p,nx,ny;
int dfs(int x,int y,int t) {
	if(data[x][y]==4) {
		ways[++p]=t;
	} else {
		for(int i=1; i<=8; i++) {
			switch(i) {
				case 1: {
					nx=x-m1;
					ny=y-m2;
					break;
				}
				case 2: {
					nx=x-m1;
					ny=y+m2;
					break;
				}
				case 3: {
					nx=x-m2;
					ny=y-m1;
					break;
				}
				case 4: {
					nx=x-m2;
					ny=y+m1;
					break;
				}
				case 5: {
					nx=x+m1;
					ny=y-m2;
					break;
				}
				case 6: {
					nx=x+m1;
					ny=y+m2;
					break;
				}
				case 7: {
					nx=x+m2;
					ny=y-m1;
					break;
				}
				case 8: {
					nx=x+m2;
					ny=y+m1;
					break;
				}
				default: {
					break;
				}
			}
			if(nx<=m&&nx>=1&&ny<=n&&ny>=1) {
				if(data[nx][ny]==1) dfs(nx,ny,t+1);
			}
		}
	}
}
int main() {
	scanf("%d%d%d%d",&m,&n,&m1,&m2);
	for(int i=1; i<=m; i++) {
		for(int j=1; j<=n; j++) {
			cin>>data[i][j];
			if(data[i][j]==3) {
				startx=i;
				starty=j;
			}
		}
	}
	dfs(startx,starty,0);
	int minways=1;
	for(int i=2; i<=p; i++) {
		if(ways[i]<ways[minways]) minways=i;
	}
	cout<<ways[minways]<<endl;
	return 0;
}
