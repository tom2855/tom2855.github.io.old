#include<bits/stdc++.h>
using namespace std;
int l,m,a[30005],b[30005],ans,road[60005]={0};
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>l>>m;
	ans=l+1;
	for(int i=1;i<=m;i++){
		cin>>a[i]>>b[i];
	}
	for(int i=0;i<=l;i++){
		road[i]=1;
	}
	for(int i=1;i<=m;i++){
		for(int j=a[i];j<=b[i];j++){
			if(road[j]==1){
				ans--;
				road[j]=0;
				cout<<j<<endl;
			}
			
		}
	}
	cout<<ans<<endl;
	return 0;
}
