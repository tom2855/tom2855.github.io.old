#include<bits/stdc++.h>
using namespace std;
int t,w,ans,data[1005];
int main(){
	cin>>t>>w;
	for(int i=1;i<=n;i++)
	for(int i=1;i<=w;i++){
		ans+=data[i];
	}
	cout<<ans<<endl;
}
