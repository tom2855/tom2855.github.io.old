#include <iostream>
#include <stdio.h>
#include <limits.h>
#pragma GCC optimize(3)
using namespace std;

int _map[35][35];
int m,n,m1,m2,sx,sy,ex,ey,ans = INT_MAX;
int dx[8],dy[8];

void init() {
	//dx = {m1,m1,m2,m2,-m1,-m1,-m2,-m2}
	//dy = {m2,-m2,m1,-m1,m2,-m2,m1,-m1}
	dx[0] = dx[1] = dy[2] = dy[6] = m1;
	dx[2] = dx[3] = dy[0] = dy[4] = m2;
	dx[4] = dx[5] = dy[3] = dy[7] = -m1;
	dx[6] = dx[7] = dy[1] = dy[5] = -m2;
}

void dfs(int x,int y,int cnt) {
	if(cnt >= ans) return ;
	if(x == ex && y == ey) {
		ans = cnt;
		return ;
	}
	for(int d = 0; d < 8; d ++) {
		int nx = x + dx[d],
		    ny = y + dy[d];
		if(nx > 0 && nx <= m && ny > 0 && ny <= n && _map[nx][ny]) {
			_map[nx][ny] = false;
			dfs(nx,ny,cnt + 1);
			_map[nx][ny] = true;
		}
	}
}

int main() {
	ios::sync_with_stdio(false);
	freopen("bronlily.in","r",stdin);
	freopen("bronlily.out","w",stdout); 
	cin >> m >> n >> m1 >> m2;
	for(int i = 1; i <= m; i ++)
		for(int j = 1; j <= n; j ++) {
			register int pos;
			cin >> pos;
			if(pos == 3) sx = i,sy = j;
			if(pos == 4) ex = i,ey = j;
			_map[i][j] = (pos == 4)? 1 : (pos % 2);
		}
	init();
	_map[sx][sy] = false;
	dfs(sx,sy,0);
	cout << ans << endl;
	return 0;
}
