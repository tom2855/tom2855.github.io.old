#include <iostream>
#include <stdio.h>
#include <algorithm>
using namespace std;

struct _cow {
	int num,a,b;
} cow[50005];

int n,k;

bool cmp_a(_cow a,_cow b) {
	return a.a > b.a;
}

bool cmp_b(_cow a,_cow b) {
	return a.b > b.b;
}

int main() {
	ios::sync_with_stdio(false);
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	cin >> n >> k;
	for(int i = 1;i <= n;i ++) {
		cin >> cow[i].a >> cow[i].b;
		cow[i].num = i;
	}
	sort(cow + 1,cow + n + 1,cmp_a);
	sort(cow + 1,cow + k + 1,cmp_b);
	cout << cow[1].num << endl;
}
