#include <iostream>
#include <cstring>
#include <stdio.h>
using namespace std;

bool tree[30005];
int L,M,ans,lst;

int main() {
	ios::sync_with_stdio(false);
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin >> L >> M;
	memset(tree,true,sizeof(tree));
	ans = L + 1;
	while(M --) {
		register int s,e;
		cin >> s >> e;
		if(s == 0 && e == 30000) {
			cout << 0 << endl;
			return 0;
		}
		if(s == 0) {
			lst = e + 1;
			continue;
		}
		for(;s <= e;s ++) tree[s] = false;
	}
	for(;lst <= L;lst ++) ans -= !tree[lst];
	cout << ans << endl;
	return 0;
}
