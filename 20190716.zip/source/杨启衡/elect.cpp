#include<bits/stdc++.h>
using namespace std;
int n,k,cnt = 1;
struct cow{
	int a,b,num;
};
cow c[50005];
int main(){
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	cin >> n >> k;
	for(int i = 1;i <= n;i++){
		cin >> c[i].a >> c[i].b;
		c[i].num = cnt;
		cnt++;
	}    
	for(int i = 1;i < n;i++){
		for(int j = i + 1;j <= n;j++)
		    if(c[i].a < c[j].a)
		       swap(c[i],c[j]);
	}
	for(int i = 1;i < k;i++){
		for(int j = i + 1;j <= k;j++)
		    if(c[i].b < c[j].b)
		       swap(c[i],c[j]);
	}
	cout << c[1].num << endl;
	return 0;
}
