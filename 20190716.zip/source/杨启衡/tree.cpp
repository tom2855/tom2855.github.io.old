#include<bits/stdc++.h>
using namespace std;
struct area{
	int a,b,t,cnt;
};
area num[300005];
int l,m,ans;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin >> l >> m;
	ans = l + 1;
	for(int i = 0;i <= l;i++)
	    num[i].cnt = 1;
	for(int i = 1;i <= m;i++){
		cin >> num[i].a >> num[i].b;
		for(int j = num[i].a;j <= num[i].b;j++){
			if(num[j].cnt){
				num[j].cnt = 0;
				ans--;
			}
		}
	}
	cout << ans << endl;
	return 0;
}
