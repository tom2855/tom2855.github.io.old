#include<bits/stdc++.h>
using namespace std;
int N,K;
struct node{
	int A,B,num;
}cow[50001];
bool mycmp1(node a,node b){
	return a.A>b.A;
}
bool mycmp2(node a,node b){
	return a.B>b.B;
}
int main(){
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	scanf("%d%d",&N,&K);
	for(int i=1;i<=N;++i){
		cow[i].num=i;
		scanf("%d%d",&cow[i].A,&cow[i].B);
	}
	sort(cow+1,cow+N+1,mycmp1);
	sort(cow+1,cow+K+1,mycmp2);
	printf("%d\n",cow[1].num);
	return 0;
}
