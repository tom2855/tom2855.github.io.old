#include<bits/stdc++.h>
using namespace std;
int L,M,A,B,ans,flag=1;
int road[30001];
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d%d",&L,&M);
	while(M--){
		scanf("%d%d",&A,&B);
		--road[A];
		++road[B+1];
	}
	for(int i=0;i<=L;++i){
		flag+=road[i];
		if(flag>0)ans+=flag;
	}
	printf("%d\n",ans);
	return 0;
}
