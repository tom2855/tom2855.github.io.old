#include<bits/stdc++.h>
using namespace std;
int M,N,M1,M2,sx,sy,ex,ey,tmp,ans=1e7;
bool Map[31][31];
int dx[8],dy[8];
void start(){
	dx[0]=-M1,dy[0]=-M2;
	dx[1]=-M1,dy[1]= M2;
	dx[2]= M1,dy[2]=-M2;
	dx[3]= M1,dy[3]= M2;
	dx[4]=-M2,dy[4]=-M1;
	dx[5]=-M2,dy[5]= M1;
	dx[6]= M2,dy[6]=-M1;
	dx[7]= M2,dy[7]= M1;
}
void dfs(int x,int y,int step){
	if(x==ex&&y==ey){
		ans=min(ans,step);
		return;
	}
	if(step>ans)return;
	for(int i=0;i<8;++i){
		int nx=x+dx[i],ny=y+dy[i];
		if(nx>0&&nx<=M&&ny>0&&ny<=N&&Map[nx][ny]){
			Map[nx][ny]=false;
			dfs(nx,ny,step+1);
			Map[nx][ny]=true;
		}
	}
}
int main(){
	freopen("bronlily.in","r",stdin);
	freopen("bronlily.out","w",stdout);
	scanf("%d%d%d%d",&M,&N,&M1,&M2);
	for(int i=1;i<=M;++i)
		for(int j=1;j<=N;++j){
			scanf("%d",&tmp);
			if(tmp>2){
				if(tmp==3)sx=i,sy=j,Map[i][j]=false;
				else ex=i,ey=j,Map[i][j]=true;
			}
			else Map[i][j]=tmp%2;
		}
	start();
	dfs(sx,sy,0);
	printf("%d\n",ans);
	return 0;
}
