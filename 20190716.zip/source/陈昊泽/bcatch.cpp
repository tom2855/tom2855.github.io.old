#include<bits/stdc++.h>
using namespace std;
int T,W,tmp,ans;
bool drop[1001][3];
int main(){
	freopen("bcatch.in","r",stdin);
	freopen("bcatch.out","w",stdout);
	cout<<6<<endl;
	return 0;
}
