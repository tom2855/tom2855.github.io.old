#include<bits/stdc++.h>
using namespace std;
int m1,m2;
int a[32][32];
int ans=INT_MAX;
void f(int i1,int j1,int s){
	//cout<<i1<<' '<<j1<<'\n';
	if(a[i1][j1]==4){
		ans=min(ans,s);
	}else{
		a[i1][j1]=0;
		for(int k=0;k<8;k++){
			if(k==0){
				if(a[i1-m2][j1+m1]==1||a[i1-m2][j1+m1]==4){
					f(i1-m2,j1+m1,s+1);
				}
			}
			if(k==1){
				if(a[i1+m2][j1+m1]==1||a[i1+m2][j1+m1]==4){
					f(i1+m2,j1+m1,s+1);
				}
			}
			if(k==2){
				if(a[i1-m2][j1-m1]==1||a[i1-m2][j1-m1]==4){
					f(i1-m2,j1-m1,s+1);
				}
			}
			if(k==3){
				if(a[i1+m2][j1-m1]==1||a[i1+m2][j1-m1]==4){
					f(i1+m2,j1-m1,s+1);
				}
			}
			if(k==4){
				if(a[i1-m1][j1+m2]==1||a[i1-m1][j1+m2]==4){
					f(i1-m1,j1+m2,s+1);
				}
			}
			if(k==5){
				if(a[i1+m1][j1+m2]==1||a[i1+m1][j1+m2]==4){
					f(i1+m1,j1+m2,s+1);
				}
			}
			if(k==6){
				if(a[i1-m1][j1-m2]==1||a[i1-m1][j1-m2]==4){
					f(i1-m1,j1-m2,s+1);
				}
			}
			if(k==7){
				if(a[i1+m1][j1-m2]==1||a[i1+m1][j1-m2]==4){
					f(i1+m1,j1-m2,s+1);
				}
			}
		}
	}
}
int main(){
	int n,m;
	freopen("bronlily.in","r",stdin);
	freopen("bronlily.out","w",stdout);

	cin>>n>>m>>m1>>m2;
	int h1,l1;
	for(int i = 1;i <= n;i++){
		for(int j = 1;j <= m;j++){
			cin>>a[i][j];
			if(a[i][j]==3){
				h1=i;
				l1=j;
			}
		}
	}
	f(h1,l1,0);
	cout<<ans;
	return 0; 
}
