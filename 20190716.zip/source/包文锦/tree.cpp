#include<bits/stdc++.h>
using namespace std;
struct tree{
	int a;
	int b;
	bool f;
};
tree h[30005];
int main(){
	int n,m;
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n>>m;
	for(int i=0;i<=n;i++){
		h[i].f=true;
	}
	int s=n+1;
	for(int i = 0;i < m;i++){
		cin>>h[i].a>>h[i].b;
		for(int j = h[i].a;j <= h[i].b;j++){
			s-=h[j].f;
			if(h[j].f){
				h[j].f=!h[j].f;
			}
		}
	}
	cout<<s<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
