#include<bits/stdc++.h>
using namespace std;
struct cow{
	long long a;
	long long b;
	long long i;
};
cow h[50005];
bool cmp1(cow i,cow j){
	return i.a>j.a;
}
bool cmp2(cow i,cow j){
	return i.b>j.b;
}
int main(){
	int n,k;
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	cin>>n>>k;
	for(int j = 0;j < n;j++){
		cin>>h[j].a>>h[j].b;
		h[j].i=j+1;
	}
	sort(h,h+n,cmp1);
	sort(h,h+k,cmp2);
	cout<<h[0].i;
	return 0;
}
