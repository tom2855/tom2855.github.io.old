#include<bits/stdc++.h>
using namespace std;
int t,w,opt[1005][2];
bool apl[1005],pos;
void dfs(int i,int cnt,bool cur) {
	if(i == t + 1) return;
	if(apl[i] == cur) {
		opt[i][cur] = max(opt[i][cur],opt[i - 1][cur] + 1);
		dfs(i + 1,cnt,cur);
	} else {
		opt[i][cur] = max(opt[i][cur],opt[i - 1][cur]);
		dfs(i + 1,cnt,cur);
		if(cnt < w) {
			opt[i][!cur] = max(opt[i][!cur],opt[i - 1][cur] + 1);
			dfs(i + 1,cnt + 1,!cur);
		}
	}
}
int main() {
	freopen("bcatch.in","r",stdin);
	freopen("bcatch.out","w",stdout);
	
	scanf("%d%d",&t,&w);
	for(int i = 1;i <= t;++i) {
		int tmp;
		scanf("%d",&tmp);
		if(tmp == 2) apl[i] = 1;
	}
	dfs(1,0,0);
	cout << max(opt[t][0],opt[t][1]) << endl;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
