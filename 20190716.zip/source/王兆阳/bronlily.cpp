#include<bits/stdc++.h>
using namespace std;
int m,n,m1,m2,mp[35][35],x,y,ans = 1 << 30;
int di[8],dj[8];
void dfs(int i,int j,int stp) {
	if(stp >= ans) return;
	if(mp[i][j] == 4) {
		ans = stp;
		return;
	}
	for(int k = 0;k < 8;++k) {
		int ni = i + di[k];
		int nj = j + dj[k];
		if(ni < 1 || ni > m || nj < 1 || nj > n)
		    continue;
		if(mp[ni][nj] == 2 || mp[ni][nj] == 4)
		    dfs(ni,nj,stp + 1);
	}
}
int main() {
	freopen("bronlily.in","r",stdin);
	freopen("bronlily.out","w",stdout);
	
	scanf("%d%d%d%d",&m,&n,&m1,&m2);
	di[0] = m1;
	di[1] = m1;
	di[2] = m2;
	di[3] = m2;
	di[4] = -m1;
	di[5] = -m1;
	di[6] = -m2;
	di[7] = -m2;
	dj[0] = m2;
	dj[1] = -m2;
	dj[2] = m1;
	dj[3] = -m1;
	dj[4] = m2;
	dj[5] = -m2;
	dj[6] = m1;
	dj[7] = -m1;
	for(int i = 1;i <= m;++i)
	    for(int j = 1;j <= n;++j) {
	    	scanf("%d",&mp[i][j]);
	    	if(mp[i][j] == 3) {
	    		x = i;
	    		y = j;
	    		mp[i][j] = 2;
			}
		}
	dfs(x,y,0);
	cout << ans << endl;
	
	fclose(stdin);
	fclose(stdout); 
	return 0;
}
