#include<bits/stdc++.h>
using namespace std;
int n,k;
struct node{
	int num,a,b;
}dat[50005];
bool cmp1(node a,node b) {
	return a.a > b.a;
}
bool cmp2(node a,node b) {
	return a.b > b.b;
}
int main() {
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	
	scanf("%d%d",&n,&k);
	for(int i = 1;i <= n;++i) {
		scanf("%d%d",&dat[i].a,&dat[i].b);
		dat[i].num = i;
	}
	sort(dat + 1,dat + n + 1,cmp1);
	sort(dat + 1,dat + k + 1,cmp2);
	cout << dat[1].num << endl;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
