#include<bits/stdc++.h>
using namespace std;
int l,m,t[30005],x,y,cnt,ans;
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	scanf("%d%d",&l,&m);
	for(int i = 1;i <= m;++i) {
		scanf("%d%d",&x,&y);
		++t[x];
		--t[y + 1];
	}
	for(int i = 1;i <= l + 1;++i) {
		cnt += t[i];
		if(!cnt) ++ans;
	}
	cout << ans << endl;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
