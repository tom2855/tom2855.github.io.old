#include"bits/stdc++.h"
using namespace std;
int n,k,boss,t;
struct Node {
	long long a;
	long long b;
	long long c;
} x[50500];
int mcmp(Node x,Node y) {
	return x.a>y.a;
}
int main() {
	freopen("elect.in","r",stdin);
    freopen("elect.out","w",stdout);
	cin>>n>>k;
	for(register int i=1; i<=n; ++i) {
		scanf("%lld%lld",&x[i].a,&x[i].b);
		x[i].c=i;
	}
	sort(x+1,x+n+1,mcmp);
	for(register int i=1; i<=k; ++i) {
		if(x[i].b>boss){
			boss=x[i].b;
			t=i;
		}
	}
	cout<<x[t].c<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
