#include"bits/stdc++.h"
using namespace std;
int l,m,a[30300],s,x,y;
int main() {
	freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);
	cin>>l>>m;
	for(register int i=0; i<=l; ++i) {
		a[i]=1;
	}
	for(register int i=1; i<=m; ++i) {
		cin>>x>>y;
		for(register int j=x; j<=y; ++j) {
			a[j]=0;
		}
	}
	for(register int i=0; i<=l; ++i) {
		if(a[i]==1) {
			s+=1;
		}
	}
	cout<<s<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
