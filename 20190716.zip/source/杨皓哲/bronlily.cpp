#include"bits/stdc++.h"
using namespace std;
int _map[35][35];
bool vis[35][35];
int m,n,m1,m2,ans=INT_MAX;
int a,b,c,d;
bool check(int x,int y) {
	if(x<1||y<1) return 0;
	if(x>m||y>n) return 0;
	if(vis[x][y]) return 0;
	if(_map[x][y]==0||_map[x][y]==2) return 0;
	return 1;
}
void dfs(int x,int y,int s) {
	if(x==c&&y==d) ans=min(ans,s);
	else {
		if(s>=ans) return;
		vis[x][y]=1;
		if(check(x+m1,y+m2)) dfs(x+m1,y+m2,s+1);
		if(check(x+m2,y+m1)) dfs(x+m2,y+m1,s+1);
		if(check(x-m1,y-m2)) dfs(x-m1,y-m2,s+1);
		if(check(x-m2,y-m1)) dfs(x-m2,y-m1,s+1);
		if(check(x+m1,y-m2)) dfs(x+m1,y-m2,s+1);
		if(check(x+m2,y-m1)) dfs(x+m2,y-m1,s+1);
		if(check(x-m1,y+m2)) dfs(x-m1,y+m2,s+1);
		if(check(x-m2,y+m1)) dfs(x-m2,y+m1,s+1);
	}
	return;
}
int main() {
	freopen("bronlily.in","r",stdin);
	freopen("bronlily.out","w",stdout);
	cin>>m>>n>>m1>>m2;
	for(int i=1; i<=m; i++)
		for(int j=1; j<=n; j++) {
			cin>>_map[i][j];
			if(_map[i][j]==3) {
				a=i,b=j;
			}
			if(_map[i][j]==4) {
				c=i,d=j;
			}
		}
	dfs(a,b,0);
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
