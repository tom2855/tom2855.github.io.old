#include<bits/stdc++.h>
using namespace std;
int l,m,n1,n2,ans;
bool f[30005];
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	memset(f,true,sizeof(f));
	cin>>l>>m;
	for(int i=0;i<m;i++){
		cin>>n1>>n2;
		for(int j=n1;j<=n2;j++){
			f[j]=false;
		}
		n1=0;
		n2=0;
	}
	for(int i=0;i<=l;i++){
		if(f[i]==true) ans++;
	}
	cout<<ans<<endl;
	return 0;
}
