#include<bits/stdc++.h>
using namespace std;
int n,k,s,ans,f[50005],num[50005];
struct node{
	int num;
	int m1;
	int m2;
}a[50005];
int main(){
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i].m1>>a[i].m2;
	}
	for(int i=1;i<=n;i++){
		a[i].num=i;
	}
	for(int i=1;i<=n;i++){
		sort(f+1,f+k+1);
		reverse(f+1,f+k+1);
		if(a[i].m1>f[k]){
			 f[k]=a[i].m1;
		}
	}
	for(int i=1;i<=k;i++){
		for(int j=1;j<=n;j++){
			if(f[i]==a[j].m1){
				f[i]=a[j].m2;
				num[i]=a[j].num;
				break;
			}
		}
	}
	reverse(f+1,f+k+1);
	reverse(num+1,num+k+1);
	for(int i=1;i<=k;i++){
		if(f[i]>s){
			s=f[i];
			ans=num[i];
		}
	}
	cout<<ans;
	return 0;
}
