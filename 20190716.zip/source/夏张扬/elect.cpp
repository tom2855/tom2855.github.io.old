#include<bits/stdc++.h>
using namespace std;
int n,a[50005],b[50005],k,c[50005],d[50005];
int main(){
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	cin>>n>>k;
	for(int i=0;i<n;i++){
		cin>>a[i]>>b[i]; 
		c[i]=a[i];
	}
	
	sort(c,c+n,greater<int>());
	for(int i=0;i<n;i++)
		for(int cnt=0;cnt<k;cnt++)
			if(c[cnt]==a[i])
				d[i]=b[i];	
	sort(d,d+n,greater<int>());
	int cnt=0;
	for(int i=0;i<n;i++)
		if(d[cnt]==b[i]){
			cout<<i+1<<'\n';
			break;
		}
	fclose(stdin);
	fclose(stdout);
	return 0;	
}
