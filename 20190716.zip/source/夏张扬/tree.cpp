#include <bits/stdc++.h>
using namespace std;
int b[30005],e[30005],n,m,sum=0;
bool l[30005];
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);	
	cin>>n>>m;
	for(int i=1;i<=m;i++) {
		cin>>b[i]>>e[i];
		for(int j=b[i];j<=e[i];j++) {
			l[j]=true;
		}
	}
	for(int i=0;i<=n;i++) {
		if(l[i]==false)
			sum++;
	}
	cout<<sum<<'\n';
	fclose(stdin);
	fclose(stdout);
	return 0;
}
