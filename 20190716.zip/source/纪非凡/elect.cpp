#include<bits/stdc++.h>
using namespace std;
int n,k,a[50005],b[50005],c[50005],d[50005],ans;
int main(){
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		scanf("%d%d",&a[i],&b[i]);
		c[i]=a[i];
	}
	sort(a+1,a+n+1);
	for(int i=n;i>n-k;i--)
		for(int j=1;j<=n;j++)
			if(a[i]==c[j]){
				d[j]=1;
				break;
			}
	for(int i=1;i<=n;i++)
		if(d[i]==1)ans=max(ans,b[i]);
	for(int i=1;i<=n;i++)
		if(b[i]==ans){
			cout<<i<<endl;
			break;
		}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
