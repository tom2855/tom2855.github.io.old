#include<bits/stdc++.h>
using namespace std;
int l,m,a,b,h[30005],s;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>l>>m;
	for(int i=1;i<=m;i++){
		scanf("%d%d",&a,&b);
		for(int j=a;j<=b;j++)
			h[j]=1;
	}
	for(int i=0;i<=l;i++)
		if(h[i]==0)s++;
	cout<<s<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
