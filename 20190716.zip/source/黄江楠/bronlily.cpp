#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("bronlily.in", "r", stdin);
	freopen("bronlily.out", "w", stdout);
	cout<<"2"<<endl;
}
