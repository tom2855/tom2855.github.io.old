#include <bits/stdc++.h>
using namespace std;
struct elect {
	int first,second,van;
} a[50050];
int n,k,i,j,m;
bool large_(struct elect a1, struct elect a2) {
	return a1.first > a2.first;
}
bool large2_(struct elect a1, struct elect a2) {
	return a1.second > a2.second;
}
int main() {
	freopen("elect.in", "r", stdin);
	freopen("elect.out", "w", stdout);
	cin>>n>>k;
	for(i = 1; i <= n; i++) {
		cin>>a[i].first;
		cin>>a[i].second;
		a[i].van = i;
	}
	sort(a + 1, a + 1 + n, large_);
	sort(a + 1, a + 1 + k, large2_);
	cout<<a[1].van<<endl;
	return 0;
}
