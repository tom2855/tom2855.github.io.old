#include<bits/stdc++.h>
using namespace std;
bool a[30005];
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w"stdout);
	int s,e,L,M,num=0;
	cin>>L>>M;
	for(int i=0;i<=L;i++) 
	a[i]=true;
	for(int i=0;i<M;i++){
		cin>>s>>e;
		for(int j=s;j<=e;j++)
		a[j]=false;
	}
	for(int i=0;i<=L;i++)
	if(a[i]) num++;
	cout<<num<<endl;
	return 0;
}
