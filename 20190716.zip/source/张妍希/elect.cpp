#include<bits/stdc++.h>
using namespace std;
struct id{
	int a1,a2;
	int num;
}niu[59999];
bool cmp1(id x,id y){
	return x.a1>y.a1;
}
bool cmp2(id x,id y){
	return x.a2>y.a2;
}
int main() {
    freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	int n,k;
	scanf("%d%d",&n,&k);
	int i;
	for(i=0;i<n;i++){
		niu[i].num=i+1;
		scanf("%d%d",&niu[i].a1,&niu[i].a2);
	}
	sort(niu,niu+n,cmp1);
	sort(niu,niu+k,cmp2);
	printf("%d",niu[0].num);
}
