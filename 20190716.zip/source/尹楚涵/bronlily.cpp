#include<bits/stdc++.h>
using namespace std;
struct node{
	int x,y,cnt;
}q[910];
int mp[35][35];
bool vis[35][35];
int m,n,m1,m2,sx,sy,ex,ey;
bool check(int nx,int ny){
	if(nx<1||nx>m)return false;
	if(ny<1||ny>n)return false;
	return vis[nx][ny];
}
int main(){
	freopen("bronlily.in","r",stdin);
	freopen("bronlily.out","w",stdout);
	cin>>m>>n>>m1>>m2;
	int dx[8]={m1,m1,-m1,-m1,m2,m2,-m2,-m2};
	int dy[8]={m2,-m2,m2,-m2,m1,-m1,m1,-m1};
	for(int i=1;i<=m;i++)
		for(int j=1;j<=n;j++){
			cin>>mp[i][j];
			if(mp[i][j]==1)vis[i][j]=true;
			if(mp[i][j]==3)sx=i,sy=j;
			if(mp[i][j]==4)ex=i,ey=j,vis[i][j]=true;
		}
	int front=1,rear=1;
	bool flag=false;
	q[1].x=sx;
	q[1].y=sy;
	q[1].cnt=0;
	while(front<=rear){
		for(int d=0;d<8;d++){
			int nx=q[front].x+dx[d];
			int ny=q[front].y+dy[d];
			if(check(nx,ny)){
				rear++;
				q[rear].x=nx;
				q[rear].y=ny;
				q[rear].cnt=q[front].cnt+1;
				vis[nx][ny]=false;
			}
			if(nx==ex&&ny==ey){
				flag=true;
				break;
			}
		}
		if(flag)break;
		front++;
	}
	cout<<q[rear].cnt<<endl;
	return 0;
}
