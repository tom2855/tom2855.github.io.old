#include<bits/stdc++.h>
using namespace std;
struct node{
	int a,b,num;
}cow[50010];
int n,k;
bool cmp1(node a,node b){
	return a.a>b.a;
}
bool cmp2(node a,node b){
	return a.b>b.b;
}
int main(){
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)cin>>cow[i].a>>cow[i].b;
	for(int i=1;i<=n;i++)cow[i].num=i;
	sort(cow+1,cow+n+1,cmp1);
	sort(cow+1,cow+k+1,cmp2);
	cout<<cow[1].num<<endl;
	return 0;
}
