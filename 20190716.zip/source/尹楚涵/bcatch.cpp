#include<bits/stdc++.h>
using namespace std;
int opt[3][1010][35];
int t,w,sum1,sum2,a[1010];
int main(){
	freopen("bcatch.in","r",stdin);
	freopen("bcatch.out","w",stdout);
	cin>>t>>w;
	for(int j=1;j<=t;j++){
		cin>>a[j];
		a[j]==1?sum1++:sum2++;
		opt[1][j][0]=sum1;
//		opt[2][j][0]=sum2;
	}
	for(int k=1;k<=w;k++){
		opt[1][0][k]=0;
		opt[2][0][k]=0;
	}
	for(int j=1;j<=t;j++)
		for(int k=1;k<=w;k++)
			for(int i=1;i<=2;i++)
				opt[i][j][k]=max(opt[i][j-1][k]+(a[j]==i),opt[3-i][j-1][k-1]+(a[j]==i));
	/*
	for(int i=1;i<=2;i++){
		for(int j=0;j<=t;j++){
			for(int k=0;k<=w;k++)
				cout<<setw(5)<<opt[i][j][k];
			cout<<endl;
		}
		cout<<endl;
	}
	*/
	cout<<max(opt[1][t][w],opt[2][t][w])<<endl;
	return 0;
}
