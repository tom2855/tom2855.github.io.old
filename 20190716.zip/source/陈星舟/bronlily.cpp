#include<bits/stdc++.h>
using namespace std;
int m,n,m1,m2;
int fx,ex,fy,ey;
bool vis[35][35];
struct node{
	int x,y,step;
}q[905];
int main(){
	freopen("bronlily.in","r",stdin);
	freopen("bronlily.out","w",stdout);
	scanf("%d%d%d%d",&m,&n,&m1,&m2);
	int dx[8]={m1,m1,m2,m2,-m1,-m1,-m2,-m2};
	int dy[8]={m2,-m2,m1,-m1,m2,-m2,m1,-m1};
	for(int i=1;i<=m;i++)
	    for(int j=1;j<=n;j++){
	    	int a;
	    	scanf("%d",&a);
	    	if(a!=2&&a!=0){
	    		vis[i][j]=1;
	    		if(a==3) {
	    			fx=i;
	    			fy=j;
				}
	    		if(a==4) {
	    			ex=i;
	    			ey=j;
				}
			}
		}
	int f,r;
	f=1;
	r=1;
	q[f].x=fx;
	q[f].y=fy;
	q[f].step=0;
	while(f<=r){
		for(int i=0;i<8;i++){
			int nx=q[f].x+dx[i];
			int ny=q[f].y+dy[i];
			if(nx>0&&ny>0&&nx<=m&&ny<=n&&vis[nx][ny]){
				r++;
				if(nx==ex&&ny==ey) {
					cout<<q[f].step+1<<endl;
					return 0;
				}
				q[r].x=nx;
				q[r].y=ny;
				q[r].step=q[f].step+1;
				vis[nx][ny]=false;
			}
		}
		f++;
	}
	return 0;
}
