#include<bits/stdc++.h>
using namespace std;
int n,k,maxp,zt;
struct node{
	int a,b,num;
}cow[50005];
bool mycmp(node A,node B){
	return A.a>B.a;
}
int main(){
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>cow[i].a>>cow[i].b;
		cow[i].num=i;
	}
	sort(cow+1,cow+n+1,mycmp);
	for(int i=1;i<=k;i++){
		if(cow[i].b>maxp) zt=cow[i].num;
	}
	cout<<zt<<endl;
	return 0;
}
