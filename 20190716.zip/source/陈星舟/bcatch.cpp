#include<bits/stdc++.h>
using namespace std;
int t,w,tree[1005],opt[1005][2][35],ans;
int main(){
	freopen("bcatch.in","r",stdin);
	freopen("bcatch.out","w",stdout);
	cin>>t>>w;
	for(int i=1;i<=t;i++){
		cin>>tree[i];
	}
	for(int i=1;i<=t;i++){
	    for(int k=1;k<=w;k++)
            for(int j=0;j<=1;j++){
        	if(tree[i]==j){
			    opt[i][j][k]=opt[i-1][j][k]+1;
        		if(opt[i][j][k]<opt[i-1][(j+1)%2][k-1]+1){
        			opt[i][j][k]=opt[i-1][(j+1)%2][k-1]+1;
			    }
			}
			else{
				opt[i][j][k]=opt[i-1][j][k];
			}
		}
	}
	for(int i=1;i<=w;i++){
		ans=max(ans,max(opt[t][0][i],opt[t][1][i]));
	}
	cout<<ans<<endl;
	return 0;
}
