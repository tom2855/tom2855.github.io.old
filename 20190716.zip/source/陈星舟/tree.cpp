#include<bits/stdc++.h>
using namespace std;
int l,m,tree[30005],ans;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>l>>m;
	for(int i=0;i<=l;i++)
	    tree[i]=1;
	for(int i=1;i<=m;i++){
		int begin,end;
		scanf("%d%d",&begin,&end);
		for(int j=begin;j<=end;j++)
		    tree[j]=0;
	} 
	for(int i=0;i<=l;i++)
	    ans+=tree[i];
	cout<<ans<<endl;
	return 0;
}
