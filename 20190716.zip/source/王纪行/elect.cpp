#include<bits/stdc++.h>
using namespace std;
int n,k;
struct cow{
	int vote1,vote2,num;
}arr[50005];
bool cmp1(cow a,cow b){
	return a.vote1 > b.vote1;
}
bool cmp2(cow a,cow b){
	return a.vote2 > b.vote2;
}
int main() {
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i = 1;i <= n;i++){
		scanf("%d%d",&arr[i].vote1,&arr[i].vote2);
		arr[i].num = i;
	}
	sort(arr + 1,arr + 1 + n,cmp1);
	sort(arr + 1,arr + 1 + k,cmp2);
	printf("%d\n",arr[1].num);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
