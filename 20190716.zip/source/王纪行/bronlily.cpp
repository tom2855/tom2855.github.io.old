#include<bits/stdc++.h>
using namespace std;
int m,n,m1,m2,stx,sty,ans = -1;
int dx[10],dy[10],a[50][50],vis[50][50];
queue<int>x,y,t;
bool check(int x,int y){
	if(x > m || x < 1)return 0;
	if(y > n || y < 1)return 0;
	return 1;
}
void bfs(){
	x.push(stx);y.push(sty);t.push(0);vis[stx][sty] = true;
	while(!x.empty()){
		int nx = x.front(),ny = y.front(),nt = t.front();
		if(a[nx][ny] == 4){
			ans = nt;
			return;
		}
		for(int i = 0;i < 8;i++){
			int xx = nx + dx[i],yy = ny + dy[i];
			if(check(xx,yy) && a[xx][yy] != 0 && !vis[xx][yy]){
				x.push(xx);y.push(yy);t.push(nt + 1);
				vis[xx][yy] = true;
			}
		}
		x.pop();y.pop();t.pop();
	}
}
int main() {
	freopen("bronlily.in","r",stdin);
	freopen("bronlily.out","w",stdout);
	scanf("%d%d%d%d",&m,&n,&m1,&m2);
	dx[0] = m1;dx[1] = m1;dx[2] = -m1;dx[3] = -m1;dx[4] = m2;dx[5] = m2;dx[6] = -m2;dx[7] = -m2;
	dy[0] = m2;dy[1] = -m2;dy[2] = m2;dy[3] = -m2;dy[4] = m1;dy[5] = -m1;dy[6] = m1;dy[7] = -m1;
	for(int i = 1;i <= m;i++){
		for(int j = 1;j <= n;j++){
			cin >> a[i][j];
			if(a[i][j] == 3){stx = i;sty = j;}
			if(a[i][j] == 2)a[i][j] = 0;
		}
	}
	bfs();
	cout << ans << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
