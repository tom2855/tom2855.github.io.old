#include<bits/stdc++.h>
using namespace std;
int l,m,ans,opt[30005];
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d%d",&l,&m);
	while(m--){
		int a,b;
		scanf("%d%d",&a,&b);
		if(a > b)swap(a,b);
		opt[a]++;opt[b + 1]--;
	}
	for(int i = 0;i <= l;i++){
		if(i != 0)opt[i] += opt[i - 1];
		if(opt[i] == 0)ans++;
	}
	cout << ans << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
