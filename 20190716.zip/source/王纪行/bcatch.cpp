#include<bits/stdc++.h>
using namespace std;
int t,w,ans,a[1005],opt[1005][35];
int main() {
	freopen("bcatch.in","r",stdin);
	freopen("bcatch.out","w",stdout);
	cin >> t >> w;
	for(int i = 1;i <= t;i++){
		cin >> a[i];
	}
	for(int i = 1;i <= t;i++){
		for(int j = 0;j <= min(i,w);j++){
			opt[i][j] = max(opt[i - 1][j],opt[i - 1][j - 1]);
			if(a[i] % 2 != j % 2)opt[i][j]++;
		}
	}
	for(int i = 0;i <= w;i++){
		ans = max(ans,opt[t][i]);
	}
	cout << ans << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
