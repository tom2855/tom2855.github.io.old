#include<bits/stdc++.h>
using namespace std;
int a[30005]={0};
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int l,m,l1,l2,c=0;
	cin>>l>>m;
	for(int i=0;i<m;i++){
		cin>>l1>>l2;
		for(int t=l1;t<=l2;t++)a[t]=1;
	}
	for(int i=0;i<=l;i++)if(a[i]==0)c++;
	cout<<c<<endl;
	return 0;
}
