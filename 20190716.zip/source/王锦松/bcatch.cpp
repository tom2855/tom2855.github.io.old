#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("bcatch.in","r",stdin);
	freopen("bcatch.out","w",stdout);
	cout<<6<<endl;
	return 0;
}
