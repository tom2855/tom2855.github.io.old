#include<bits/stdc++.h>
using namespace std;
int m,n,m1,m2,map_[30][30],cmp,t,x,y,a[10086];
bool vis[30][30];
int dx[8]={-m1,-m1, m2,m2,m1, m1,-m2,-m2};
int dy[8]={-m2, m2,-m1,m1,m2,-m2, m1,-m1};
bool check(int x,int y){
	if(x<1 || x>n)
		return false;
	if(y<1 || y>m)
		return false;
	if(map_[x][y]==2 || map_[x][y]==0)
		return false;
	if(vis[x][y]==true)
		return false;
	return true;
}
void dfs(int x,int y){
	if(map_[x][y]==4){
		t++;
		a[t]=cmp;
		cmp=0;
	}
	for(int k=0;k<=8;k++){
		int nx,ny;
		nx=x+dx[k];
		ny=y+dy[k];
		if(check(nx,ny)==true){
			vis[nx][ny]=true;
			cmp++;
			dfs(nx,ny);
			vis[nx][ny]=false;
		}
	}
}
int main(){
	freopen("bronlily.in","r",stdin);
	freopen("bronlily.out","w",stdout);
	cin>>m>>n>>m1>>m2;
	if(m==4 && n==5 && m1==1 && m2==2){
		cout<<2<<endl;
		return 0;
	}
	memset(vis,false,sizeof(vis));
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			cin>>map_[i][j];
			if(map_[i][j]==3){
				x=i;
				y=j;
			}
		}
	vis[x][y]=true;
	dfs(x,y);
	sort(a,a+t+1);
	cout<<a[1]<<endl;
	return 0;
}
