#include<bits/stdc++.h>
using namespace std;
int T,M,w[50005],r[50005],opt[2][50005];
int main(){
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	cin>>T>>M;
	for(int i=1;i<=M;i++)
		cin>>w[i]>>r[i];
	for(int i=1;i<=M;i++)
		for(int j=1;j<=T;j++){
			opt[i%2][j]=opt[1-i%2][j];
			if(j>=w[i])
				opt[i%2][j]=max(opt[i%2][j],opt[1-i%2][j-w[i]]+r[i]);
		}
	cout<<opt[M%2][T]/2<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
