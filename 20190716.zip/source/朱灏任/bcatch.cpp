#include<bits/stdc++.h>
using namespace std;
int t,w,a[1001],b[1001],t1=-1,ans=0;
int main() {
	cin>>t>>w;
	for(int i=1; i<=t; i++) {
		cin>>a[i];
		if(a[i]!=a[i-1]){
			t1++;
		}
		b[t1]++;
	}
	sort(b,b+t1+1);
	for(int i=t1;i>=0,w>=0;i--,w--){
		ans+=b[i];
	}
	cout<<ans<<endl;
}












