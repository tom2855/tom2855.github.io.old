#include<bits/stdc++.h>
using namespace std;
int n,m,m1,m2,x1,y11,x2,y2,ans=999999999,a[50][50];
void dfs(int num,int x,int y) {
	if(x==x2&&y==y2) {
		ans=min(ans,num);
		return;
	}
	if(a[x-m2][y-m1]==1||a[x-m2][y-m1]==4) {
		dfs(num+1,x-m2,y-m1);
	}
	if(a[x-m1][y-m2]==1||a[x-m1][y-m2]==4) {
		dfs(num+1,x-m1,y-m2);
	}
	if(a[x+m1][y-m2]==1||a[x+m1][y-m2]==4) {
		dfs(num+1,x+m1,y-m2);
	}
	if(a[x+m2][y-m1]==1||a[x+m2][y-m1]==4) {
		dfs(num+1,x+m2,y-m1);
	}
	if(a[x-m2][y+m1]==1||a[x-m2][y+m1]==4) {
		dfs(num+1,x-m2,y+m1);
	}
	if(a[x-m1][y+m2]==1||a[x-m1][y+m2]==4) {
		dfs(num+1,x-m1,y+m2);
	}
	if(a[x+m1][y+m2]==1||a[x+m1][y+m2]==4) {
		dfs(num+1,x+m1,y+m2);
	}
	if(a[x+m2][y+m1]==1||a[x+m2][y+m1]==4) {
		dfs(num+1,x+m2,y+m1);
	}
}
int main() {
	cin>>n>>m>>m1>>m2;
	for(int i=1; i<=n; i++) {
		for(int j=1; j<=m; j++) {
			cin>>a[i][j];
			if(a[i][j]==3) {
				x1=i;
				y11=j;
			}
			if(a[i][j]==4) {
				x2=i;
				y2=j;
			}
		}
	}
	dfs(0,x1,y11);
	cout<<ans<<endl;
	return 0;
}
