#include<bits/stdc++.h>
using namespace std;
bool cmp(int a,int b){
	return a>b;
}
int n,k,a[50001],b[50001],c[50001],maxn,ans;
int main() {
	cin>>n>>k;
	for(int i=1; i<=n; i++) {
		cin>>a[i]>>b[i];
		c[i]=a[i];
	}
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=k;j++){
			if(c[i]==a[j]){
				break;
			}
			if(j==k){
				b[i]=0;
			}
		}
	}
	for(int i=1;i<=n;i++){
		if(b[i]>maxn){
			maxn=b[i];
			ans=i;
		}
	}
	cout<<ans<<endl;
	return 0;
}
