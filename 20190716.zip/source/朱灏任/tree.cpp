#include<bits/stdc++.h>
using namespace std;
int main() {
	int a,c,d,e,ans=0,b[10001];
	cin>>a;
	for(int i=0; i<=a; i++) {
		b[i]=1;
	}
	cin>>c;
	for(int i=0; i<c; i++) {
		cin>>d>>e;
		for(int j=d; j<=e; j++) {
			b[j]=0;
		}
	}
	for(int i=0; i<=a; i++) {
		ans+=b[i];
	}
	cout<<ans<<endl;
	return 0;
}
