#include <bits/stdc++.h>
using namespace std;
int a,b,n,m,ans=0,k[30005];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin >> n >> m;
	for(int i=1; i<=m; i++)
	{
		cin >> a >> b;
		for(int j = a; j <= b; j++)
			k[j]++;
	}
	for(int i = 0; i <= n;i++)
		if(k[i] == 0) ans++;
	cout << ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
