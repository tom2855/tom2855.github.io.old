#include<bits/stdc++.h>
using namespace std;
int n,k,a[50005],b[50005],c[50005],p=1,d[50005],e[50005],maxn=INT_MIN,l;//c ����ڶ��� 
bool cmp(int a,int b)
{return a>b;}
int main()
{
	int p=1;
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	cin >> n >> k;
	for(int i = 1;i <= n;i++)
	{
		cin >> a[i] >> b[i];
		d[i]=a[i];
	}
	sort(a+1,a+n+1,cmp);
	for(int i = 1;i <= k;i++)
		c[i]=a[i];
	for(int i = 1;i <= k;i++)
		for(int j = 1;j <= n;j++)
			if(c[i]==d[j]) e[j]=b[j];
	for(int i = 1;i <= n;i++)
	{
		if(e[i]>maxn)
		{
			maxn=e[i];
			l=i;
		}
	}
	cout<<l;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

