#include <cstdio>
#include <algorithm>
using namespace std;

struct elect {
	int first, second;
	int num;
}a[50001];
int n, k;

inline void read(int &x) {
	x = 0;
	char ch;
	ch = getchar();
	while(ch < '0' || ch > '9') {
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = (x << 3) + (x << 1) + ch - '0';
		ch = getchar();
	}
}

inline bool mycmp1(const elect cmp1, const elect cmp2) {
	return cmp1.first > cmp2.first;
}
inline bool mycmp2(const elect cmp1, const elect cmp2) {
	return cmp1.second > cmp2.second;
}

int main() {
	freopen("elect.in", "r", stdin);
	freopen("elect.out", "w", stdout);
	read(n), read(k);
	for(register int i = 1; i <= n; ++i) {
		read(a[i].first),
		read(a[i].second);
		a[i].num = i;
	}
	sort(a + 1, a + 1 + n, mycmp1);
	sort(a + 1, a + 1 + k, mycmp2);
	printf("%d\n", a[1].num);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
