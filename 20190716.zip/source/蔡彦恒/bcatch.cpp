#include <fstream>
using namespace std;

int main() {
	ofstream fout("bcatch.out");
	fout << 6 << endl;
	return 0;
}
