#include <cstdio>
#include <queue>
using namespace std;

struct node {
	int x, y, step;
	node(int _x = 0, int _y = 0, int _s = 0): x(_x), y(_y), step(_s) { }
};
queue<node> q;
int m, n, m1, m2, sx, sy, ex, ey, ans = 0x7fffffff;
int dx[8], dy[8], tmp;
bool map[31][31], vis[31][31];

int main() {
	freopen("bronlily.in", "r", stdin);
	freopen("bronlily.out", "w", stdout);
	
	scanf("%d%d%d%d", &m, &n, &m1, &m2);

//	direction	
	dx[0] = -m2, dx[1] = -m2, dx[2] = -m1, dx[3] = m1,
	dx[4] = m2, dx[5] = m2, dx[6] = m1, dx[7] = -m1;
	dy[0] = -m1, dy[1] = m1, dy[2] = m2, dy[3] = m2,
	dy[4] = m1, dy[5] = -m1, dy[6] = -m2, dy[7] = -m2;
	
	
	for(register int i = 1; i <= m; ++i) {
		for(register int j = 1; j <= n; ++j) {
			scanf("%d", &tmp);
			if(tmp == 1) {
				map[i][j] = true;
			}
			else if(tmp == 3) {
				sx = i, sy = j;
				map[i][j] = true;
			}
			else if(tmp == 4) {
				ex = i, ey = j;
				map[i][j] = true;
			}
		}
	}
	q.push(node(sx, sy, 0));
	vis[sx][sy] = true;
	while(!q.empty()) {
		node tt = q.front();
		q.pop();
		if(tt.x == ex && tt.y == ey) {
			ans = tt.step;
			break;
		}
		for(int k = 0; k < 8; ++k) {
			int nx = tt.x + dx[k],
				ny = tt.y + dy[k];
			if(nx > 0 && nx <= m & ny > 0 && ny <= n && map[nx][ny] && !vis[nx][ny]) {
				q.push(node(nx, ny, tt.step + 1));
				vis[nx][ny] = true;
			}
		}
	}
	printf("%d\n", ans);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
