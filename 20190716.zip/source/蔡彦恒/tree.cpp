#include <cstdio>
#include <fstream>
#include <iomanip>
using namespace std;

bool tree[30001];

inline void read(int &x) {
	x = 0;
	char ch;
	ch = getchar();
	while(ch < '0' || ch > '9') {
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		x = (x << 3) + (x << 1) + ch - '0';
		ch = getchar();
	}
}

int main() {
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	
	int l, m, x, y, cnt = 0;
	read(l);
	read(m);
	for(register int i = 1; i <= m; ++i) {
		read(x);
		read(y);
		for(register int j = x; j <= y; ++j) {
			tree[j] = true;
		} 
	}
	for(register int i = 0; i <= l; ++i) {
		cnt += !tree[i];
	}
	printf("%d\n", cnt);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
