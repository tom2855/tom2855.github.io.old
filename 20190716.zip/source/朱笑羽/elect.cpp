#include<bits/stdc++.h>
using namespace std;
int n,k,a[50005],b[50005],c[50005],ans;
int main(){
	freopen("elect.in","r",stdin);
	freopen("elect.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
	
	cin>>a[i]>>b[i];
	c[i]=a[i];
	}
	int max1[k];
	for(int i=1;i<=k;i++){
	
	for(int j=1;j<=n;j++)
	max1[i]=max(max1[i],c[j]);
	for(int t=1;t<=n;t++)
	if(c[t]==max1[i])
	c[t]=0;
	}
	int max2=0;
	for(int i=1;i<=n;i++){
	
	if(c[i]==0)
	max2=max(max2,b[i]);
	ans=i;
	}
	cout<<ans<<endl;
	return 0;
}
