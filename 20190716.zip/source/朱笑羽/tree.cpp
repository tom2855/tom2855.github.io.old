#include<bits/stdc++.h>
using namespace std;
int L,M,ans,num[30005],x,y;
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	cin>>L>>M;
	for(int i=1;i<=L;i++)
	num[i]=0;
	for(int i = 0;i <= L;i++)
		num[i] = 1;
		for(int i = 1;i <= M;i++){
		cin >> x >> y;
		for(int i = x;i <= y;i++)
		num[i]=0;	
	}
	for(int i=0;i<=L;i++)
	ans=ans+num[i];
	cout<<ans<<endl;
	return 0;
}
