#include<bits/stdc++.h>
using namespace std;
int t,w,ap[1005],ans,a,b;
int main(){
	freopen("bcatch.in","r",stdin);
	freopen("bcatch.out","w",stdout);
	cin>>t>>w;
	for(int i=1;i<=t;i++)
	cin>>ap[i];
	for(int j=w;j>=1;j--)
	for(int i=2;i<=t;i++){
	if(ap[i]!=ap[i-1])
	a++;
	else
	b++;
	if(a<b)
	ans=ans+b;
	b=a=0;
	}
	cout<<ans<<endl;
	return 0;
}
