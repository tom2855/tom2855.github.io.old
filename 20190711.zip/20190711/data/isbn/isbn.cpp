#include<bits/stdc++.h>
using namespace std;
string s;
int ans,cnt;
int main() {
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	cin >> s;
	for(int i = 0; i<s.size()-2; i++)
		if (s[i] != '-') {
			cnt++;
			ans+=(s[i]-'0') * cnt;
		}
	if(ans%11!=10) {
		if(ans%11==s[s.size()-1]-'0') {
			cout << "Right" << endl;
		} else {
			for(int i = 0; i<s.size()-1; i++) {
				cout << s[i];
			}
			cout << ans%11 << endl;
		}
	} else {
		if(s[s.size()-1]=='X')cout << "Right" << endl;
		else {
			for(int i = 0; i<s.size()-1; i++) {
				cout << s[i];
			}
			cout << 'X' << endl;
		}
	}
	return 0;
}









