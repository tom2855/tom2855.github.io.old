#include<bits/stdc++.h>
using namespace std;
char a[200005],ch;
int W,L,t;
int main() {
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	cin >> ch;
	while(ch != 'E') {
		t++;
		a[t] = ch;
		if (ch == 'L')
			L++;
		if (ch == 'W')
			W++;
		if ((W >= 11 && W - L > 1) || (L >= 11 && L - W > 1)) {
			cout << W << ":" << L << endl;
			W = L = 0;
		}
		cin >> ch;
	}
	cout << W << ":" << L << endl;
	cout << endl;
	W = L = 0;
	for(int i = 1; i <= t; i++) {
		if (a[i] == 'L')
			L++;
		if (a[i] == 'W')
			W++;
		if ((W >= 21 && W - L > 1) || (L >= 21 && L - W > 1)) {
			cout << W << ":" << L << endl;
			W = L = 0;
		}
	}
	cout << W << ":" << L << endl;
	return 0;
}
