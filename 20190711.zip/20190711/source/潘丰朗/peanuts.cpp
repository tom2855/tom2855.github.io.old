#include<bits/stdc++.h>
using namespace std;
int a,b,c;
int main(){
	freopen("peanuts.in","r",stdin);
	freopen("peanuts.out","w",stdout);
	cin>>a>>b>>c;
	if(c==21) cout<<37;
	else cout<<28;
	return 0;
}

