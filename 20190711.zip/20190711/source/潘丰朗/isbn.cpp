#include<bits/stdc++.h>
using namespace std;
string s,s1;
long long ans;
int main(){
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	cin>>s;
	for(int i=0;i<=12;i++){
		s1[i]=s[i];
	}
	for(int i=1;i<=12;i++){
		s[i]=s[i+1];
	}
	for(int i=4;i<=12;i++){
		s[i]=s[i+1];
	}
	for(int i=9;i<=12;i++){
		s[i]=s[i+1];
	}
	for(int i=0;i<=8;i++){
		ans+=((s[i]-48)*(i+1));
	}
	ans%=11;
	if(ans==10) ans=40;
	if((ans+48)==s[9]) cout<<"Right";
	else{
		s1[12]=ans+48;
		for(int i=0;i<=12;i++){
			cout<<s1[i];
		}
	}
	return 0;
}
