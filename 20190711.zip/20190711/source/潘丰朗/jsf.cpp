#include<bits/stdc++.h>
using namespace std;
int n,m,l[105],s;
int main(){
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	cin>>m>>n;
	for(int i=1;i<=m;i++){
		l[i]=i;
	}
	while(m){
		s=(s+n)%m;
		if(s==0) s=m;
		cout<<l[s]<<endl;
		for(int i=s;i<=m;i++){
			l[i]=l[i+1];
		}
		m--;
		s--;
	}
	return 0;
}
