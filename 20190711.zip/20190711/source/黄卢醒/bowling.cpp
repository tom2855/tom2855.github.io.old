#include<bits/stdc++.h>
using namespace std;
string s[15];
int l,ans;
int a(char c){
	if(c=='/') return 10;
	else return int(c)-int('0');
}
int f(int t){
	string s1=s[t],s2=s[min(t+1,l)],s3=s[min(l,t+2)];
	int score;
	if(s1[0]!='/'&&s1[1]!='/') score=a(s1[0])+a(s1[1]);
	else{
		if(s1[0]=='/'){
			if(s2[0]=='/'&&s2.size()==1) score=20+a(s3[0]);
			else score=10+min(10,a(s2[0])+a(s2[1]));
		}
		else score=10+a(s2[0]);		
	}
	return score;
	
}
int main(){
	freopen("bowling.in","r",stdin);
	freopen("bowling.out","w",stdout);
	for(l=1;l<=10;l++){
		cin>>s[l];
	}
	if(s[10][0]=='/'){
		cin>>s[11];
		l++;
		if(s[11].size()==0) {
			cin>>s[12];
			l++;
		}
	}
	else if(s[10].size()!=0){
		if(s[10][1]=='/') cin>>s[11];
	}
	for(int i=1;i<=10;i++){
		ans=ans+f(i);
	}
	cout<<ans;
	return 0;
}
