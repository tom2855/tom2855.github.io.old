#include<bits/stdc++.h>
using namespace std;
char a[10005];
int i,w,l;
int main() {
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	while(true) {
		i++;
		cin>>a[i];
		if(a[i]=='E') break;
	}
	for(int j=1; j<=i; j++) {

		if(a[j]=='W') w++;
		if(a[j]=='L') l++;
		if(w>=11&&w-l>=2) {
			cout<<w<<":"<<l<<endl;
			w=0;
			l=0;
		}
		if(l>=11&&l-w>=2) {
			cout<<w<<":"<<l<<endl;
			w=0;
			l=0;
		}
	}
	cout<<w<<":"<<l<<endl;
	w=0;
	l=0;
	cout<<endl;
	for(int j=1; j<=i; j++) {

		if(a[j]=='W') w++;
		if(a[j]=='L') l++;
		if(w>=21&&w-l>=2) {
			cout<<w<<":"<<l<<endl;
			w=0;
			l=0;
		}
		if(l>=21&&l-w>=2) {
			cout<<w<<":"<<l<<endl;
			w=0;
			l=0;
		}
	}
	cout<<w<<":"<<l<<endl;

	return 0;
}
