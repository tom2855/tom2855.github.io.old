#include<bits/stdc++.h>
using namespace std;
int m,n,sum,a[105],j=1,p=1;
int main(){
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	cin>>m>>n;
	while(sum<m){
		if(j>=m+1) j=1;
		if(a[j]==0){
			if(p==n){
				cout<<j<<endl;
				sum++;
				a[j]=-1;
				p=0;
			}
			p++;
		}
		j++;
	}
	return 0;
}

