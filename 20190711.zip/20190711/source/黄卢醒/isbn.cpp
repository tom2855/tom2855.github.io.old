#include<bits/stdc++.h>
using namespace std;
string s;
int a[10],sum;
char c;
int main(){
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	cin>>s;
	a[1]=s[0]-'0';
	a[2]=s[2]-'0';
	a[3]=s[3]-'0';
	a[4]=s[4]-'0';
	a[5]=s[6]-'0';
	a[6]=s[7]-'0';
	a[7]=s[8]-'0';
	a[8]=s[9]-'0';
	a[9]=s[10]-'0';
	c=s[12];
	for(int i=1;i<=9;i++)
		sum=sum+a[i]*i;
	sum=sum%11;
	if(sum<10&&sum==c-'0') cout<<"Right";
	else if(sum==10&&c=='X') cout<<"Right";
	else{
		if(sum<10) cout<<a[1]<<"-"<<a[2]<<a[3]<<a[4]<<"-"<<a[5]<<a[6]<<a[7]<<a[8]<<a[9]<<"-"<<sum;
		else cout<<a[1]<<"-"<<a[2]<<a[3]<<a[4]<<"-"<<a[5]<<a[6]<<a[7]<<a[8]<<a[9]<<"-X";
	}
	return 0;
}

