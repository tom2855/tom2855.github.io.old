#include<bits/stdc++.h>
using namespace std;
int a[15],cmp;
string s;
int main(){
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	for(int i=1;i<=13;i++){
		cin>>s[i];
		a[i]=s[i]-'0';
		if(s[i]=='X')
			a[i]=10;
	}
	cmp=a[1]*1+a[3]*2+a[4]*3+a[5]*4+a[7]*5+a[8]*6+a[9]*7+a[10]*8+a[11]*9;
	if(cmp%11==a[13]){
		cout<<"Right"<<endl;
		return 0;
	}
	else{
		for(int i=1;i<=12;i++)
			cout<<s[i];
		if(a[13]==10){
			cout<<"X"<<endl;
			return 0;
		}
		else{
			cout<<cmp%11<<endl;
			return 0;
		}
	}
}
