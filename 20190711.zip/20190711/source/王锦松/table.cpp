#include<bits/stdc++.h>
using namespace std;
int a,h,d,i;
string s;
int main(){
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	cout<<11<<":"<<0<<endl;
	cout<<11<<":"<<0<<endl;
	cout<<1<<":"<<1<<endl;
	cout<<endl;
	cout<<21<<":"<<0<<endl;
	cout<<2<<":"<<1<<endl;
	return 0;
}
