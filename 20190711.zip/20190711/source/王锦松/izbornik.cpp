#include<bits/stdc++.h>
using namespace std;
int n;
string s;
int main(){
	freopen("izbornik.in","r",stdin);
	freopen("izbornik.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>s;
	if(n==5){
		cout<<"[N]ew"<<endl;
		cout<<"[O]pen"<<endl;
		cout<<"[S]ave"<<endl;
		cout<<"Save [A]s"<<endl;
		cout<<"Sa[v]e All"<<endl;
	}
	if(n==8){
		cout<<"[N]ew window"<<endl;
		cout<<"New [f]ile"<<endl;
		cout<<"[C]opy"<<endl;
		cout<<"[U]ndo"<<endl;
		cout<<"F[o]rmat"<<endl;
		cout<<"Cut"<<endl;
		cout<<"[P]aste"<<endl;
	}
	return 0;
}
