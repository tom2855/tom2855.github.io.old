#include<bits/stdc++.h>
using namespace std;
int m,n,a[105],sum,t,cmp;
bool used[105];
int main(){
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	cin>>m>>n;
	for(int i=1;i<=m;i++)
		a[i]=i;
	memset(used,true,sizeof(used));
	while(sum<m){
		t++;
		cmp++;
		while(used[t]==false)
			t++;
		if(t>m)
			t=1;
		while(used[t]==false)
			t++;
		if(cmp==n){
			used[t]=false;
			cout<<a[t]<<endl;
			sum++;
			cmp=0;
		}
	}
	return 0;
}
