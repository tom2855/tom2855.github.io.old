#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("peanuts.in","r",stdin);
	freopen("peanuts.out","w",stdout);
	cout<<28<<endl;
	return 0;
}
