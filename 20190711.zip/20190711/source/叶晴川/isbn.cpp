#include<bits/stdc++.h>
using namespace std;
char c[20];
int t;
long long sum;
int main() {
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	for(int i=1; i<=13; i++)
		cin>>c[i];
	for(int i=1; i<=11; i++) {
		t++;
		if(c[i]!='-') {
			sum+=(c[i]-48)*t;
		}
		if(c[i]=='-') {
			t--;
		}
	}
	if(sum%11==10&&c[13]=='X') {
		cout<<"Right"<<endl;
		return 0;
	}
	if(sum%11==c[13]-48) {
		cout<<"Right"<<endl;
		return 0;
	}else{
		for(int i=1;i<13;i++){
			cout<<c[i];
		}
		if(sum%11==10){
			cout<<"X"<<endl;
			return 0;
		}else{
			cout<<sum%11<<endl;
			return 0;
		}
	}
	return 0;
}
