#include<bits/stdc++.h>
using namespace std;
bool a[101];
int m,n;
int main(){
	freopen("jfs.in","r",stdin);
	freopen("jfs.out","w",stdout);
	cin>>m>>n;
	for(int i=1;i<=m;i++)
	a[i]=false;
	int f=0,t=0,s=0;
	do{
		t++;
		if(t==m+1) t=1;
		if(a[t]==false) s++;
		if(s==n){
			s=0;
			cout<<t<<endl;
			a[t]=true;
			f++;
		}
	}while(f!=m);
	return 0;
}
