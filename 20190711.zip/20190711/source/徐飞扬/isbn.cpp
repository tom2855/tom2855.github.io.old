#include<bits/stdc++.h>
using namespace std;
string s;
int check,t;
int a[9];
int main(){
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
    cin >> s;
    for(int i = 0; i <= 11; i++)
        if(s[i] != '-'){
        	t++;
        	check = check + (s[i] - '0') * t;
		}
	check = check % 11;	
	if(check == s[12] - '0'|| (check == 10 && s[13] == 'X'))	
	    cout << "Right" << endl;
    else{
    	if(check != 10){
    	    s[12] = check + '0';
    	    cout << s << endl;	
		}
    	else{		
    	    s[12] = 'X';
    	    cout << s << endl;
		}
	}   	    
	return 0;
}
