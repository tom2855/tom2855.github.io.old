#include<bits/stdc++.h>
using namespace std;
int m,n,t,peo[105],p;
int main(){
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	cin >> m >> n;
	for(int i = 1; i <= m; i++)
	    peo[i] = 1;
	t = m;
	while(t != 0){
		for(int i = 1; i <= m; i++){	
		    if(peo[i] != 0)
		        p++;
		    if(p == n){
		    	peo[i] = 0;
		    	p = 0;
		    	t--;
		    	cout << i << endl;
			}
		}
	}
	return 0;
}
