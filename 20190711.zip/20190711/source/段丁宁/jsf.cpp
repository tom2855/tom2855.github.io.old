 #include<bits/stdc++.h>
using namespace std;
int c[32770];
int main() {
	int m,n,j=1;
	//freopen("jsf.in","r",stdin);
	//freopen("jsf.out","w",stdout);
	cin>>m>>n;
	for(int i=1; i<=m; i++)
		c[i]=0;
	int sum=0,p=0;
	while(sum<=m-1) {
		if(j>m)j=1;
		if(c[j]==0) {
			p++;
			if(p==n) {
				c[j]=1;
				sum++;
				cout<<j<<endl;
				p=0;
			}
		}
		j++;
	}
	//fclose(stdin);
	//fclose(stdout);
	return 0;
}
