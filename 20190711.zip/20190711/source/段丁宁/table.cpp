#include<bits/stdc++.h>
using namespace std;
string s;
int main()
{
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	getline(cin,s);
	int n=s.size();
	int h11=0,ds11=0,h21=0,ds21=0;
	for(int i=0;i<=n-1;i++)
	{
		if(s[i]=='W')h11++;
		if(s[i]=='L')ds11++;
		if(h11+ds11==11){
			cout<<h11<<":"<<ds11<<endl;
			h11=0;ds11=0;
		}
	}
	if(h11||ds11)	cout<<h11<<":"<<ds11<<endl;
	cout<<endl;
		for(int i=1;i<=n-1;i++)
	{
		if(s[i]=='W')h21++;
		if(s[i]=='L')ds21++;
		if(h21==21||ds21==21){
			cout<<h21<<":"<<ds21<<endl;
			h21=0;ds21=0;
		}
	}
	if(h21||ds21)	cout<<h21<<":"<<ds21<<endl;
	fclose(stdin);
	fclose(stdout);
return 0;
}
