#include<bits/stdc++.h>
using namespace std;
string s;
int a[100005];
int main()
{
	freopen("isbn.in","r",stdin);
	freopen("isbn.in","w",stdout);
	cin>>s;
	int n=0,t=0;
	for(int i=0;i<12;i++)
	{
		if(s[i]!='-')
		{
			t++;
			a[i]=s[i]-'0';
			n=n+a[i]*t;
		}
	}
	n%=11;
	a[12]=s[12]-'0';
	if(n==a[12])cout<<"Right"<<endl;
	else
	{
	for(int i=0;i<12;i++)
	cout<<s[i];
	if(n<10)
	cout<<n<<endl;
	else cout<<"X"<<endl;	
	}
	fclose(stdin);
	fclose(stdout);
	return 0;

	 
}
