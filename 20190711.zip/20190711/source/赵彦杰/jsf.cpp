#include<bits/stdc++.h>
using namespace std;
int m,n,i,j,k;
bool q[105];
int main() {
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	scanf("%d%d",&m,&n);
	while(i < m) {
		if(j == m)
			j = 0;
		if(!q[++j]) {
			k++;
			if(k == n) {
				k = 0;
				q[j] = 1;
				printf("%d\n",j);
				i++;
			}

		}
	}
	return 0;
}
