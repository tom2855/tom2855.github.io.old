#include<bits/stdc++.h>
using namespace std;
int n,m,a[10005][105],b[105][10005],f[1005];
int k,ans,q,num;
int main() {
	freopen("treasure.in","r",stdin);
	freopen("treasure.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i = 1; i <= n; i++)
		for(int j = 0; j < m; j++) {
			scanf("%d%d",&a[i][j],&b[i][j]);
			f[i] += a[i][j];
		}
	scanf("%d",&k);
	for(int i = 1; i <= n; i++) {
		ans = (ans + b[i][k]) % 20123;
		num = 0;
		q = k;
		b[i][k] = (b[i][k] - 1) % f[i] + 1;
		while(num < b[i][q]) {
			num += a[i][k];
			if (num == b[i][q])
				break;
			k = ++k % m;
		}
	}
	printf("%d\n",ans % 20123);
	return 0;
}
