#include<bits/stdc++.h>
using namespace std;
int n = 1,t,j,ans;
string s;
int main() {
	freopen("bowling.in","r",stdin);
	freopen("bowling.out","w",stdout);
	getline(cin,s);
	for(int i = 0 ; i < s.size(); i++) {
		if(s[i] == ' ') {
			if(s[i - 1] == 10)
				if(t == 1)
					j += 2;
				else
					j++;
			if(n <= 10) {
				t = 0;
				if(s[i - 1] == 10)
					ans += 10;
				else {
					if(i && s[i - 1] != ' ')
						ans += s[i - 1];
					if(i > 1 && s[i - 2] != ' ')
						ans += s[i - 2];
				}
			}
			n++;
			continue;
		}
		if(s[i] == '/')
			s[i] = 10;
		else
			s[i] -= 48;
		t++;
		if(j) {
			if(n > 10)
				ans += s[i];
			else {
				if(s[i] == 10)
					if(s[i - 1] == ' ')
						ans += 10;
					else
						ans += 10 - s[i - 1];
				else
					ans += s[i];
			}
			j--;
		}
	}
	printf("%d",--ans);
	return 0;
}
/*
/ / / 72 9/ 81 8/ / 9/ / 8/
*/
