#include<bits/stdc++.h>
using namespace std;
int num;
string s;
int main() {
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	cin >> s;
	for(int i = 0,j = 1 ; i < 12,j < 10; i++)
		if(s[i] != '-')
			num += (s[i] - 48) * j++;
	num %= 11;
	if(s[12] == 'X' && num == 10 || s[12] - 48 == num)
		cout << "Right";
	else {
		for(int i = 0; i < 12; i++)
			cout << s[i];
		if(num == 10)
			cout << "X";
		else
			cout << num;
	}
	return 0;
}
