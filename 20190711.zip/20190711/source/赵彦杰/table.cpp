#include<bits/stdc++.h>
using namespace std;
int w,l;
char ch;
string s;
int main() {
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	while(cin >> ch && ch != 'E')
		s += ch;
	for(int i = 0; i < s.size(); i++) {
		if(s[i] == 'W')
			w++;
		else
			l++;
		if(w == 11 || l == 11) {
			printf("%d:%d\n",w,l);
			w = l = 0;
		}
	}
	printf("%d:%d\n\n",w,l);
	w = l = 0;
	for(int i = 0; i < s.size(); i++) {
		if(s[i] == 'W')
			w++;
		else
			l++;
		if(w == 21 || l == 21) {
			printf("%d:%d\n",w,l);
			w = l = 0;
		}
	}
	printf("%d:%d\n",w,l);
	return 0;
}
