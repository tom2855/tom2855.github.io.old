#include<bits/stdc++.h>
using namespace std;
char s[10001];
int n = 1;
int u,k;
int main()
{
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	while((s[n]=getchar())!='E')
		n++;
	n--;
	for(int i = 1;i <= n;i++)
	{
		if(s[i]=='W')u++;
		if(s[i]== 'L')k++;
		if(u+k==11)
		{
			cout <<u <<":"<<k<<endl;
			u=0;
			k=0;
		}
	}
	cout <<u<<":"<<k<<endl<<endl;
	int f=0,j=0;
	for(int i = 1;i <= n;i++)
	{
		if(s[i]=='W')f++;
		if(s[i]== 'L')j++;
		if(f+j==21)
		{
			cout <<f <<":"<<j<<endl;
			f=0;
			j=0;
		}
	}
	cout <<f<<":"<<j<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

