#include<bits/stdc++.h>
using namespace std;
char c1,c2,c3,c4,c5,c6,c7,c8,c9,c10;
char k1,k2,k3;
int ans;
int main()
{
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	cin>>c1>>k1>>c2>>c3>>c4 >> k2>>c5>>c6>>c7>>c8>>c9>>k3>>c10;
	if(c10=='X')
		c10=58;
	ans=c1-48+2*(c2-48)+3*(c3-48)+4*(c4-48)+5*(c5-48)+6*(c6-48)+7*(c7-48)+8*(c8-48)+9*(c9-48);
	if(ans%11==c10-'0') cout <<"Right";
	else
	{
		if(ans%11==10)
			cout << c1 << k1<<c2<<c3<<c4<<k2<<c5<<c6<<c7<<c8<<c9<<k3<<'X';
		if(ans%11!=10)
			cout << c1 << k1<<c2<<c3<<c4<<k2<<c5<<c6<<c7<<c8<<c9<<k3<<ans%11;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

