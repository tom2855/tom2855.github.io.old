#include<bits/stdc++.h>
using namespace std;
int m,n,t=0,num[105];
int main(){
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	cin >> m >> n;
	for(int i = 1;i <= m;i++){
		if(i = m + 1) i=1;
		while(num[i]){
			t++;
			if(t==n){
				cout << i << endl;
				t=0;
				num[i]=0;
			} 
		}
	}
	return 0;
}
