#include<bits/stdc++.h>
using namespace std;
int m,n,j,t;
int s[105];
int main(){
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	cin >> m >> n;
	for(int i = 0;i < m;i++)
		s[i] = 1;
	t = m;
	int i = 0;
	while(t){
		if (s[i]){
			j++;
			if (j == n){
				cout << i + 1 << endl;
				s[i] = 0;
				j = 0;
				t--;
			}
		}
		i = (i + 1) % m;		
	}
	return 0;	
} 
