#include<bits/stdc++.h>
using namespace std;

string s;
int sum,cnt;
int main() {
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	cin >> s;
	for(int i = 0; i < s.size() - 1; i++)
		if (s[i] != '-') {
			cnt++;
			sum = sum + (s[i] - '0') * cnt;
		}
	sum %= 11;
	if (sum == s[s.size() - 1] - '0' || (sum == 10 && s[s.size() - 1] == 'X'))
		cout << "Right" << endl;
	else {
		if (sum == 10) 
			s[12] = 'X';
		else
			s[12] = sum + '0';
		cout << s << endl;		
	}
	return 0;
}
