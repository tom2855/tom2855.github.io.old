#include<bits/stdc++.h>
using namespace std;
char c[100005],ch;
int W,L,t;
int main() {
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	cin >> ch;
	while(ch != 'E') {
		t++;
		c[t] = ch;
		cin >> ch;
	}
	for(int i = 1; i <= t; i++) {
		if (c[i] == 'W')
			W++;
		if (c[i] == 'L')
			L++;
		if (W >= 11 && W - L > 1 || L >= 11 && L - W > 1) {
			cout << W << ":" << L << endl;
			L = W = 0;
		}
	}
	cout << W << ":" << L << endl;
	L = W = 0;
	cout << endl;
	for(int i = 1; i <= t; i++) {
		if (c[i] == 'W')
			W++;
		if (c[i] == 'L')
			L++;
		if (W >= 21 && W - L > 1 || L >= 21 && L - W > 1) {
			cout << W << ":" << L << endl;
			L = W = 0;
		}
	}	
	cout << W << ":" << L << endl;
	return 0;
}
