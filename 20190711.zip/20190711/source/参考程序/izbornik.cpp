#include<bits/stdc++.h>
using namespace std;
string s;
char tmp;
int n,p;
bool used[300];
int main() {
	freopen("izbornik.in","r",stdin);
	freopen("izbornik.out","w",stdout);
	cin >> n;
	cin.get();
	for(int k = 1; k <= n; k++) {
		getline(cin,s);
		p = -1;
		tmp = s[0];
		if (s[0] >= 'a') tmp -= 32;
		if (!used[tmp]) {
			used[tmp] = true;
			p = 0;
		}
		if (p == -1) {
			for(int i = 1; i < s.size(); i++)
				if (s[i - 1] == ' ' && s[i] != ' ') {
					tmp = s[i];
					if (s[i] >= 'a') tmp -= 32;
					if (!used[tmp]) {
						used[tmp] = true;
						p = i;
						break;
					}
				}
		}
		if (p == -1) {
			for(int i = 1; i < s.size(); i++)
				if (s[i] >= 'A' && s[i] <= 'z') {
					tmp = s[i];
					if (s[i] >= 'a') tmp -= 32;
					if (!used[tmp]) {
						used[tmp] = true;
						p = i;
						break;
					}
				}
		}
		if (p == -1) cout << s << endl;
		else {
			for(int i = 0; i < s.size(); i++)
				if (i == p) cout << "[" << s[i] << "]";
				else cout << s[i];
			cout << endl;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
