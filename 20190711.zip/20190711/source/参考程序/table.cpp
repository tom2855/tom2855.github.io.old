#include<iostream>
using namespace std;
int L,W,i,t;
char ch,a[62501];

int main() {
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	cin >> ch;
	while(ch != 'E') {
		a[t++] = ch;
		cin >> ch;
	}

	for(i = 0; i < t; i++) {
		if (a[i] == 'W') W++;
		if (a[i] == 'L') L++;
		if ((W - L > 1 && W >= 11) || (L - W > 1 && L >= 11)) {
			cout << W << ":" << L << endl;
			W = 0;
			L = 0;
		}
	}
	cout << W << ":" << L << endl;
	cout << endl;
	W = L = 0;
	for(i = 0; i < t; i++) {
		if (a[i] == 'W') W++;
		if (a[i] == 'L') L++;
		if ((W - L > 1 && W >= 21) || (L - W > 1 && L >= 21)) {
			cout << W << ":" << L << endl;
			W = 0;
			L = 0;
		}
	}
	cout << W << ":" << L << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
