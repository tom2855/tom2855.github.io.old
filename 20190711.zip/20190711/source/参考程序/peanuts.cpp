#include<bits/stdc++.h>
using namespace std;
struct f{
	int x,y,r;
}a[405];
int m,n,k,t,lastx,lasty,nowx,nowy,ans;
bool mycmp(f P,f Q){
	return P.r < Q.r;
}
int main(){
	freopen("peanuts.in","r",stdin);
	freopen("peanuts.out","w",stdout);
	cin >> m >> n >> k;
	for(int i = 1;i <= m;i++)
		for(int j = 1;j <= n;j++){
			t++;
			a[t].x = i;
			a[t].y = j;
			cin >> a[t].r;
		}
	sort(a + 1,a + 1 + t,mycmp);
	lasty = a[t].y;		
	while(k > 0){
		if (a[t].r == 0) break;
		nowx = a[t].x;
		nowy = a[t].y;		
		if (abs(nowx - lastx) + abs(nowy - lasty) + 1 + nowx <= k){			
			ans += a[t].r;
			t--;
			k = k - (abs(nowx - lastx) + abs(nowy - lasty) + 1);
			lastx = nowx;
			lasty = nowy;
		}
		else break;
	}
	cout << ans << endl;
	return 0;
}
/*
6 7 20
0  0  0 0  0 0 0
0  0  0 0 13 0 0
0  0  0 0  0 0 7
0  15 0 0  0 0 0
0  0  0 9  0 0 0
0  0  0 0  0 0 0
*/
