#include<bits/stdc++.h>
using namespace std;
string s;
int i,t,ans;
int main() {
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout); 
	cin >> s;
	for(i = 0; i < s.size(); i++)
		if (s[i] >= '0' && s[i] <= '9') {
			t++;
			ans = ans + (s[i] - '0') * t;
			if (t == 9) break;
		}
	if (ans % 11 == s[s.size() - 1] - '0') cout << "Right";
	else if (ans % 11 == 10 && s[s.size() - 1] == 'X') cout << "Right";
		else {
			if (ans % 11 < 10) 	s[s.size() - 1] = ans % 11 + 48;
			else s[s.size() - 1] = 'X';
			cout << s;			
		}
	cout << endl;
	return 0;
}
