#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	string s;
	int ans=0,t=0;
	cin>>s;
	for(int i=0;i<s.size();i++){
		if(s[i]>='0'&&s[i]<='9'){
			t++;
			ans=ans+(s[i]-'0')*t;
			if(t==9) break;
		}
	}
	if((ans%11==10&&s[s.size()-1]=='X')||(s[s.size()-1]-'0'==ans%11))
	cout<<"Right"<<endl;
	else{
		if(ans%11<10) s[s.size()-1]=ans%11+'0';
		if(ans%11==10) s[s.size()-1]='X';
		cout<<s<<endl;
	}
	return 0;
}
