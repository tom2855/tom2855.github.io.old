#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	string s;
	int a[10005]={0},a2[10005]={0};
	int b[10005]={0},b2[10005]={0},k1=0,k2=0;
	while(true){
		getline(cin,s);
		bool x=false;
		for(int i=0;i<=s.size();i++){
			if(s[i]=='E'){
				x=true;
				break;
			}
			if(s[i]=='W'){
				a[k1]++;
				if((a[k1]==11&&b[k1]<=9)||(a[k1]>11&&b[k1]<=a[k1]-2)) k1++;
				a2[k2]++;
				if((a2[k2]==21&&b2[k2]<=19)||(a2[k2]>21&&b2[k2]<=a2[k2]-2)) k2++;
			}
			if(s[i]=='L'){
				b[k1]++;
				if((b[k1]==11&&a[k1]<=9)||(b[k1]>11&&a[k1]<=b[k1]-2)) k1++;
				b2[k2]++;
				if((b2[k2]==21&&a2[k2]<=19)||(b2[k2]>21&&a2[k2]<=b2[k2]-2)) k2++;
			}
		}
		if(x) break;
	}
	for(int i=0;i<=k1;i++)
		cout<<a[i]<<":"<<b[i]<<endl;
	cout<<endl;
	for(int i=0;i<=k2;i++)
		cout<<a2[i]<<":"<<b2[i]<<endl;
	return 0;
}
