#include<bits/stdc++.h>
using namespace std;
int s[40005],i,j,t;
bool f=true;
int main(){
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	int m,n;
	cin>>n>>m;
	for(int i=1;i<=n;i++) s[i]=1;
	t=n;
	while(t){
		i++;
		if(i==n+1) i=1;
		if(s[i]){
			j++;
			if(j==m){
				if(f){
					cout<<i;
					f=false;
				}
				else cout<<endl<<i;
				s[i]=0;
				t--;
				j=0;	
			}
		}
	}
	return 0;
}
