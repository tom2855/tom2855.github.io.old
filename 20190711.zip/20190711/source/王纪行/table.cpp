#include<bits/stdc++.h>
using namespace std;
int l,lens,x,y,X1,Y1;
struct r{
	int a,b;
};
vector<r>elv,twl;
string s,p;
int main() {
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	while(getline(cin,p)){
		s += p;
		if((int)p.find('E') != -1)break;
	}
	l = s.length();
	for(int i = 0;i < l;i++){
		if(s[i] == 'E')break;
		if(s[i] == 'W'){
			x++;X1++;
		}
		if(s[i] == 'L'){
			y++;Y1++;
		}
		r tmp;
		if(x + y == 11){
			tmp.a = x;tmp.b = y;
			x = 0;y = 0;
			elv.push_back(tmp);
		}
		if(X1 + Y1 == 21){
			tmp.a = X1;tmp.b = Y1;
			X1 = 0;Y1 = 0;
			twl.push_back(tmp);
		}
	}
	r tmp;
	tmp.a = x;tmp.b = y;
	x = 0;y = 0;
	elv.push_back(tmp);
	tmp.a = X1;tmp.b = Y1;
	X1 = 0;Y1 = 0;
	twl.push_back(tmp);
	lens = elv.size();
	for(int i = 0;i < lens;i++){
		printf("%d:%d\n",elv[i].a,elv[i].b);
	}
	lens = twl.size();
	for(int i = 0;i < lens;i++){
		printf("%d:%d\n",twl[i].a,twl[i].b);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
