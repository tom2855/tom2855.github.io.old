#include<bits/stdc++.h>
using namespace std;
int m,n,k,ans;
int main() {
	freopen("peanuts.in","r",stdin);
	freopen("peanuts.out","w",stdout);
	scanf("%d%d%d",&m,&n,&k);
	for(int i = 1;i <= n;i++){
		for(int j = 1;j <= m;j++){
			int x;
			scanf("%d",&x);
			ans += x;
		}
	}
	cout << ans << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
