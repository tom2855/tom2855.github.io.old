#include<bits/stdc++.h>
using namespace std;
int m,n,pos,tmp,arr[109];
bool vis[109];
int main() {
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	cin >> m >> n;
	tmp = m;
	for(int i = 1;i <= m;i++){
		arr[i] = i;
	}
	while(tmp){
		for(int i = 1;i <= m;i++){
			if(vis[i])continue;
			pos = (pos + 1) % n;
			if(pos == 0){
				pos = n;
				vis[i] = true;
				tmp--;
				printf("%d\n",i);
				if(tmp == 0)return 0;
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
