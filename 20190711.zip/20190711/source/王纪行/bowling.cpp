#include<bits/stdc++.h>
using namespace std;
string s;
int t,ans;
struct lun{
	int a,b,c;
}arr[100];
int main() {
	freopen("bowling.in","r",stdin);
	freopen("bowling.out","w",stdout);
	while(cin >> s){
		int l = s.size();
		if(l == 1){
			arr[++t].a = 10;
			arr[t].c = 2;
			arr[t].b = 0;
		}
		else {
			if(s[1] == '/' || (s[0] - '0' + s[1] - '0' == 10)){
				arr[++t].a = s[0] - '0';
				arr[t].b = 10 - arr[t].a;
				arr[t].c = 1;
			}
			else {
				arr[++t].a = s[0] - '0';
				arr[t].b = s[1] - '0';
			}
		}
	}
	for(int i = 1;i <= 10;i++){
		ans = ans + arr[i].a + arr[i].b;
		if(arr[i].c == 0);
		else if(arr[i].c == 1)ans += arr[i + 1].a;
		else {
			if(arr[i + 1].b)ans = ans + arr[i + 1].a + arr[i + 1].b;
			else ans = ans + arr[i + 1].a + arr[i + 2].a;
		}
	}
	cout << ans << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
