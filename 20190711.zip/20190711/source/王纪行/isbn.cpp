#include<bits/stdc++.h>
using namespace std;
int l,ans;
int isbn[100];
int main() {
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	for(int i = 1;i <= 13;i++){
		char c;
		cin >> c;
		if(c != '-')isbn[++l] = c - '0';
	}
	for(int i = 1;i <= 9;i++){
		ans = ans + isbn[i] * i;
		ans %= 11;
	}
	if(ans == isbn[10] || ans == 10 && isbn[10] == 'X' - '0'){
		cout << "Right" << endl;
	}
	else {
		for(int i = 1;i <= 9;i++){
			if(i == 2 || i == 5)cout << '-';
			cout << isbn[i];
		}
		cout << '-';
		cout << ans << endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
