#include<bits/stdc++.h>
using namespace std;
int n;
string s;
int main() {
	freopen("izbornik.in","r",stdin);
	freopen("izbornik.out","w",stdout);
	cin >> n;
	for(int i = 1;i <= n;i++){
		cin >> s;
		for(int i = 0;i < s.size();i++){
			if(i == 0)cout << '[';
			 cout << s[i];
			if(i == 0)cout << ']';
		}
		cout << endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
