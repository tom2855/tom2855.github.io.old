#include<bits/stdc++.h>
using namespace std;
int m,n,t,a[105],s,i=0;
int main(){
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	cin>>m>>n;
	while(s<m){
		i++;
		if(i==m+1)i=1;
		if(a[i]==0)t++;
		if(t==n){
			cout<<i<<endl;
			a[i]=1;
			s++;
			t=0;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
