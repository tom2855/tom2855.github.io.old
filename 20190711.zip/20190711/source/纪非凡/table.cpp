#include<bits/stdc++.h>
using namespace std;
int l,w,i=0,t=1,x;
string s;
int main(){
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	cin>>s;
	while(s[i]!='E'){
		if(s[i]=='W')w++;
		if(s[i]=='L')l++;
		if(x>=11*t-1){
			if(w-l>1||l-w>1){
				cout<<w<<":"<<l<<endl;
				t++;
				w=l=0;
			}
			else x--;
		}
		i++;
		x++;
	}
	cout<<w<<":"<<l<<endl<<endl;
	w=l=0;
	i=x=0;
	t=1;
	while(s[i]!='E'){
		if(s[i]=='W')w++;
		if(s[i]=='L')l++;
		if(x>=21*t-1){
			if(w-l>1||l-w>1){
				cout<<w<<":"<<l<<endl;
				t++;
				w=l=0;
			}
			else x--;
		}
		i++;
		x++;
	}
	cout<<w<<":"<<l<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
