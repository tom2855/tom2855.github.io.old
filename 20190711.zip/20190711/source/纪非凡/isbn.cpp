#include<bits/stdc++.h>
using namespace std;
int sum,t;
string s;
int main(){
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	cin>>s;
	for(int i=0;i<s.size()-2;i++)
		if(s[i]!='-'){
			t++;
			sum=sum+(s[i]-'0')*t;
		}
	if(sum%11==10){
		if(s[12]=='X'){
			cout<<"Right"<<endl;
			return 0;
		}
		else{
			for(int i=0;i<s.size()-1;i++)
				cout<<s[i];
			cout<<"X"<<endl;
		}
	}
	else {
		if(sum%11==s[12]-'0'){
			cout<<"Right"<<endl;
			return 0;
		}
		else {
			for(int i=0;i<s.size()-1;i++)
				cout<<s[i];
			cout<<sum%11<<endl;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
