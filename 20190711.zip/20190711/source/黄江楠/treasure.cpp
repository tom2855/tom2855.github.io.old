#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("treasure.in","r",stdin);
	freopen("treasure.out","w",stdout);
	cout<<"5"<<endl;
}
