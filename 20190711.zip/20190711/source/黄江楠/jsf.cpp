#include<bits/stdc++.h>
using namespace std;
int n,m,i=1,j=1,k,ans,sum,f,s,t,l;
bool a[101];
int main(){
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	cin>>n>>m;
	memset(a,0,sizeof(a));
	do{
		t++;
		if(t==n+1) t=1;
		if(a[t]==false) s++;
		if(s==m) {
			s=0;
			cout<<t<<endl;
			a[t]=true;
			f++;
		}
	}while(f!=n);
	return 0;
}
