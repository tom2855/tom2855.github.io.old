#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	cout<<"Right"<<endl;
}
