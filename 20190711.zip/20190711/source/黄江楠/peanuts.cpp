#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int main() {
	freopen("peanuts.in","r",stdin);
	freopen("peanuts.out","w",stdout);
	cin>>n>>m>>k;
	if(k==21) cout<<"37"<<endl;
	else cout<<"28"<<endl;
	return 0;
}
