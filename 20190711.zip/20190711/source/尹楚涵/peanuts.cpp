#include<bits/stdc++.h>
using namespace std;
int m,n,k;
struct node{
	int x,y,num;
}mp[450];
bool cmp(node a,node b){
	return a.num<b.num;
}
int main(){
	freopen("peanuts.in","r",stdin);
	freopen("peanuts.out","w",stdout);
	cin>>m>>n>>k;
	for(int i=1;i<=m*n;i++){
		cin>>mp[i].num;
		mp[i].x=i/m+1;
		mp[i].y=i%m;
	}
	sort(mp+1,mp+m*n+1,cmp);
	int t=0,cnt=0,it=0;
	for(int i=1;i<=m*n;i++){
		t+=mp[m*n-it].x;
		if(t+mp[m*n-it].x>k)break;
		cnt+=mp[m*n].num;
		it++;
	}
	cout<<cnt<<endl;
	return 0;
}

