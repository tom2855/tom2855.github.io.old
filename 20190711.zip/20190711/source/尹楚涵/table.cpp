#include<bits/stdc++.h>
using namespace std;
int tw11,tl11,tw21,tl21;
char ch;
string str;
int main(){
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	while(1){
		cin>>ch;
		if(ch=='E')break;
		if(ch=='W'){
			str+="W";
			tw11++;
			if(tw11==11){
				cout<<tw11<<':'<<tl11<<endl;
				tw11=tl11=0;
			}
		}
		if(ch=='L'){
			str+="L";
			tl11++;
			if(tl11==11){
				cout<<tw11<<':'<<tl11<<endl;
				tw11=tl11=0;
			}
		}
		//cout<<str<<endl;
	}
	cout<<tw11<<':'<<tl11<<endl;
	cout<<endl;
	for(int i=0;i<str.size();i++){
		if(str[i]=='W'){
			tw21++;
			if(tw21==21){
				cout<<tw21<<':'<<tl21<<endl;
				tw21=tl21=0;
			}
		}
		if(str[i]=='L'){
			tl21++;
			if(tl21==21){
				cout<<tw21<<':'<<tl21<<endl;
				tw21=tl21=0;
			}
		}
	}
	cout<<tw21<<':'<<tl21<<endl;
	return 0;
}

