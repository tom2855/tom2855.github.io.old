#include<bits/stdc++.h>
using namespace std;
int isbn[15];
char ch;
int main(){
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	for(int i=1;i<=10;){
		cin>>ch;
		if(ch>='0'&&ch<='9'){
			isbn[i]=ch-48;
			i++;
		}
		if(ch=='X'){
			isbn[i]=10;
			i++;
		}
	}
	int sum=0;
	for(int i=1;i<=9;i++)sum+=isbn[i]*i;
	if(sum%11==isbn[10])cout<<"Right"<<endl;
	else{
		for(int i=1;i<=9;i++){
			cout<<isbn[i];
			if(i==1||i==4||i==9)cout<<'-';
		}
		if(isbn[10]==10)cout<<'X';
		else cout<<sum%11;
		cout<<endl;
	}
	return 0;
}

