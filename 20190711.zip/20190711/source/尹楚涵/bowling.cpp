#include<bits/stdc++.h>
using namespace std;
string str[15],s;
int num[15],next[15],sum,n=10;
int main(){
	freopen("bowling.in","r",stdin);
	freopen("bowling.out","w",stdout);
	for(int i=1;i<=10;i++)cin>>str[i];
	if(str[10][0]=='/'){
		cin>>str[11];
		n=11;
	}
	else if(str[10][1]=='/'){
		cin>>str[11];
		n=11;
	}
	for(int i=1;i<=10;i++){
		if(str[i][0]=='/'){
			num[i]=10;
			next[i]=2;
		}
		else if(str[i][1]=='/'){
			num[i]=10;
			next[i]=1;
		}
		else{
			num[i]=(str[i][0]-'0')+(str[i][1]-'0');
			next[i]=0;
		}
		if(i>1&&next[i-1]==1){
			if(str[i][0]=='/')num[i-1]+=10;
			else num[i-1]+=str[i][0]-'0';
			next[i-1]=0;
		}
		if(i>1&&next[i-1]==2){
			if(str[i][0]=='/'){
				num[i-1]+=10;
				next[i-1]=1;
			}
			else if(str[i][1]=='/'){
				num[i-1]+=10;
				next[i-1]=0;
			}
			else{
				num[i-1]+=(str[i][0]-'0')+(str[i][1]-'0');
				next[i-1]=0;
			}
		}
		if(i>2&&next[i-2]){
			if(str[i][0]=='/')num[i-2]+=10;
			else num[i-2]+=str[i][0]-'0';
			next[i-2]=0;
		}
	}
	if(n==11){
		if(str[11][0]=='/'){
			num[10]+=10;
		}
		else if(str[11][1]=='/'){
			num[10]+=10;
		}
		else{
			num[10]+=(str[11][0]-'0')+(str[11][1]-'0');
		}
	}
	//for(int i=1;i<=12;i++)cout<<num[i]<<" ";
	//cout<<endl;
	for(int i=1;i<=10;i++)sum+=num[i];
	cout<<sum<<endl;
	return 0;
}

