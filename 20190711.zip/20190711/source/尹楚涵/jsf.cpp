#include<bits/stdc++.h>
using namespace std;
int n,m,t;
struct node{
	int n;
	int next;
}a[33000];
int main(){
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		a[i].n=i;
		a[i].next=i%n+1;
	}
	t=n;
	int now=1,pre=n;
	while(t){
		for(int i=1;i<m;i++){
			pre=now;
			now=a[now].next;
		}
		cout<<now<<endl;
		a[pre].next=a[now].next;
		now=a[now].next;
		t--;
	}
	return 0;
}
