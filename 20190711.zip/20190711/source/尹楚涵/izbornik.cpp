#include<bits/stdc++.h>
using namespace std;
int n,pos[35];
string str[35];
map<char,int> mp;
int main(){
	freopen("izbornik.in","r",stdin);
	freopen("izbornik.out","w",stdout);
	memset(pos,INT_MAX,sizeof(pos));
	cin>>n;
	cin.get();
	for(int i=1;i<=n;i++){
		getline(cin,str[i]);
		bool flag=false;
		for(int j=0;j<str[i].size();j++){
			if(str[i][j]==' ')continue;
			if(j==0||str[i][j-1]==' '){
				if(str[i][j]>='a'&&str[i][j]<='z'){
					if(!mp[str[i][j]-' ']){
						mp[str[i][j]-' ']=1;
						pos[i]=j;
						flag=true;
						break;
					}
					else continue;
				}
				if(str[i][j]>='A'&&str[i][j]<='Z'){
					if(!mp[str[i][j]]){
						mp[str[i][j]]=1;
						pos[i]=j;
						flag=true;
						break;
					}
					else continue;
				}
			}
		}
		if(flag){
			for(int j=0;j<str[i].size();j++){
				if(j==pos[i])cout<<'[';
				cout<<str[i][j];
				if(j==pos[i])cout<<']';
			}
			cout<<endl;
			continue;
		}
		for(int j=0;j<str[i].size();j++){
			if(str[i][j]==' ')continue;
			if(str[i][j]>='a'&&str[i][j]<='z'){
				if(!mp[str[i][j]-' ']){
					mp[str[i][j]-' ']=1;
					pos[i]=j;
					flag=true;
					break;
				}
				else continue;
			}
			if(str[i][j]>='A'&&str[i][j]<='Z'){
				if(!mp[str[i][j]]){
					mp[str[i][j]]=1;
					pos[i]=j;
					flag=true;
					break;
				}
				else continue;
			}
		}
		for(int j=0;j<str[i].size();j++){
			if(j==pos[i])cout<<'[';
			cout<<str[i][j];
			if(j==pos[i])cout<<']';
		}
		cout<<endl;
	}
	return 0;
}
