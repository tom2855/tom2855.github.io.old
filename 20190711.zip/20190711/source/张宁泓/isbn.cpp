#include<bits/stdc++.h>
using namespace std;
string s,checking;
int tmp,tmp2,cn[9]={0,2,3,4,6,7,8,9,10};
bool check(string x){
	for(int i=0;i<9;i++){
		tmp2=x[cn[i]]-'0';
		tmp+=tmp2*(i+1);
	}
	tmp2=tmp%11;
	if(tmp2==10){
		if(x[12]=='X') return true;
		  else return false;
	} 
	if(x[12]-'0'==tmp2) return true;
	   else return false;
}
int main(){
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	cin>>s;
	if(check(s)==true) cout<<"Right"<<endl;
	else {
		if(tmp2==10) {
			s[12]='X';
		}
		else s[12]=tmp2+'0';
		cout<<s<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

//Copyright Tom 2019
