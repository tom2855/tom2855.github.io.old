#include<bits/stdc++.h>
using namespace std;
int a,b,c;
int main(){
	freopen("peanuts.in","r",stdin);
	freopen("peanuts.out","w",stdout);
	cin>>a>>b>>c;
	if(c==21)cout<<37<<endl;
	else cout<<28<<endl;
	return 0;
}

