#include<bits/stdc++.h>
using namespace std;

int N,M,a[10005][105],b[10005][105],c[10005];
int k,ans,q,cnt;

int main(){
	
	freopen("treasure.in","r",stdin);
	freopen("treasure.out","w",stdout);
	scanf("%d%d",&N,&M);
	for(int i=1;i<=N;++i)
		for(int j=0;j<M;++j){
			scanf("%d%d",&a[i][j],&b[i][j]);
			c[i]+=a[i][j];
		}

	scanf("%d",&k);
	for(int i=1;i<=N;++i){
		ans=(ans+b[i][k])%20123;
		cnt=0;
		q=k;
		b[i][k]=(b[i][k]-1)%c[i]+1;
		while(cnt<b[i][q]){
			cnt+=a[i][k];
			if(cnt==b[i][q])
				break;
			k=(k+1)%M;	
		}		
	}
	printf("%d\n",ans%20123);
	return 0;	
}
