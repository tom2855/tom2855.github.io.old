#include<bits/stdc++.h>
using namespace std;
string s;
char c;
int num,isbn;
int main(){
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	for(int i=1;i<=9;){
		c=getchar();
		if(c!='-'){
			isbn=(isbn+(c-'0')*i)%11;
			++i;
		}
		s+=c;
	}
	getchar();
	cin>>num;
	if(num!=isbn)
		if(isbn!=10)cout<<s<<'-'<<isbn<<endl;
		else cout<<s<<"-X"<<endl;
	else printf("Right\n");
	return 0;
}

