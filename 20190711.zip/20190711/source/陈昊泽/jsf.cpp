#include<bits/stdc++.h>
using namespace std;
int N,M,l[105],s;
int main(){
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	cin>>M>>N;
	for(int i=1;i<=M;i++){
		l[i]=i;
	}
	while(M){
		s=(s+N)%M;
		if(s==0) s=M;
		cout<<l[s]<<endl;
		for(int i=s;i<=M;i++){
			l[i]=l[i+1];
		}
		M--;
		s--;
	}
	return 0;
}
