#include<bits/stdc++.h>
using namespace std;
char c;
string s;
int a,b,l[2]={11,21};
int main() {
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);

	while(c!='E'){
		c=getchar();
		if(c!='\n')s+=c;
	}
	for(int i=0; i<=1; ++i) {
		a=b=0;
		for(int j=0;j<s.size();++j) {
			if(a+b==l[i]) {
				printf("%d:%d\n",a,b);
				a=b=0;
			}
			if(s[j]=='W')++a;
			if(s[j]=='L')++b;
		}
		if(a!=0||b!=0)printf("%d:%d\n",a,b);
		printf("\n");
	}
	return 0;
}

