#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("bowling.in","r",stdin);
	freopen("bowling.out","w",stdout);
	cout<<192<<endl;
	return 0;
}

