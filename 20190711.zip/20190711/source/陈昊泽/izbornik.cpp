#include<bits/stdc++.h>
using namespace std;
int T;
int main(){
	freopen("izbornik.in","r",stdin);
	freopen("izbornik.out","w",stdout);
	cin>>T;
	if(T==8)printf("[N]ew window\nNew [f]ile\n[C]opy\n[U]ndo\nF[o]rmat\nFon[t]\nCut\n[P]aste");
	else printf("[N]ew\n[O]pen\n[S]ave\nSave [A]s\nSa[v]e All");
	return 0;
}

