#include<bits/stdc++.h>
using namespace std;
int tot = 1,cnt;
bool win[1000000];
char c;
int main() {
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	
	c = getchar();
	for(;c != 'E';++tot) {
		if(c == 'W') win[tot] = true;
		c = getchar();
		if(c == '\n') --tot;
	}
	--tot;
	for(int i = 1;i <= tot;++i) {
		if(win[i]) ++cnt;
		if(i % 11 == 0) {
			cout << cnt << ':' << 11 - cnt << endl;
			cnt = 0;
		}
	}
	if(tot % 11 != 0) {
		cout << cnt << ':' << (tot % 11) - cnt << endl;
		cnt = 0;
	}
	cout << endl;
	
	for(int i = 1;i <= tot;++i) {
		if(win[i]) ++cnt;
		if(i % 21 == 0) {
			cout << cnt << ':' << 21 - cnt << endl;
			cnt = 0;
		}
	}
	if(tot % 21 != 0) {
		cout << cnt << ':' << (tot % 21) - cnt << endl;
		cnt = 0;
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
