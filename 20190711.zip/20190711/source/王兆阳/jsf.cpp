#include<bits/stdc++.h>
using namespace std;
int m,n,now,s,k;
int a[105];
bool vis[105];
int main() {
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	
	scanf("%d%d",&m,&n);
	for(int i = 1;i <= m;++i) a[i] = i;
	do{
		++now;
		if(now == m + 1) now = 1;
		if(a[now]) ++s;
		if(s == n) {
			s = 0;
			a[now] = 0;
			cout << now << endl;
			++k;
		}
	} while(m != k);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
