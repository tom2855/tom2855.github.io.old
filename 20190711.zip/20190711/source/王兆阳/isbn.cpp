#include<bits/stdc++.h>
using namespace std;
int a[11],sum;
char c;
void get() {
	c = getchar();
}
int main() {
//	freopen("isbn.in","r",stdin);
//	freopen("isbn.out","w",stdout);
	
	scanf("%d",&a[1]);
	sum = a[1];
	get();
	for(int i = 2;i <= 4;++i) {
		get();
		a[i] = c - '0';
		sum = (sum + (c - 0) * i) % 11;
	}
	get();
	for(int i = 5;i <= 9;++i) {
		get();
		a[i] = c - '0';
		sum = (sum + (c - 0) * i) % 11;
	}
	get();
	get();
	if(sum == c - '0') {
		cout << "Right" << endl;
	} else if(sum == 10 && c == 'x') {
		cout << "Right" << endl;
	} else {
		cout << a[1] << '-';
	    for(int i = 2;i <= 4;++i) {
		    cout << a[i];
	    }
	    cout << '-';
	    for(int i = 5;i <= 9;++i) {
	    	cout << a[i];
	    }
	    cout << '-';
		if(sum == 10) cout << 'x';
		else cout << sum;
		cout << endl;
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
