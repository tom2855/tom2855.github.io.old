#include<bits/stdc++.h>
using namespace std;
int m,n,a[105];
int main(){
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	scanf("%d%d",&m,&n);
	for(int i=1;i<m;i++)
	    a[i]=i;
	a[0]=m;
	int i=0,j=0,num=0;
	while(num<m){
        if(a[i]){
        	if(j==n){
        		cout<<a[i]<<endl;
        		num++;
        		a[i]=0;
        		j=0;
			}
        	j++;
		}
		i=(i+1) % m;
	}
	return 0;
}
