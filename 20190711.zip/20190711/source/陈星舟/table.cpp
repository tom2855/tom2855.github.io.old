#include<bits/stdc++.h>
using namespace std;
int a,b,num,t;
char ch;
string s;
int main(){
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	cin>>s[0];
    while(s[t]!='E'){
    	t++;
    	cin>>s[t];
	}
	for(int i=0;i<t;i++){
		if(s[i]=='W') a++;
		if(s[i]=='L') b++;
		if(a+b==11){
			cout<<a<<':'<<b<<endl;
			a=0;
			b=0;
		}
	}
	if(a!=0||b!=0) cout<<a<<':'<<b<<endl;
	a=0;
	b=0;
	for(int i=0;i<t;i++){
		if(s[i]=='W') a++;
		if(s[i]=='L') b++;
		if(a+b==21){
			cout<<a<<':'<<b<<endl;
			a=0;
			b=0;
		}
	}
	if(a!=0||b!=0) cout<<a<<':'<<b<<endl;
	return 0;
}
