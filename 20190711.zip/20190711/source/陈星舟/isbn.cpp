#include<bits/stdc++.h>
using namespace std;
int num;
char a[10]={'1','2','3','4','5','6','7','8','9','X'};
string s,st;
int main(){
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
    cin>>s;
    st=s;
    st.erase(1,1);
    st.erase(4,1);
    st.erase(9,1);
    for(int i=0;i<st.size()-1;i++){
    	num+=(st[i]-'0')*(i+1);
	}
	num%=11;
	if(a[num-1]==st[st.size()-1]) cout<<"Right"<<endl;
	else {
		for(int i=0;i<s.size()-1;i++)
		    cout<<s[i];
		cout<<a[num-1]<<endl;
	}
}
