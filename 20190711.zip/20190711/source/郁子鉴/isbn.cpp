#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	string s;
	cin>>s;
	int ans=0;
	int c=1,i=0;
	while(c<=9){
		if(s[i]>='0'&&s[i]<='9'){
			ans+=(s[i]-'0')*c;
			c++;
		}
		i++;
	}
	if(ans%11==s[12]-'0') cout<<"Right";
	else{
		for(int i=0;i<12;i++) cout<<s[i];
		cout<<ans%11;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
