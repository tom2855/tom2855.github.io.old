#include<bits/stdc++.h>
using namespace std;
int a[100005][2],ans;
int main(){
	freopen("bowling.in","r",stdin);
	freopen("bowling.out","w",stdout);
	string s;
	getline(cin,s);
	int n=0;
	int l=s.size();
	int i=0;
	while(i<l){
		if(s[i]=='/') a[n][0]=10;
		if(s[i]>='0'&&s[i]<='9') a[n][0]=s[i]-'0';
		if(s[i]!=' ') n++;
		if(s[i]=='/'||(s[i]>='0'&&s[i]<='9'))
			if(s[i+1]=='/'||(s[i+1]>='0'&&s[i+1]<='9')){
				if(s[i+1]=='/') a[n-1][1]=10;
				else a[n-1][1]=s[i+1]-'0';
				i++;
			}
		i++;
	}
	if(a[n-2][1]==10) n--;
	else if(a[n-1][1]==0){
		if(a[n-2][1]==10) n-=2;
	}else{
		if(a[n-1][1]==10) n--;
	}
	for(int i=0;i<n;i++){
		int t=a[i][0]+a[i][1];
		if(a[i][0]==10)
			if(a[i+1][1]==0) t+=a[i+1][0]+a[i+2][0];
			else if(a[i+1][1]==10) t+=a[i+1][1];
				else t+=a[i+1][0]+a[i+1][1];
		if(a[i][1]==10) t=10+a[i+1][0];
		cout<<i<<' '<<t<<endl;
		ans+=t;
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
