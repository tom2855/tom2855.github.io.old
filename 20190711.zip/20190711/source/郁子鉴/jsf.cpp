#include<bits/stdc++.h>
using namespace std;
bool vis[105];
int main(){
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	memset(vis,true,sizeof(vis));
	int n,m;
	cin>>m>>n;
	int i=1,c=1;
	int mm=m;
	while(m){
		if(c==n&&vis[i]){
			m--;
			vis[i]=false;
			cout<<i<<endl;
			c=1;
		}
		c+=vis[i];
		i++;
		if(i>mm) i=1;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
