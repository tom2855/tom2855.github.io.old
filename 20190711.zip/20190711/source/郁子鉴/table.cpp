#include<bits/stdc++.h>
using namespace std;
int a11[100005],b11[100005],a21[100005],b21[100005];
int main(){
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	string s;
	cin>>s;
	int i=0;
	int c11=0,c21=0;
	while(s[i]!='E'){
		if(a11[c11]==11||b11[c11]==11) c11++;
		if(a21[c21]==21||b21[c21]==21) c21++;
		if(s[i]=='W'){
			a11[c11]++;
			a21[c21]++;
		}else{
			b11[c11]++;
			b21[c21]++;
		}
		i++;
	}
	for(int i=0;i<=c11;i++) cout<<a11[i]<<':'<<b11[i]<<endl;
	cout<<endl;
	for(int i=0;i<=c21;i++) cout<<a21[i]<<':'<<b21[i]<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
