#include<bits/stdc++.h>
using namespace std;
int m,n,i,j,t;
bool f[105];
int main() {
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	cin>>m>>n;
	t=m;
	i=0;
	j=0;
	while(t>0) {
		i++;
		if(i==m+1) i=1;
		if(!f[i]) {
			j++;
			if(j==n) {
				cout<<i<<'\n';
				f[i]=true;
				j=0;
				t--;
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
