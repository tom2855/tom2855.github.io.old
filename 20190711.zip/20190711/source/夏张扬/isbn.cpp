#include<bits/stdc++.h>
using namespace std;
string s;
int cnt,ans;
int main() {
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	cin>>s;
	for(int i=0; i<s.size()-2; i++) {
		if(s[i]!='-') {
			cnt++;
			ans+=(s[i]-'0')*cnt;
		}
	}
	ans%=11;
	int num=s[12]-'0';
	if(ans==10) {
		ans=40;
	}
	if(ans==num) cout<<"Right";
	else {
		s[12]=ans+'0';
		for(int i=0; i<s.size(); i++) cout<<s[i];
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
