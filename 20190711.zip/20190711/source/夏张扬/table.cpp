#include<bits/stdc++.h>
using namespace std;
char s[100005];
int num1,num2,n=1;
int main(){
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	while((s[n]=getchar())!='E') 
		n++;
	n--;
	for(int i=1;i<=n;i++){
		if(s[i]=='W') num1++;
		if(s[i]=='L') num2++;
		if(num1+num2==11){
			cout<<num1<<':'<<num2<<endl;
			num1=0;
			num2=0;
		}
	}
	cout<<num1<<':'<<num2<<endl<<endl;
	int nu1=0,nu2=0;
	for(int i=1;i<=n;i++){
		if(s[i]=='W') nu1++;
		if(s[i]=='L') nu2++;
		if(nu1+nu2==21){
			cout<<nu1<<':'<<nu2<<endl;
			nu1=0;
			nu2=0;
		}
	} 
	cout<<nu1<<':'<<nu2<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

