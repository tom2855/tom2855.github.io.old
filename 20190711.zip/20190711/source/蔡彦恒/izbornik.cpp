#include <string>
#include <cstdio>
#include <iostream>
using namespace std;

string s;
int n,p,num;
bool used[300];

int main(){
	freopen("izbornik.in", "r", stdin);
	freopen("izbornik.out", "w", stdout);
	scanf("%d", &n);
    getline(cin, s);
	for(int i = 1; i <= n; ++i) {
		getline(cin, s);
		p = -1;
		if (s[0] >= 'A' && s[0] <= 'z'){
			num = s[0];
			if (s[0] >= 'a') {
				num -= 32;
			}
			if (!used[num]){
				p = 0;
				used[num] = true;
			}
		}
		
		if (p == -1){
			for(int j = 1; j < s.size(); ++j)
				if (s[j - 1] == ' ' && s[j] != ' ') {
				   if (s[j] >= 'A' && s[j] <= 'z') {
			          num = s[j];
			          if (s[j] >= 'a') num -= 32;
			          if (!used[num]){
				         p = j;
			         	 used[num] = true;
			         	 break;
			          }
		           }	
				}
		}
		if (p == -1){
			for(int j = 1; j < s.size(); ++j)
				if (s[j] >= 'A' && s[j] <= 'z') {
			          num = s[j];
			          if (s[j] >= 'a') num -= 32;
			          if (!used[num]) {
				         p = j;
			         	 used[num] = true;
			         	 break;
			          }
			    }
		}
		if (p == -1) {
			cout << s << endl;
		}
		else {
			for(int j = 0; j < s.size(); ++j)
				if (j == p) {
					printf("[%c]", s[j]);
				}
				else {
					putchar(s[j]);
				}
			putchar('\n');
		}	
		
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
