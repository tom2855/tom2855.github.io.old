#include <string>
#include <cstdio>
#include <iostream>
using namespace std;

int main() {
	freopen("isbn.in", "r", stdin);
	freopen("isbn.out", "w", stdout);
	string str;
	long long tmp = 0;
	cin >> str;
	str.erase(str.begin() + 1);
	str.erase(str.begin() + 4);
	str.erase(str.begin() + 9);
	for(int i = 1; i <= 9; ++i) {
		tmp += (str[i - 1] - '0') * i; 
	}
	
	if(tmp % 11 == str[9] - '0') {
		cout << "Right" << endl;
	}
	else if(tmp % 11 == 10 && str[9] == 'X') {
		cout << "Right" << endl;
	}
	else {
		for(int i = 1; i <= 9; ++i) {
			cout << str[i - 1];
			if(i == 1 || i == 4 || i == 9) {
				cout << "-";
			}
		}
		if(tmp % 11 == 10) {
			putchar('X');
		}
		else {
			printf("%d", tmp % 11);
		}	putchar('\n');
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
