#include<bits/stdc++.h>
using namespace std;
int n,m,s,t;
bool a[105];
int main(){
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	cin >> m >> n;
	memset(a,true,sizeof(a));
	int t1 = m;
	while(t1 > 0){
		t++;
		if(t == m + 1){
			t = 1;
		}
		if(a[t]){
			s++;
			if(s == n){
				cout << t << endl;
				a[t] = false;
				s = 0;
				t1--;
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
