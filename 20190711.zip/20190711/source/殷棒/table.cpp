#include<bits/stdc++.h>
using namespace std;
char s[100005];
int p1,p2,p3,p4,n = 1;
int main(){
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	while((s[n] = getchar()) != 'E'){
		n++;
	}
	n--;
	for(int i = 1;i <= n;i++){
		if(s[i] == 'W'){
			p1++;
		}
		if(s[i] == 'L'){
			p2++; 
		} 
		if(p1 == 11 || p2 == 11){
			cout << p1 << ":" << p2 << endl;
			p1 = 0;
			p2 = 0;
		}
	}
	cout << p1 << ":" << p2 << endl;
	cout << endl;
	for(int i = 1;i <= n;i++){
		if(s[i] == 'W'){
			p3++;
		}
		if(s[i] == 'L'){
			p4++; 
		} 
		if(p3 == 21 || p4 == 21){
			cout << p3 << ":" << p4 << endl;
			p3 = 0;
			p4 = 0;
		}
	}
	cout << p3 << ":" << p4 << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
