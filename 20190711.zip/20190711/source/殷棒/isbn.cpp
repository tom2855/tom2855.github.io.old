#include<bits/stdc++.h>
using namespace std;
string s;
int cnt,ans;
int main(){
//	freopen("isbn.in","r",stdin);
//	freopen("isbn.out","w",stdout);
	cin >> s;
	for(int i = 0;i < s.size() - 2;i++){
		if(s[i] != '-'){
			cnt++;
			ans += (s[i] - '0') * cnt;
		}
	}

	ans %= 11;
	cout << ans << endl;
	return 0;	
	if(ans == s[12] - '0'){
		cout << "Right" << endl;
	}
	else{
		if(ans == 10 && s[12] == 'X'){
			cout << "Right" << endl;
		}
		else{
			if(ans == 10){
				s[12] == 'X';
				cout << s << endl;
			}
			else{
				s[12] = ans + '0';
				cout << s << endl;
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
