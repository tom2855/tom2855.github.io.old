#include<bits/stdc++.h>
using namespace std;
char a[20];
int t;
long long sum;
int main() {
	freopen("isbn.in","r",stdin);
	freopen("isbn.out","w",stdout);
	for(register int i=1; i<=13; ++i) {
		cin>>a[i];
	}
	for(register int i=1; i<=11; ++i) {
		t++;
		if(a[i]!='-') {
			sum+=(a[i]-48)*t;
		}
		if(a[i]=='-') {
			t--;
		}
	}
	if(sum%11==10&&a[13]=='X') {
		cout<<"Right"<<endl;
		return 0;
	}
	if(sum%11==a[13]-48) {
		cout<<"Right"<<endl;
		return 0;
	} else {
		for(register int i=1; i<13; ++i) {
			cout<<a[i];
		}
		if(sum%11==10) {
			cout<<"X"<<endl;
			return 0;
		} else {
			cout<<sum%11<<endl;
			return 0;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
