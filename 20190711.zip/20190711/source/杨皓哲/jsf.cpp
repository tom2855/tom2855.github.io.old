#include<bits/stdc++.h>
using namespace std;
int m,n,t,a[110],s,k;
int main() {
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	cin>>m>>n;
	for(register int i=1; i<=m; ++i) {
		a[i]=i;
	}
	do {
		t++;
		if(t==m+1) {
			t=1;
		}
		if(a[t]!=0) {
			s++;
		}
		if(s==n) {
			s=0;
			a[t]=0;
			cout<<t<<endl;
			k++;
		}
	} while(m!=k);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
