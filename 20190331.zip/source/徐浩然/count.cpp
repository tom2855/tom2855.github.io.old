#include<bits/stdc++.h>
using namespace std;
int s,ans;

int main(){
	  freopen("count.in","r",stdin);
	  freopen("count.out","w",stdout);
      cin>>s;
      if(s == 0 ) cout<<"0"<<endl;
        else{
        	for(int i = 1; i <= s; i++){
	  	          ans += (1 + i) * i /2;
	         }	
	       cout<<ans<<endl;
		}
	  
	  return 0;
}
