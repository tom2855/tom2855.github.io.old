#include<bits/stdc++.h>
using namespace std;
int a[15],n,ans;
int main(){
	freopen("busses.in","r",stdin);
	freopen("busses.out","w",stdout);
        for(int i = 1;i <=10 ; i++){
        	cin>>a[i];
		}
		cin>>n;
	    ans = a[1] * n;
	    cout<<ans<<endl;
	    return 0;
}
