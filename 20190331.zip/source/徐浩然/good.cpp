#include<bits/stdc++.h>
using namespace std;
int used[1005],ans;
string s;
char a[8] = {'H','h','L','O','o','i','I','l'};
void dfs(int x,int c){
	ans = max(ans,c);
	used[x] = 1;
	for(int i = 0 ; i < 8; i++){
		if(s[x + 1] == a[i]){
			c++;
			dfs(x + 1,c);
			break;
		}
	}
	
}
int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	getline(cin,s);
	for(int i = 0 ; i < s.size(); i++){
		for(int j = 0; j < 8; j++){
			if(s[i] == a[j] and used[i] == 0){
				used[i] = 1;
				dfs(i,1);
			} 
		}
		
	}
	cout<<ans<<endl;
	return 0;
}
