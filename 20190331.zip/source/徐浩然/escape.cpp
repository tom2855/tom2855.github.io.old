#include<bits/stdc++.h>
using namespace std;
struct queue{
	int x,y,step;
}q[2505];
int n,m,a[505][505],tx,ty,ans = 250006;
int dx[4] = {0,1,-1,0};
int dy[4] = {1,0,0,-1};
	
int main(){
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	cin>>n>>m;
	for(int i = 1; i <= n ; i++){
		for(int j = 1; j <= m ; j++){
			cin>>a[i][j];
		}
	}
    cin>>tx>>ty;
    a[tx][ty] = 1;
	int f = 1;
	int r = 1;
	q[1].x = tx;
	q[1].y = ty;
	q[1].step = 0;
	while(f <= r){
		int b = q[f].x;
		int c = q[f].y;
		for(int i = 0 ; i < 4; i++){
			int nx = b + dx[i];
			int ny = c + dy[i];
			if(a[nx][ny] == 0 and nx > 0 and nx <= n and ny > 0 and ny <= n) {
				q[++r].x = nx;
				q[r].y = ny;
				q[r].step = q[f].step + 1;
				a[nx][ny] = 1;
				//cout<<nx<<" "<<ny<<endl;
			}
			if(q[r].x == n and q[r].y == m){
				ans = min(q[r].step,ans);
			}
		}
		f++;
	}
    cout<<ans<<endl;
    return 0;
}
