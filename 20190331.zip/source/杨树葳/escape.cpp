#include<bits/stdc++.h>
using namespace std;
int n,m,mi = 2147483647,q,p;
int dx[4] = {0,0,1,-1};
int dy[4] = {1,-1,0,0};
bool vis[501][501] = {0};
char a[501][501];
void dfs(int x,int y,int s) {
	if(x == n && y == m && s < mi) mi = s;
	for(int k=0; k<4; k++) {
		if(!vis[x+dx[k]][y+dy[k]]) {
			vis[x][y] = 1;
			dfs(x+dx[k],y+dy[k],s+1);
			vis[x][y] = 0;
		}
	}
}
int main() {
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	memset(vis,1,sizeof(vis));
	cin >> n >> m;
	for(int i=1; i<=n; i++)
		for(int j=1; j<=m; j++) {
			cin >> a[i][j];
			if(a[i][j] == '0') vis[i][j] = 0;
		}
	cin >> q >> p;
	dfs(q,p,0);
	if(q==n&&p==m) cout << 0 << endl;
	else
		cout << mi << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
