#include<bits/stdc++.h>
using namespace std;
int n;
int c = 1,ans = 1;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin >> n;
	for(int i=2; i<=n; i++){
		c += i;
		ans += c;
	}
	cout << ans << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
