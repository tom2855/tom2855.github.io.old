#include<bits/stdc++.h>
using namespace std;
string s;
int ans,mans,K,b,c;
char a[8] = {'H','L','O','I','h','l','o','i'};
int main() {
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	getline(cin,s);
	int len = s.size();
	for(int i=0; i<len; i++) {
		if(s[i] == ' ') continue;
		for(int j=0; j<=8; j++) {
			if(j == 8) {
				mans = max(ans,mans);
				ans = 0;
				break;
			}
			if(s[i] == a[j]) {
				ans++;
				i++;
				j = 0;
			}
		}
	}
	cout << mans << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
