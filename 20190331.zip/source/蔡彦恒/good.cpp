#include <iostream>
#include <string>
using namespace std;

int len, n, ans, sum, maxn, tmp;
char a[] = { 'H', 'L', 'O', 'I' };

int main() {
	freopen("good.in", "r", stdin);
	freopen("good.out", "w", stdout);
	string s;
	getline(cin,s);
	len = s.size();
	for(int i = 0; i < len; ++i) {
		if(s[i] >= 'a' && s[i] <= 'z') {
			s[i] -= 32;
		}
	}
	for(int i = 0; i < len; ++i) {
		if(s[i] == ' ') {
			continue;
		}
		for(int j = 0; j <= 3; j++) {	
			if(s[i] == a[j]) {
				tmp++;
				i++;
				j = 0;
			}
		}
		maxn = max(maxn, tmp);
		tmp = 0;
	}
	cout << maxn << endl;
	return 0;
}
