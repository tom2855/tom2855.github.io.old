#include <cstdio>
#include <fstream>
using namespace std;

long long opt[1001], sum = 0;

int main() {
	ifstream fin("count.in");
	ofstream fout("count.out");
	freopen("count.out", "w", stdout);
	opt[1] = (long long)1;
	int n;
	long long curr = 2;
	fin >> n; 
	for(int i = 2; i <= n; ++i) {
		opt[i] = opt[i - 1] + curr;
		curr++;
	}
	for(int i = 1; i <= n; ++i) {
		sum += opt[i];
	}
	fout << sum << endl;
	fin.close(),
	fout.close();
	return 0;
}
