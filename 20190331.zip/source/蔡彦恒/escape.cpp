#include <cstdio>
#include <queue>
using namespace std;

const int dx[] = { 1, 0, -1, 0 },
		  dy[] = { 0, 1, 0, -1 };
struct node {
	int x, y, step;
	node(int _x = 0, int _y = 0, int _s = 0): x(_x), y(_y), step(_s) { }
};
bool map[501][501], vis[501][501];
int sx, sy, n, m, ans = 0;
int tmp;
queue<node> q;

void bfs() {
	q.push(node(sx, sy, 0));
	vis[sx][sy] = true;
	while(!q.empty()) {
		node tmp = q.front();
		if(tmp.x == n && tmp.y == m) {
			ans = tmp.step;
			return;
		}
		for(int k = 0; k < 4; ++k) {
			int nx = dx[k] + tmp.x,
				ny = dy[k] + tmp.y;
			if(nx > 0 && nx <= n && ny > 0 && ny <= m && !map[nx][ny] && !vis[nx][ny]) {
				q.push(node(nx, ny, tmp.step + 1));
				vis[nx][ny] = true;
			}
		}
		q.pop();
	}
}

int main() {
	freopen("escape.in", "r", stdin);
	freopen("escape.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= n; ++i) {
		for(int j = 1; j <= m; ++j) {
			scanf("%d", &tmp);
			if(tmp) {
				map[i][j] = true;
			}
		}
	}
	scanf("%d%d", &sx, &sy);
	bfs();
	printf("%d\n", ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
