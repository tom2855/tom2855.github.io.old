#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	long long n,s = 0,c=0;
	cin>>n; 
	for(int i=1;i<=n;i++){
		c+=i;
		s+=c;
	}
	cout<<s;
}
