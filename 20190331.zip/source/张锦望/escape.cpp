#include<bits/stdc++.h>
using namespace std;
struct point{
	int x;
	int y;
	int c;
};
int mi=INT_MAX,n,m;
int d[4][2]={
-1,0,
0,1,
1,0,
0,-1};
bool mp[502][502];
queue<point> a;
void bfs(int x,int y,int c){
	if(x==n&&y==m){
		mi=min(mi,c);
	}
	mp[x][y]=1;
	a.pop();
	for(int i=0;i<4;i++){
		int nx=x+d[i][0],ny=y+d[i][1];
		if(!mp[nx][ny]){
			point t;
			t.x=nx;
			t.y=ny;
			t.c=c+1;
			a.push(t);
		}
	}
	if(a.size()==0)return;
	bfs(a.front().x,a.front().y,a.front().c);
}
int main(){
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	int x,y;
	cin>>n>>m;
	for(int i=0;i<502;i++){
		for(int j=0;j<502;j++){
			mp[i][j]=1;
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>mp[i][j];
		}
	}
	cin>>x>>y;
	point t;
	t.x=x;
	t.y=y;
	t.c=0;
	a.push(t);
	bfs(x,y,0);
	cout<<mi;
}
