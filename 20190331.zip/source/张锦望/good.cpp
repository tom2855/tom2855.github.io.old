#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	string s,b="HLOIhloi";
	getline(cin,s);
	int t=0,ma=0;
	for(int i=0;i<s.size();i++){
		if(b.find(s[i])!=-1){
			t++;
		}else{
			ma=max(ma,t);
			t=0;
		}
	}
	ma=max(ma,t);
	cout<<ma;
}
