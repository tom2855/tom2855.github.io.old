#include<bits/stdc++.h>
using namespace std;
int b[10],mi=INT_MAX;
void f(int m,int l){
	if(l==0){
		mi=min(mi,m);
		return;
	}
	for(int i=0;i<10;i++){
		if(i>l)break;
		f(m+b[i],l-i-1);
	}
}
int main(){
	freopen("busses.in","r",stdin);
	freopen("busses.out","w",stdout);
	int n;
	for(int i=0;i<10;i++){
		cin>>b[i];
	}
	cin>>n;
	f(0,n);
	cout<<mi;
}
