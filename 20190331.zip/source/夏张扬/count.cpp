#include<bits/stdc++.h>
using namespace std;
long long ans,a,s[10010];
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>a;
	for(int i=0;i<=a;i++){
		s[i]=s[i-1]+i;
		ans+=s[i];
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
