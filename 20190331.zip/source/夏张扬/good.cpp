#include<bits/stdc++.h>
using namespace std;
string s;
int ans,ss,ans1;
int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	getline(cin,s);
	ss=s.size();
	for(int i=0;i<ss;i++){
		if(s[i]=='H'||s[i]=='O'||s[i]=='L'||s[i]=='I'||s[i]=='h'||s[i]=='o'||s[i]=='i'||s[i]=='l'){
			ans1++;
		}else{
			if(ans1>ans) ans=ans1;
			ans1=0;
		}
		if(ans1>ans) ans=ans1;
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
