#include<bits/stdc++.h>
using namespace std;
int n,j,ans;

int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	scanf("%d",&n);
	for(int i = 1;i <= n;i++){
		ans = ans + i + j;
		j += i;
	}
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
