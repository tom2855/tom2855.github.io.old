#include<bits/stdc++.h>
using namespace std;
int step;
string s;
int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
    cin >> s;
	for(int i = 0;i < s.size();i++){
		if(s[i] == 'H' || s[i] == 'h') step++;
		if(s[i] == 'L' || s[i] == 'l') step++;
		if(s[i] == 'O' || s[i] == 'o') step++;
		if(s[i] == 'I' || s[i] == 'i') step++;
	}
    cout << step << endl;
    fclose(stdin);
    fclose(stdout);
	return 0;
}
