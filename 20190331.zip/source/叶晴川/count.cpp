#include<bits/stdc++.h>
using namespace std;
long long n,a,ans;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		a+=i;
		ans+=a;
	}
    cout<<ans<<endl;
    return 0;
}
