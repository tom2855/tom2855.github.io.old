#include<bits/stdc++.h>
using namespace std;
char a[8]={'H','L','O','I','h','l','o','i'};
string s;
bool check;
int ans,MAXN;
int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	getline(cin,s);
	for(int i=0;i<s.size();i++){
		check=true;
		for(int j=0;j<8;j++){
			if(s[i]==a[j]){
				ans++;
				check=false;
				break;
			}
		}
		if(check==1){
			MAXN=max(MAXN,ans);
			ans=0;
		}
	}
	MAXN=max(MAXN,ans);
	cout<<MAXN<<endl;
	return 0;
}
