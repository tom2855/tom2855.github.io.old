#include<bits/stdc++.h>
using namespace std;
long long n,ans;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	for(int i=n;i>=1;i--)
		ans=ans+((1+i)*i/2);
	cout<<ans<<endl;
	return 0;
}
