#include<bits/stdc++.h>
using namespace std;
int rmb[15],km,ans;
int main(){
	freopen("busses.in","r",stdin);
	freopen("busses.out","w",stdout);
	for(int i=1;i<=10;i++)
		cin>>rmb[i];
	cin>>km;
	for(int i=10;i>=1;i--){
		ans+=km/i*rmb[i];
		km=km-(km/i*i);
	}
	cout<<ans<<endl;
	return 0;
}
