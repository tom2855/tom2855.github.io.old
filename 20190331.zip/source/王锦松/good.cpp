#include<bits/stdc++.h>
using namespace std;
int num[1005],t;
string s;
int mycmp(int x,int y){
	return x>y;
}
int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	cin >> s;
	for(int i=1;i<=s.size();i++){
		t++;
		for(int j=1;j<=s.size();j++){
			if(s[j]=='H' || s[j]=='L'||s[j]=='I' || s[j]=='O' || s[j]=='h' || s[j]=='l' || s[j]=='i' || s[j]=='o'){
				num[t]++;
			}
		}
	}
	sort(num,num+s.size()+1,mycmp);
	cout<<num[1]<<endl;
	return 0;
}
