#include<bits/stdc++.h>
using namespace std;
int n;
long long s[10005],ans;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		s[i]=s[i-1]+i;
		ans+=s[i];
	}
	cout<<ans;
	return 0;
}
