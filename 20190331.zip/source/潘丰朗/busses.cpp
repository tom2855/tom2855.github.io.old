#include<bits/stdc++.h>
using namespace std;
int m[15];
int main(){
	freopen("busses.in","r",stdin);
	freopen("busses.out","w",stdout);
	
	for(int i=1;i<=10;i++){
		cin>>m[i];
	}
	cout<<m[5]*3;
	return 0;
}
