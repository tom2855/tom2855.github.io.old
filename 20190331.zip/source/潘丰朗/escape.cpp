#include<bits/stdc++.h>
using namespace std;
int n,m,x,y;
int e[505][505];
int main(){
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>e[i][j];
		}
	}
	cin>>x>>y;
	cout<<n-x+m-y;
	return 0;
}
