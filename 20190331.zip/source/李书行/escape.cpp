#include<bits/stdc++.h>
using namespace std;
int n,m,a,b,x,y,h,t,c[501][501],ans[501][501],qx[250000],qy[250000],nx,ny,dx[4]={0,1,0,-1},dy[4]={1,0,-1,0};
int main(){
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	    for(int j=1;j<=m;j++)
	        scanf("%d",&c[i][j]);
	cin>>a>>b;
	qx[h]=a;
	qy[h]=b;
	while(h<=t){
		x=qx[h];
		y=qy[h];
		h++;
		c[x][y]=1;
		if(x==n&&y==m){
			cout<<ans[n][m]<<endl;
			break;
		}
		for(int k=0;k<4;k++){
			nx=x+dx[k];
			ny=y+dy[k];
			if(nx>0&&nx<=n&&ny>0&&ny<=m&&!c[nx][ny]){
				t++;
				qx[t]=nx;
				qy[t]=ny;
				ans[nx][ny]=ans[x][y]+1;
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
