#include<bits/stdc++.h>
using namespace std;
long long n,a[10001];
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	a[1]=1;
	for(int i=2;i<=n;i++)
	    a[i]=2*a[i-1]-a[i-2]+i;
	cout<<a[n]<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
