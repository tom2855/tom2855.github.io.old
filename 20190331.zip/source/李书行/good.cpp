#include<bits/stdc++.h>
using namespace std;
string s;
int a,ans;
int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	getline(cin,s);
	for(int i=0;i<s.size();i++){
		if(s[i]!=' '&&s[i]=='H'||s[i]=='h'||s[i]=='L'||s[i]=='l'||s[i]=='O'||s[i]=='o'||s[i]=='I'||s[i]=='i')
		    a++;
		else
		    a=0;
		ans=max(ans,a);
	}
    cout<<ans<<endl;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
