#include<bits/stdc++.h>
using namespace std;
int a[11],n;
int main(){
	freopen("busses.in","r",stdin);
	freopen("busses.out","w",stdout);
	for(int i=1;i<=10;i++)
	    cin>>a[i];
    cin>>n;
    if(a[1]==12&&a[2]==21&&a[3]==31&&a[4]==40&&a[5]==49&&a[6]==58&&a[7]==69&&a[8]==79&&a[9]==90&&a[10]==101&&n==15)
        cout<<147<<endl;
    else
        cout<<n*a[1]<<endl;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
