#include<bits/stdc++.h>
using namespace std;
string s;
int sum1,sum2;
int main() {
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	getline(cin,s);
	for(int i=0; i<=s.size()-1; i++) {
		if(s[i]==' ') {
			continue;
		}
		if(s[i]=='H'||s[i]=='h'||s[i]=='L'||s[i]=='l'||s[i]=='O'||s[i]=='o'||s[i]=='I'||s[i]=='i') {
			sum1++;
		}
		if(s[i]!='H'&&s[i]!='h'&&s[i]!='L'&&s[i]!='l'&&s[i]!='O'&&s[i]!='o'&&s[i]!='I'&&s[i]!='i') {
			sum2=max(sum1,sum2);
			sum1=0;
		}
		if(i==s.size()-1) {
			sum2=max(sum1,sum2);
		}
	}
	cout<<sum2<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
