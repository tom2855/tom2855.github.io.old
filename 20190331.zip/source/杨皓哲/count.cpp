#include<bits/stdc++.h>
using namespace std;
long long n,a,b;
int main() {
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	for(int i=1; i<=n; i++) {
		a=a+i;
		b=b+a;
	}
	cout<<b<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
