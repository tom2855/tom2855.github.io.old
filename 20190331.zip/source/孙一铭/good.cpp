#include <bits/stdc++.h>
using namespace std;

string good = "hloiHLOI",s;
int ans,cnt;

int main() {
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	
	getline(cin,s);
	for(int i = 0;i < s.size();i ++) {
		if(good.find(s[i]) != string::npos) cnt ++;
		else cnt = 0;
		ans = max(ans,cnt);
	}
	cout << ans << endl;
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
