#include <bits/stdc++.h>
using namespace std;

int _map[505][505];
int dx[4] = {0,0,1,-1};
int dy[4] = {1,-1,0,0};
int n,m,x,y,ans = 10000000;

bool check(int x,int y) {
	if(x > n || x < 1) return false;
	if(y > m || y < 1) return false;
	if(_map[x][y]) return false;
	return true;
}

void bfs(int x,int y,int step) {
	if(x == n && y == m) ans = min(ans,step);
	for(int d = 0;d < 4;d ++) {
		int nx = x + dx[d];
		int ny = y + dy[d];
		if(check(x,y)) {
			_map[x][y] = 1;
			bfs(nx,ny,step + 1);
			_map[x][y] = 0;
			//cout << dx[d] << " " << dy[d] << endl;
		}
	}
	
	//printf("%d %d %d\n",x,y,step);
}

int main() {
  freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	
	cin >> n >> m;
	for(int i = 1; i <= n; i ++)
		for(int j = 1; j <= m; j ++)
			cin >> _map[i][j];
	cin >> x >> y;
	
	bfs(x,y,0);
	
	cout << ans << endl;
	
	fclose(stdin);
	fclose(stdout);
	
	return 0; 
}
