#include <bits/stdc++.h>
using namespace std;

int t[15],n,ans;
struct tmp {
	int miles;
	long double pj;
} tt[15];

bool cmp(tmp a,tmp b) {
	if(b.pj - a.pj > 0.00000000000000001) return true;
}

void take(int mile,int mrank) {
	if(mile < tt[mrank].miles) take(mile,mrank + 1);
	else {
		mile -= tt[mrank].miles;
		ans += t[mrank];
		take(mile,1);
	}
}

int main() {
	freopen("busses.in","r",stdin);
	freopen("busses.out","w",stdout);

	for(int i = 1; i <= 10; i ++) {
		cin >> t[i];
		tt[i].miles = i;
		tt[i].pj = double(t[i] / tt[i].miles);
	}

	cin >> n;
	for(int i = 1; i <= 10; i ++)
		for(int j = i + 1; j <= 10; j ++)
			if(tt[i].pj - tt[j].pj > 0.00000000000000001) swap(tt[i],tt[j]);
	take(n,1);
	cout << ans << endl;
	return 0;
}
