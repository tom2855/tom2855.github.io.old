#include <bits/stdc++.h>
using namespace std;

long long opt[10005],s[10005],i,n;

int main() {
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	
	cin >> n;
	for(i = 1;i <= n;i ++) {
		opt[i] = opt[i - 1] + i;
		s[i] = s[i - 1] + opt[i];
	}
	cout << s[n] << endl;
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
