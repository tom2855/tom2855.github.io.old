#include<bits/stdc++.h>
using namespace std;
string s;
int m[1005],ans;
int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	cin>>s;
	for(int i=1;i<s.size();i++){
		if(m[i]='H')ans++;
		if(m[i]='L')ans++;
		if(m[i]='O')ans++;
		if(m[i]='T')ans++;
		if(m[i]='h')ans++;
		if(m[i]='l')ans++;
		if(m[i]='o')ans++;
		if(m[i]='t')ans++;
	}
	getline(cin,s);
	cout<<ans<<endl;
	return 0;
}
