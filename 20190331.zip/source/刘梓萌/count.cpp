#include<bits/stdc++.h>
using namespace std;
int n,num[10005],ans;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	num[1]=1;
	ans=1;
	for(int i=2;i<=n;i++){
		num[i]=num[i-1]+i;
	    ans+=num[i];
	}
	cout<<ans<<endl;
	return 0;
}
