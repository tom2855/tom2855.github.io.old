#include<bits/stdc++.h>
using namespace std;
long long N,ans;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	scanf("%d",&N);
	for(int i=1;i<=N;i++)
		ans+=i*(N-i+1);
	printf("%lld\n",ans);
	return 0;
}
