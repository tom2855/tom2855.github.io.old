#include<bits/stdc++.h>
using namespace std;
string s;
int l,ans,p,ta;
map<char,bool>c;
void start(){
	c['H']=true;
	c['h']=true;
	c['L']=true;
	c['l']=true;
	c['O']=true;
	c['o']=true;
	c['I']=true;
	c['i']=true;
}
int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	start();
	getline(cin,s);
	l=s.size();
	for(int i=0;i<l;i++){
		p=i;
		ta=0;
		while(c[s[p]]){
			p++;
			ta++;
		}
		ans=max(ans,ta);
	}
	printf("%d\n",ans);
	return 0;
}
