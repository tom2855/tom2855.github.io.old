#include<bits/stdc++.h>
using namespace std;
int n,m,sx,sy,ans,q[250000][3],fnt,rer;
bool Map[501][501];
int dx[4]={-1,1,0,0};
int dy[4]={0,0,-1,1};
void read(){
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%d",&Map[i][j]);
	scanf("%d%d",&sx,&sy);
}
void search(){
	rer++;
	q[rer][0]=sx;
	q[rer][1]=sy;
	q[rer][2]=0;
	Map[sx][sy]=true;
	
	while(fnt<=rer){
		fnt++;
		int x=q[fnt][0];
		int y=q[fnt][1];
		int z=q[fnt][2];
		
		for(int i=0;i<4;i++){
			int nx=x+dx[i],ny=y+dy[i],nz=z+1;
			if(nx>0&&nx<=n&&ny>0&&ny<=m&&!Map[nx][ny]){
				rer++;
				q[rer][0]=nx;
				q[rer][1]=ny;
				q[rer][2]=nz;
				Map[nx][ny]=true;
				if(nx==n&&ny==m){
					ans=nz;
					return;
				}
			}
		}
	}
}
void write(){
	printf("%d\n",ans);
	/*for(int i=1;i<=rer;i++)
		cout<<q[i][0]<<' ';
	cout<<endl;
	for(int i=1;i<=rer;i++)
		cout<<q[i][1]<<' ';
	cout<<endl;
	for(int i=1;i<=rer;i++)
		cout<<q[i][2]<<' ';
	cout<<endl;*/
}
int main(){
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	read();
	search();
	write();
	return 0;
}
