#include<bits/stdc++.h>
using namespace std;
int N,n[101];
int main(){
	freopen("busses.in","r",stdin);
	freopen("busses.out","w",stdout);
	for(int i=1;i<=10;i++)
		scanf("%d",&n[i]);
	scanf("%d",&N);
	
	for(int i=1;i<=N;i++){
		if(!n[i])n[i]=n[i-1]+n[1];
		for(int j=1;j<i;j++)
			n[i]=min(n[j]+n[i-j],n[i]);
	}
	printf("%d\n",n[N]);
	return 0;
}
