#include<bits/stdc++.h>
using namespace std;
int n,j,m=1,cnt=0;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		for(j=1;j<=i;j++){
			m+=j;
		}
	}
	cout<<m-1<<endl;
	return 0;
}
