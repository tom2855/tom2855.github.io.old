#include<bits/stdc++.h>
using namespace std;
int a[15],n,ans=100000;
void dfs(int sum,int coin){
	if(sum>n) return ;
	if(sum==n) {
		ans =min(coin,ans);
		return ;
	}
	for(int i=1;i<=10;i++){
		dfs(sum+i,a[i]+coin);
	}
}
int main(){
	freopen("busses.in","r",stdin);
	freopen("busses.out","w",stdout);
	for(int i=1;i<=10;i++){
		cin>>a[i];
	}
	cin>>n;
	dfs(0,0);
	cout<<ans<<endl;
	return 0;
}
