#include<bits/stdc++.h>
using namespace std;
string s;
int cnt,t=1,ans;

int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	getline(cin,s);
	for(int i=0;i<=s.size()-1;i++){
		switch(s[i]){
			case 'H':{
				cnt++;
				break;
			}
			case 'h':{
				cnt++;
				break;
			}
			case 'O':{
				cnt++;
				break;
			}
			case 'o':{
				cnt++;
				break;
			}
			case 'L':{
				cnt++;
				break;
			}
			case 'l':{
				cnt++;
				break;
			}
			case 'I':{
				cnt++;
				break;
			}
			case 'i':{
				cnt++;
				break;
			}
			default :{
				ans=max(ans,cnt);
				cnt=0;
				break;
			}
		}
	}
	ans=max(ans,cnt);
	cout<<ans<<endl;
	return 0;
}
