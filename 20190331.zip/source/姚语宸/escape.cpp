#include<bits/stdc++.h>
using namespace std;
#define MAXN 500
struct node {
	int x,y,step;
}que[MAXN*MAXN+5];
int dx[4]={1,-1,0,0};
int dy[4]={0,0,1,-1};
int _map[MAXN+5][MAXN+5],n,m;
bool vis[MAXN+5][MAXN+5];
bool check(int nx,int ny){
	if(_map[nx][ny]==1) return false;
	if(nx<1||nx>n) return false;
	if(ny<1||ny>m) return false;
	if(vis[nx][ny]) return false;
	else return true;
}
void bfs(int x,int y){
	int front,rear,nx,ny,ns;
	front=rear=1;
	que[front].x=x;
	que[front].y=y;
	que[front].step=0;
	while(front<=rear){
		if(que[front].x==n&&que[front].y==m){
			cout<<que[front].step<<endl;
			return ;
		}
		for(int i=0;i<4;i++){
			nx=que[front].x+dx[i];
			ny=que[front].y+dy[i];
			ns=que[front].step+1;
			if(check(nx,ny)){
				rear++;
				que[rear].x=nx;
				que[rear].y=ny;
				que[rear].step=ns;
			}
		}
		front++;
	}
}
int main(){
	cin>>m>>n;
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>_map[i][j];
		}
	}
	int sx,sy;
	cin>>sx>>sy;
	bfs(sx,sy);
	return 0;
}
