#include<bits/stdc++.h>
using namespace std;
string s;
char good[8] = {'H','L','O','I','h','l','o','i'};
int ans,a;
int main() {
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	getline(cin,s);
	bool n = 1;
	for(int i = 0; i < s.size(); i++) {
		n = 1;
		for(int j = 0; j < 8; j++) {
			if(s[i] == good[j]) {
				a++;
				n = 0;
				break;
			}

		}
		if(n == 1) {
			ans = max(ans,a);
			a = 0;
		}
	}
	ans = max(ans,a);
	cout << ans << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
