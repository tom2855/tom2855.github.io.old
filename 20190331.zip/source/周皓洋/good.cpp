#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	int ans=0,ans1=0,i=0;
	string s;
	getline(cin,s);
	while(i<s.size()) {
		if(s[i]=='H'||s[i]=='O'||s[i]=='L'||s[i]=='I'||s[i]=='h'||s[i]=='o'||s[i]=='l'||s[i]=='i') {
			ans1++;
			i++;
		} else {
			ans=max(ans,ans1);
			ans1=0;
			i++;
		}
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
