#include<bits/stdc++.h>
using namespace std;
int dx[4]={0,0,1,-1},dy[4]={1,-1,0,0};
int a[505][505],q[3][250100];
int m,n,front,rear,x,y;
char k;

void bfs(int i,int j){
	front=rear=1;
	q[1][1]=i; q[2][1]=j; a[i][j]=1;
	while(front<=rear){
		for(int v=0;v<4;v++){
			if(a[q[1][front]+dx[v]][q[2][front]+dy[v]]==0){
				rear++;
				q[1][rear]=q[1][front]+dx[v];
				q[2][rear]=q[2][front]+dy[v];
				a[q[1][rear]][q[2][rear]]=1;
				if(q[1][rear]==n&&q[2][rear]==m) cout<<rear<<endl;
			}
		}
		front++;
	}
}
int main(){
//	freopen("escape.in","r",stdin);
//	freopen("escape.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;i<=m;j++)
		scanf("%d",&a[i][j]);
	}
	cin>>x>>y;
/* 
	if(x==n&&y==m) {
		rear=0;	cout<<rear<<endl;	
	}
	else 
	bfs(x,y);
*/
	return 0;
}
