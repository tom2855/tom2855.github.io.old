#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	int a[10005],n;
	long long ans=0;
	cin>>n;
	a[1]=1;
	for(int i=2;i<=n;i++){
		a[i]=a[i-1]+i;
	}
	for(int i=1;i<=n;i++)
		ans+=a[i];
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;	
}
