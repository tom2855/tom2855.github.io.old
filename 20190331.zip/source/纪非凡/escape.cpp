#include<bits/stdc++.h>
using namespace std;
int dx[4]= {0,1,0,-1};
int dy[4]= {1,0,-1,0};
int n,m,x,y,q[2][250050],a[505][505],f=1,r=2;
int main() {
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	cin>>m>>n;
	for(int i=1; i<=n; i++)
		for(int j=1; j<=m; j++)
			cin>>a[i][j];
	cin>>x>>y;
	q[1][f]=x;
	q[2][f]=y;
	while(q[1][r]!=x||q[2][r]!=y) {
		for(int k=0; k<4; k++) {
			if(q[1][f]+dx[k]<=n&&q[1][f]+dx[k]>=1&&q[2][f]+dy[k]<=m&&q[2][f]+dy[k]>=1&&a[q[1][f]+dx[k]][q[2][f]+dy[k]]==0) {
				q[1][r]=q[1][f]+dx[k];
				q[2][r]=q[2][f]+dy[k];
				r++;
			}
		}
		a[q[1][f]][q[2][f]]=1;
		f++;
	}
	cout<<r<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
