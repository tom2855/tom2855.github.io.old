#include<bits/stdc++.h>
using namespace std;
string s;
int x=0,ans=0;
int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	getline(cin,s);
	for(int i=0;i<s.size();i++){
		if(s[i]=='H')x++;
		if(s[i]=='h')x++;
		if(s[i]=='L')x++;
		if(s[i]=='l')x++;
		if(s[i]=='O')x++;
		if(s[i]=='o')x++;
		if(s[i]=='I')x++;
		if(s[i]=='i')x++;
		else {
			ans=max(ans,x);
			x=0;
		}
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
