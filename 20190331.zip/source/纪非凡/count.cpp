#include<bits/stdc++.h>
using namespace std;
int n,i,j;
long long ans;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++){
		for(j=1;j<=i;j++)
		ans=ans+j;
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
