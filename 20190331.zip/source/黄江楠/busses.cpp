#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("busses.in","r",stdin);
	freopen("busses.out","w",stdout);
	cout<<"147"<<endl;
	return 0;
}
