#include<bits/stdc++.h>
using namespace std;
int len,n,ans,sum,k,i,j,big,bigg;
char a[8]= {'H','h','L','l','O','o','I','i'};
int main() {
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	string s;
	getline(cin,s);
	len=s.size();
	for(i=0; i<len; i++) {
		if(s[i]==' ') continue;
		for(j=0; j<=8; j++) {
			if(j==8) {
				big=max(big,bigg);
				bigg=0;
				break;
			}
			if(s[i]==a[j]) {
				bigg++;
				i++;
				j=0;
			}
		}
	}
	cout<<big<<endl;
	return 0;
}
