#include<bits/stdc++.h>
using namespace std;
string s;
int ans,tmp;
int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	cin>>s;
	for(int i=0;i<=s.size();i++) {
		if(s[i]=='H'||s[i]=='L'||s[i]=='O'||s[i]=='I'||s[i]=='h'||s[i]=='l'||s[i]=='o'||s[i]=='i') {
			tmp++;
		}
		else {
			ans=max(ans,tmp);
			tmp=0;
		}
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
