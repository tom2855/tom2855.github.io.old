#include<bits/stdc++.h>
using namespace std;
int c,ans,j;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>c;
	for(int i=1;i<=c;i++) {
		ans=ans+i+j;
		j+=i;
	}
	fclose(stdin);
	fclose(stdout);
	cout<<ans<<endl;
}
