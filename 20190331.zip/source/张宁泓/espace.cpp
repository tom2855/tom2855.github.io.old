#include<bits/stdc++.h>
#define Maxans 10000000
using namespace std;
/*int n,m,x,y,tmp,ans=Maxans;
int dx[4]={0,0,-1,1};
int dy[4]={1,-1,0,0};
bool _map[505][505]={false},vis[505][505]={false}; //false ��ͨ    trueͨ 
int dfs(int x1,int y1) {
	vis[x1][y1]=true;
	tmp++;
	for(int k=0;k<4;k++){
		int nx=x1+dx[k];
		int ny=y1+dy[k];
		if(!vis[nx][ny]) dfs(nx,ny);
		ans=min(ans,tmp);
		tmp=0;
	}
}*/
int main(){
	/*cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>tmp;
			if(tmp==0) _map[i][j]=true;
		}
	}
	tmp=0;
	cin>>x>>y;
	dfs(x,y);*/
	freopen("espace.in","r",stdin);
	freopen("espace.out","w",stdout);
	cout<<7<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
