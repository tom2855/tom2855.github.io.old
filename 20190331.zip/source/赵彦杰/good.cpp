#include<bits/stdc++.h>
using namespace std;
int i,j,ans,x,num;
char a[4]= {'H','L','O','I'};
string s;
int main() {
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	getline(cin,s);
	for(i=0; i<s.size(); i++) {
		x=0;
		for(j=0; j<4; j++)
			if(s[i]==a[j]||s[i]==a[j]+32)
				x++;
		if(x)
			num++;
		else
			num=0;
		ans=max(num,ans);
	}
	cout<<ans;
	return 0;
}
