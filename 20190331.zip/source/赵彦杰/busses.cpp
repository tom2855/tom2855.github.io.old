#include<bits/stdc++.h>
using namespace std;
int p[11],km,ans,x,i;
void dfs(int d,int pr) {
	if(d>=km) {
		x=min(x,pr);
		return;
	}
	for(int i=1; i<=10; i++)
		dfs(d+i,pr+p[i]);
}
int main() {
	freopen("busses.in","r",stdin);
	freopen("busses.out","w",stdout);
	for(i=1; i<=10; i++) {
		cin>>p[i];
		if(!x||p[x]/x>p[i]/i||p[x]/x==p[i]/i&&p[x]%x>p[i]%i)
			x=i;
	}
	cin>>km;
	ans+=(km/x)*p[x];
	km-=x*(km/x);
	x=p[x];
	dfs(0,0);
	cout<<ans+x;
	return 0;
}
