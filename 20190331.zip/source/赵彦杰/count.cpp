#include<bits/stdc++.h>
using namespace std;
long long n,i,ans;
int main() {
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	for(i=1; i<=n; i++)
		ans+=i*(n-i+1);
	cout<<ans;
	return 0;
}
