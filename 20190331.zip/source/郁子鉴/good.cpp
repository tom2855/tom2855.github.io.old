#include<bits/stdc++.h>
using namespace std;
char a[8]={'H','L','O','I','h','l','o','i'};
string s;
int ans,mans;
int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	getline(cin,s);
	int l=s.size();
	bool f=1;
	for(int i=0;i<l;i++){
		f=1;
		for(int j=0;j<8;j++){
			if(s[i]==a[j]){
				ans++;
				f=0;
				break;
			}
		}
		if(f==1){
			mans=max(mans,ans);
			ans=0;
		}
	}
	mans=max(mans,ans);
	cout<<mans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
