#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	long long n,ans=0,t=0;
	cin>>n;
	for(int i=1;i<=n;i++){
		t+=i;
		ans+=t;
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
