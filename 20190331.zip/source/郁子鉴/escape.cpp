#include<bits/stdc++.h>
using namespace std;
int m,n,mans=505*505;
bool a[505][505];
int dx[4]={0,1,0,-1};
int dy[4]={1,0,-1,0};
bool check(int i,int j){
	if(i<0||i>=m) return 0;
	if(j<0||j>=n) return 0;
	if(a[i][j]==1) return 0;
	return 1;
}
void dfs(int x,int y,int ans){
	if(x==m-1&&y==n-1){
		mans=min(ans,mans);
		return;
	}
	for(int i=0;i<4;i++){
		int nx=x+dx[i];
		int ny=y+dy[i];
		if(check(nx,ny)){
			a[x][y]=1;
			dfs(nx,ny,ans+1);
		}
	}
	return;
}
int main(){
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	cin>>m>>n;
	int x,y;
	for(int i=0;i<m;i++)
		for(int j=0;j<n;j++)
			cin>>a[i][j];
	cin>>x>>y;
	dfs(x,y,0);
	cout<<mans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
