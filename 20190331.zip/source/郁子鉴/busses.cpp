#include<bits/stdc++.h>
using namespace std;
int a[11],n,mans=200000;
void f(int x,int ans){
	if(x==0) mans=min(ans,mans);
	else for(int i=1;i<=10;i++){
			if(x-i>=0) f(x-i,ans+a[i]);
		}
	return;
}
int main(){
	freopen("busses.in","r",stdin);
	freopen("busses.out","w",stdout);
	for(int i=1;i<=10;i++) cin>>a[i];
	cin>>n;
	f(n,0);
	cout<<mans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
