#include<bits/stdc++.h>
using namespace std;
struct zb{
	int p,q,cnt;
}q[250010];
int n,m,x,y,dx[4]={0,0,1,-1},dy[4]={1,-1,0,0};
int _map[510][510];
bool vis[510][510];
void bfs(){
	int front,rear;
	front=rear=1;
	q[1].cnt=0;
	q[1].p=x;
	q[1].q=y;
	while(front<=rear&&vis[n][m]==false){
		for(int i=0;i<4;i++){
			int nx=q[front].p+dx[i];
			int ny=q[front].q+dy[i];
			if(_map[nx][ny]!=1&&vis[nx][ny]==false){
				vis[nx][ny]=true;
				rear++;
				q[rear].cnt=q[front].cnt+1;
				q[rear].p=nx;
				q[rear].q=ny;
			}
		}
		front++;
	}
	cout<<q[rear].cnt<<endl;
}
int main() {
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;i<=m;j++){
			cin>>_map[i][j];
		}
	}
	cin>>x>>y;
	bfs();
	return 0;
}
