#include<bits/stdc++.h>
using namespace std;
int n,m[11],opt[110];
int main() {
	freopen("busses.in","r",stdin);
	freopen("busses.out","w",stdout);
	for(int i=1;i<=10;i++)cin>>m[i];
	cin>>n;
	opt[1]=m[1];
	for(int i=2;i<=n;i++){
		int tmp=INT_MAX;
		for(int j=1;j<=i&&j<=10;j++){
			tmp=min(tmp,opt[i-j]+m[j]); 
		}
		opt[i]=tmp;
	}
	cout<<opt[n]<<endl;
	return 0;
}
