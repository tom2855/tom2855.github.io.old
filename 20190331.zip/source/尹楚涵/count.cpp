#include<bits/stdc++.h>
using namespace std;
int ans[1010],n;
int main() {
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)ans[i]=ans[i-1]+i*(i+1)/2;
	cout<<ans[n];
	return 0;
}
