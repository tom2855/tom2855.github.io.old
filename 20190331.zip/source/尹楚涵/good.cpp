#include<bits/stdc++.h>
using namespace std;
char ch[8]= {'H','h','L','l','O','o','I','i'};
string s;
int opt[1010],ans,ans1;
int main() {
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	getline(cin,s);
	int i=0;
	while(i<s.size()) {
		if(s[i]=='H'||s[i]=='h'||s[i]=='L'||s[i]=='l'||s[i]=='O'||s[i]=='o'||s[i]=='I'||s[i]=='i') {
			ans1++;
			i++;
		} else {
			ans=max(ans,ans1);
			ans1=0;
			i++;
		}
	}
	cout<<ans<<endl;
	return 0;
}
