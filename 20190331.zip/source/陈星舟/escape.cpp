#include<bits/stdc++.h>
using namespace std;
int n,m,f,r,a,b,_map[505][505],ans=250005;
bool vis[505][505];
int dx[4]={0,0,1,-1};
int dy[4]={1,-1,0,0};
struct node{
	int x,y,step;
}q[250010];
void bfs(int x,int y){
	f=1;
	r=1;
	_map[x][y]=1;
	q[f].x=x;
	q[f].y=y;
	vis[x][y]=true;
	while(f<=r){
		if(q[f].x==n&&q[f].y==m) {
			ans=min(ans,q[f].step);
		}
		for(int k=0;k<4;k++)
		{
			int nx=q[f].x+dx[k];
			int ny=q[f].y+dy[k];
			if(_map[nx][ny]==0&&vis[nx][ny]==false){
				r++;
				q[r].x=nx;
				q[r].y=ny;
				q[r].step=q[f].step+1; 
				vis[nx][ny]=true;                  
			}
		}
		f++;
	}
}
int main(){
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	cin>>n>>m;
	for(int i=0;i<=n+1;i++)
	    for(int j=0;j<=m+1;j++)
	    _map[i][j]=1;
	for(int i=1;i<=n;i++)
	    for(int j=1;j<=m;j++)
	    cin>>_map[i][j];
	cin>>a>>b;
	bfs(a,b);
	cout<<ans<<endl;
	return 0;
}
