#include<bits/stdc++.h>
using namespace std;
string s;
int ans;
bool check(char a){
	if(a=='H') return true;
	if(a=='L') return true;
	if(a=='O') return true;
	if(a=='I') return true;
	if(a=='h') return true;
	if(a=='l') return true;
	if(a=='o') return true;
	if(a=='i') return true;
	return false;
}
int main(){
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	getline(cin,s);
	for(int i=0;i<s.size();i++)
	{
		if(check(s[i])){
		    int tmp=1;
			for(int j=i+1;j<s.size();j++)
			{
				if(check(s[j])&&check(s[j-1])) tmp++;
				else break;
			}
			ans=max(ans,tmp);
		}
	}
	cout<<ans<<endl;
	return 0;
}
