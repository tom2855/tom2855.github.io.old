#include<bits/stdc++.h>
using namespace std;
int n,a[10005];
long long sum;
int main(){
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin>>n;
	a[0]=0;
	for(int i=1;i<=n;i++)
	{
		a[i]=a[i-1]+i;
		sum+=a[i];
	}
	cout<<sum<<endl;
	return 0;
}
