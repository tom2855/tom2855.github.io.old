#include<bits/stdc++.h>
using namespace std;
int n,m,x,y;
bool _map[505][505];
queue<int>a,b,step;
int dx[6] = {1,-1,0,0};
int dy[6] = {0,0,1,-1};
void bfs(){
	a.push(x);b.push(y);step.push(0);
	_map[x][y] = 1;
	while(!a.empty()){
		int nx = a.front(),ny = b.front(),nt = step.front();
		if(nx == n && ny == m){cout << nt << endl;exit(0);}
		for(int i = 0;i < 4;i++){
			int tmpx = nx + dx[i],tmpy = ny + dy[i];
			if(tmpx > 0 && tmpy > 0 && tmpx <= n && tmpy <= m && !_map[tmpx][tmpy]){
				a.push(tmpx);b.push(tmpy);step.push(nt + 1);
				_map[tmpx][tmpy] = 1;
			}
		}
		a.pop();b.pop();step.pop();
	}
}
int main() {
	freopen("escape.in","r",stdin);
	freopen("escape.out","w",stdout);
	cin >> n >> m;
	for(int i = 1;i <= n;i++){
		for(int j = 1;j <= m;j++){
			cin >> _map[i][j];
		}
	}
	cin >> x >> y;
	bfs();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
