#include<bits/stdc++.h>
using namespace std;
string a;
int ans,lens,opt[1010];
bool good(char x) {
	if(x == 'H' || x == 'h')return true;
	if(x == 'L' || x == 'l')return true;
	if(x == 'O' || x == 'o')return true;
	if(x == 'I' || x == 'i')return true;
	return false;
}
int main() {
	freopen("good.in","r",stdin);
	freopen("good.out","w",stdout);
	getline(cin,a);
	lens = a.size() - 1;
	opt[0] = good(a[0]);
	for(int i = 1; i <= lens; i++) {
		int cnt = 0;
		if(!good(a[i]))continue;
		if(good(a[i - 1]))opt[i] = opt[i - 1] + 1;
		else opt[i] = 1;
		ans = max(ans,opt[i]);
	}
	cout << ans << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
