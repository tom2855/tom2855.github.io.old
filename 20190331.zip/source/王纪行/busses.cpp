#include<bits/stdc++.h>
using namespace std;
int bus[20],n,opt[150];
int main() {
	freopen("busses.in","r",stdin);
	freopen("busses.out","w",stdout);
	for(int i = 1;i <= 10;i++){
		cin >> bus[i];
	}
	cin >> n;
	for(int i = 1;i <= n;i++){
		int cnt = 1000000000;
		for(int j = 1;j <= 10;j++){
			if(j > i)break;
			cnt = min(cnt,opt[i - j] + bus[j]);
		}
		opt[i] = cnt;
	}
	cout << opt[n] << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
