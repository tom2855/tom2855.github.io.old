#include<bits/stdc++.h>
using namespace std;
long long ans,opt[11111];
int n;
int main() {
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cin >> n;
	for(int i = 1;i <= n;i++){
		opt[i] = opt[i - 1] + i;
		ans += opt[i];
	}
	cout << ans << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
