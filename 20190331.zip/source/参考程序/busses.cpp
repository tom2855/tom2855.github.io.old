#include<bits/stdc++.h>
using namespace std;
#define Maxn 100
int opt[Maxn + 5],s[11],d;
int main(){
	freopen("busses.in","r",stdin);
	freopen("busses.out","w",stdout);
	for(int i = 1;i <= 10;i++)
		cin >> s[i];
	cin >> d;
	for(int i = 1;i <= d;i++){
		opt[i] = 20000;
		for(int j = 1;j <= 10;j++)
			if (i >= j) opt[i] = min(opt[i],opt[i - j] + s[j]);			
	}
	cout << opt[d] << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;	
}
