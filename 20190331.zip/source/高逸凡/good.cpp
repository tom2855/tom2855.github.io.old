#include <bits/stdc++.h>
using namespace std;
int ans,ansa;
string s;
bool check(char n){
	if (n=='H'||n=='h'||n=='O'||n=='o'||n=='L'||n=='l'||n=='I'||n=='i')
	return true;
}
int main()
{ 
    freopen ("good.in","r",stdin);
	freopen ("good.out","w",stdout);
    getline (cin,s);
	for (int i=0;i<=s.size();i++){
		if (s[i]=='H'||s[i]=='h'||s[i]=='O'||s[i]=='o'||s[i]=='L'||s[i]=='l'||s[i]=='I'||s[i]=='i')
	    ans++;
	    if (check(s[i+1])!=true){
	    	ansa=max(ans,ansa);
	    	ans=0;
		}
	} 
	cout <<ansa<<endl;
	return 0;
}
