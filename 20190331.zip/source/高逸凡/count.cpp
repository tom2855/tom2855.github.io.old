#include <bits/stdc++.h>
using namespace std;
long long n,ans,a[10005];
int main()
{
	freopen ("count.in","r",stdin);
	freopen ("count.out","w",stdout);
	cin >>n;
	a[1]=1;ans=1;
	for (int i=2;i<=n;i++){
	    a[i]=a[i-1]+i;
	    ans+=a[i];	
	}
	cout <<ans<<endl;
	return 0;
}
