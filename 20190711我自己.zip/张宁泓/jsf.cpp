#include<bits/stdc++.h>
using namespace std;
int M,N,ans[8]={5,2,8,7,1,4,6,3};
int main(){
	freopen("jsf.in","r",stdin);
	freopen("jsf.out","w",stdout);
	cin>>M>>N;
	for(int i=0;i<8;i++)
	  cout<<ans[i]<<endl;
	return 0;
}
