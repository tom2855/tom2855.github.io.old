#include<bits/stdc++.h>
using namespace std;
string s,stmp;
bool stop=false;
int a,b,p;
void cheer(){
	if(a>b) cout<<a<<":"<<b<<endl;
	else cout<<b<<":"<<a<<endl;
	a=b=0;
}
int main(){
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	while(stop==false){
		cin>>stmp;
		for(int i=0;i<=stmp.size();i++)
		  if(stmp[i]=='E') stop=true;
		s+=stmp;
	}
	stop=false;
	//11
	while(stop==false){
		if(s[p]=='E') {
			if(a!=0||b!=0);
			cheer();
			stop=true;
			break;
		}
		if(s[p]=='W') a++;
		if(s[p]=='L') b++;
		p++;
		if(a==11||b==11) cheer();
	}
	cout<<endl;
	p=0;
	stop=false;
	//21
	while(stop==false){
		if(s[p]=='E') {
			if(a!=0||b!=0);
			cheer();
			stop=true;
			break;
		}
		if(s[p]=='W') a++;
		if(s[p]=='L') b++;
		p++;
		if(a==21||b==21) cheer();
	}
	fclose(stdin);
	fclose(stdout);
    return 0;
}

//Copyright Tom 2019
