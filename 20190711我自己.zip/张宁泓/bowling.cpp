#include<bits/stdc++.h>
using namespace std;
string s[15];
int ans,data[15],n;
int main(){
	for(int i=1;i<=12;i++){
		cin>>s[i];
		if(i==10&&s[10][0]!='/'&&s[10][1]!='/') {
			n=10;
			break;
		}
		if(i==11&&s[10][1]=='/') {
			n=11;
			break;
		}
		if(i==12) n=12;
	}
	for(int i=1;i<=n;i++){
		if(s[i][0]='/') data[i]=10;
		if(s[i][1]='/') data[i]=11;//hwagrihbeirugiuwer
		if(s[i][0]!='/'&&s[i][1]!='/') data[i]=s[i][0]-'0'+s[i][1]-'0';
	}
	for(int i=1;i<=n;i++){
		if(data[i]==10) ans+=10+data[i+1]+data[i+2];
		if(data[i]==11) ans+=10+data[i+1];
		if(data[i]<10) ans+=data[i];
	}
	for(int i=1;i<=12;i++){
		cout<<data[i]<<endl;
	}
	cout<<ans<<endl;
}
